# Catacombs biome pack

Open **START_HERE.html** after extracting the ZIP. It is an offline, searchable asset browser. **Overview.png** shows an assembled room made from the actual delivered sprites. The `reference_sheets` folder contains labeled inventories; `sheets` contains clean transparent atlases without labels.

## Inventory

| Asset | Coverage | PNG frames |
|---|---|---:|
| Floors | 60 distinct designs; floors 01–10 certified for self-repeat | 60 |
| Walls | 5 distinct families, 20 placement pieces per family | 100 |
| Arches | 3 designs × 4 directed views; each spans 3 tiles | 12 |
| Doors | 3 designs × 4 directed views × open/closed | 24 |
| Scatter | 40 distinct Catacombs props, one authored view each | 40 |
| **Total** | Static sprites; only doors have alternate states | **236** |

The five wall families are crypt ashlar, ossuary niches, funerary chapel, sealed cells, and drowned crypt. The three arches are Roman ossuary, pointed funerary, and ironbound segmental. The doors are ironbound oak, iron grille, and bone reliquary.

Every wall family includes 1 pillar, 4 end pieces, 2 straight node pieces, all 4 L corners, all 4 T junctions, 1 cross junction, and 4 directed full-length panels. L pieces contain both inside and outside surfaces; select the corner by its connected directions. Front and reverse artwork is included in the directed panels. Five full-length panel entries intentionally share their pixels with an equivalent topology entry; `pixel_identical_to` identifies these placement aliases. The pack has **231 distinct pixel payloads**, including all 60 different floors and all 40 different props.

## Import and placement

Use PNG RGBA, point/nearest-neighbor filtering, no smoothing, no lossy texture compression, and integer screen positions. Keep the supplied canvas dimensions and pivots. Do not trim transparent space unless you adjust the pivot by the same crop offset. Disable mipmaps for a fixed-resolution pixel presentation. If you scale the game, scale all sprites by the same integer factor.

The base tile slot is **160 × 80 pixels**, with basis vectors `u = (+80,+40)` and `v = (-80,+40)`. Coordinates are measured from the ground center of each sprite:

```text
ground_x = origin_x + 80 * (u - v)
ground_y = origin_y + 40 * (u + v)
image_x  = ground_x - pivot_x
image_y  = ground_y - pivot_y
```

Positive vertical height subtracts from screen y. For example, floor `(u=2,v=1)` has ground center `(origin_x+80, origin_y+120)`, and its 160×80 image starts at `(origin_x, origin_y+80)` because the floor pivot is `(80,40)`.

| Category | Fixed canvas | Pivot |
|---|---|---|
| Floor | 160 × 80 | 80, 40 |
| Wall | 256 × 256 | 128, 192 |
| Arch | 384 × 336 | 192, 248 |
| Door, both states | 320 × 288 | 160, 208 |
| Scatter | 192 × 192 | Per sprite in manifest |

Scatter pivots estimate the ground center from the visible base. They are practical placement anchors, not recovered 3D collision geometry. Use `footprint_tiles_estimate` as a starting point, then set gameplay collision for each prop in your engine.

Draw floors first. Ground depth `u+v` is a useful starting order for separate props. For overlapping tall architecture, use your engine's isometric occlusion rules. These are combined sprites, not a general solution for characters walking both behind and in front of the same three-tile arch; split or mask architecture in the engine if that behavior is needed.

## Orientation and wall sockets

Direction names describe the direction **along** a panel, not a compass-facing camera normal:

| Name | World step | Screen step | Rotation from base |
|---|---|---|---:|
| SE | +u | +80,+40 | 0° |
| SW | +v | -80,+40 | 90° |
| NW | -u | -80,-40 | 180° |
| NE | -v | +80,-40 | 270° |

Wall topology uses neighbor bits `NE=1, SE=2, SW=4, NW=8`. Add the bits for all connected neighbors. For example, mask 6 gives the SE+SW corner; mask 14 gives SE+SW+NW, a T junction. A node connects at half-tile offsets from its pivot and joins the next node at a center spacing of one tile. Each wall is 128 pixels tall and 0.2 tile thick.

A directed wall panel extends from -0.5 to +0.5 tile along its oriented axis. An arch extends from -1.5 to +1.5 tiles along that axis. Place wall centers at -2 and +2 relative to an arch center to connect to its outer endpoints. The **three-tile measurement is the outer structural span**, including the piers; the clear walk-through opening is narrower. Arch heights are 160, 184, and 144 native pixels respectively. Reverse views use separate generated reverse textures fitted to the same silhouette.

A door module occupies one wall tile. It includes jambs and lintel, with a 0.8-tile-wide, 112-pixel-high leaf. A door rotates open 90° around its persistent hinge. Leave clearance for the open leaf in the adjacent tile. Both states use the same canvas, pivot, hinge, and connection sockets. Do not move the sprite when switching state. There are no intermediate motion frames.

## Seamless floors and the reference grid

Floors **01–10** repeat seamlessly with themselves. This does **not** promise invisible transitions between different materials or from a motif floor into a repeat floor. Floors 11–60 are distinct feature tiles, with no seamless claim.

The supplied `56242.png` was measured at 800×893 pixels. Its tile slot is 160×80, with 6,400 opaque pixels. Its exact diamond raster has row widths `4,8,...,160,...,4,0`: 79 occupied rows followed by one transparent row. This asymmetrical raster phase is deliberate and matches the reference mask with **zero differing pixels**. Do not crop off the last row or infer tile spacing from alpha bounds.

The first ten source textures were made periodic in square UV space with an 18-pixel opposing-edge blend. Opposite UV edges are identical. Pixel-center projection then produces the exact measured diamond mask. Four-by-four layouts have zero uncovered pixels and zero pixels outside the expected combined diamond. The visual repeats are included in `qa/seamless_repeats.png`.

## How this pack and template were made

1. Measured the user-supplied reference's tile dimensions, alpha-equivalent silhouette, row widths, and 2:1 grid. The original game reference was used for style and geometry; it is not copied into the shipped artwork or redistributed in this pack.
2. Generated eight original source atlases with the **built-in imagegen tool**: three floor texture sheets, one front/reverse wall-material sheet, one arch-elevation sheet, one door-leaf sheet, and two scatter sheets. Exact prompts are in `source_art/generation_prompts.json`. The unprocessed generated images are also retained.
3. Extracted full-bleed texture cells and isolated connected sprite components. This avoids cutting props that extend beyond an imperfect generated contact-sheet cell. Alpha was thresholded to a clean binary mask; RGB under fully transparent pixels was cleared. Colors were reduced in four-level increments and sampled with nearest-neighbor filtering.
4. Converted square floor textures into exact reference diamonds. Made the ten repeat textures periodic, then tested them in assembled layouts.
5. Projected the wall, arch, and door textures with deterministic 2.5D geometry. Architecture rotations are real reprojections, not horizontal-flip substitutes. Arches use their generated front silhouette for the shared front/reverse extrusion. Nearby interior colors are used for the extrusion faces so a dark outline is not stretched across the top.
6. Created individual transparent PNGs, atlas rectangles, pivots, connection data, state coverage, labeled sheets, a sample room, and blank guides. Tested counts, uniqueness of floors/props, binary alpha, canvas margins, atlas round trips, floor masks/repeats, door state pivots, arch sockets, and wall joins.

The result matches the measured pixel grid exactly. The artistic style is an original approximation of the supplied grimdark reference. Scatter projection is visually matched generated art rather than analytically verified 3D geometry. This is an engine-neutral PNG pack, **not a native Diablo DT1/DCC package**.

## Reuse the template for another biome

`template/Layout_Template.png` explains the canvas and pivot system. Transparent guide PNGs are supplied for all five asset categories. Guides are drafting aids: remove their colored lines before exporting artwork. `template/biome_template.json` is the editable inventory/layout specification, and `template/catacombs_config.json` records this pack's names and prop sizes. `template/example_room.json` records the placements used in the overview.

1. Copy the entire pack into a new biome working folder. Keep the original pack intact.
2. Copy `template/biome_template.json` to a new configuration file. Replace `biome_name`, the design-name arrays, and, if needed, `scatter_widths_px`. Keep 60 floor names, 5 wall names, 3 arch names, 3 door names, and 40 prop names. Use simple lowercase names with underscores. The current builder deliberately keeps this inventory and the measured geometry fixed.
3. Use `source_art/generation_prompts.json` as a prompt layout template. Change the biome art direction, material choices, and prop lists, while preserving the exact atlas row/column layouts, front/reverse pairing, and transparent backgrounds. Generate original replacement source art with imagegen. Inspect it before proceeding.
4. Put the eight replacement images in a separate `new_source` folder under the **same source filenames** listed below. Do not feed already-projected isometric wall sprites into a front-elevation slot.
5. Run the builder with Python 3.10 or newer, Pillow, and NumPy installed. From the extracted pack folder:

```text
python tools/build_pack.py --source new_source --config my_biome_config.json --out My_New_Biome
```

To reproduce this pack's core sprites, manifests, atlases, and validation using its saved artwork:

```text
python tools/build_pack.py --source source_art --config template/catacombs_config.json --out Rebuilt_Catacombs
```

The builder is offline and does not call an image service. Source names are `floors_01_20.png`, `floors_21_40.png`, `floors_41_60.png`, `wall_materials.png`, `arch_elevations.png`, `door_leaves.png`, `scatter_01_20.png`, and `scatter_21_40.png`. The texture sheets use equal cells: floors 5×4, walls 5×2 (front row, reverse row). Isolated sheets use arches 3×2, door leaves 3×2, and scatter 5×4. Keep transparent objects separated; touching objects can defeat automatic extraction.

6. Inspect the new `qa/validation.json` and every new labeled sheet. The geometry tests passing does not certify that new art depicts the right subject or that new source objects were separated correctly. Inspect repeat layouts at 1× and enlarged with nearest-neighbor scaling. Check doors and arches on a floor with the neighboring walls.
7. The optional `tools/make_previews.py PACK_FOLDER` produces the illustrated room, extra assembly boards, and offline browser. Its showcase arrangement and captions are Catacombs-specific: adapt those presentation choices for a different biome. It is not needed to produce the reusable core asset pack.

## Files and validation evidence

- `sprites/`: 236 individual clean PNG frames.
- `sheets/`: 9 transparent atlases with a small gap between cells.
- `reference_sheets/`: matching labeled inventories.
- `manifest.json`: complete coverage, canvas sizes, pivots, texture rectangles, orientations, states, sockets, hashes, and placement notes.
- `manifest.csv`: convenient flat inventory.
- `qa/validation.json`: machine-readable results. An overall pass covers the listed checks only.
- `qa/seamless_repeats.png`: all ten self-repeat layouts.
- `qa/wall_junctions.png`: assembled runs, corners, T and cross junctions for all five families.
- `qa/arch_wall_alignment.png`: all three arches and four directions with neighboring walls.
- `qa/door_wall_alignment.png`: all door designs, directions, and states with fixed origin/hinge markers.
- `source_art/`: original generated sheets, normalized floor/elevation sources, and exact prompts.
- `template/`: blank layouts, configuration, reusable instructions, and example placements.
- `tools/`: offline deterministic builder and preview utility; requires Pillow and NumPy.
- `SHA256SUMS.txt`: checksums for the packaged files.

Created October 12, 2026. No source files in the separate character or monster workspaces were modified.
