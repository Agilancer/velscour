HARPSICHORD CHROMATIC SAMPLE PACK — C4 through C5

CONTENTS
- Samples/: 13 individually cropped 24-bit stereo WAV samples at 48,000 Hz.
- Harpsichord_C4-C5.sfz: SFZ sampler instrument mapped to MIDI notes 60–72.
- Note_Markers.csv: Time markers for the continuous WAV file.

RENDER DETAILS
- Concert pitch: A4 = 440 Hz, equal temperament.
- GM Harpsichord patch (GM program 7; zero-based program 6) rendered from TimGM6mb SoundFont with FluidSynth.
- MIDI velocities: 100/127, kept consistent across the scale.
- Dry recording: reverb and chorus disabled. No compression, denoising, or added ambience.
- One global level adjustment preserves relative key loudness and leaves 2.5 dB of peak headroom.
- Each note sounds until the render decays below a very low threshold, with an end fade
  only at the near-silent tail.
- Note filenames use Cs/Ds/Fs/etc. for sharps, while Note_Markers.csv uses C#/D# notation.
- The master WAV contains 0.7 s silence after each full decay for easy editing.

SAMPLER IMPORT
Load Harpsichord_C4-C5.sfz into an SFZ-compatible sampler to play the 13-note range,
or drag individual WAV files into your sampler and set each filename's MIDI note as its root pitch.
The one-shot SFZ mapping plays the complete decay, even if the key is released early.

NOTE ABOUT QUALITY
These are digital renders of a sampled GM harpsichord instrument; they are not
new stereo microphone recordings of a physical harpsichord.
