ACOUSTIC GRAND PIANO — TWO-OCTAVE CHROMATIC SAMPLE PACK

NOTES
- Bass octave: C3, C#3, D3, D#3, E3, F3, F#3, G3, G#3, A3, A#3, B3 (MIDI 48-59).
- Treble octave: C4, C#4, D4, D#4, E4, F4, F#4, G4, G#4, A4, A#4, B4 (MIDI 60-71).
- Exactly 24 notes. Middle C is C4, MIDI 60. The upper C5 is deliberately not repeated,
  because C3-B4 provides exactly two chromatic 12-note octaves.
- Equal temperament with A4=440 Hz.

CONTENTS
- Samples/: 24 individual 48,000 Hz, 24-bit stereo PCM WAV files.
- Piano_C3-B4.sfz: 24 mapped MIDI regions, ready for an SFZ-compatible sampler.
- Note_Markers.csv: position, pitch and duration of each note in the separate continuous master WAV.
- Continuous master: Piano_Chromatic_C3_to_B4_48k_24bit.wav (separate download).

RENDERING
- Acoustic Grand Piano: GM program 1 (zero-based program 0) from TimGM6mb.sf2.
- SoundFont played using FluidSynth with 7th-order interpolation.
- MIDI velocity 100/127, consistent between notes.
- No reverb, chorus, dynamics processing, EQ, or artificial stereo widening.
- Keys held until near-inaudible; note-off tails are included and the near-silent ending
  gently faded to prevent clicks.
- Every note is independently recorded with NO note overlap and no competing voices.
- All notes share one global gain adjustment, retaining relative loudness.
- Maximum peak: -2.5 dBFS. The PCM is 24-bit output, but the underlying SoundFont is
  a compact GM sample library, not a new recording from a live acoustic piano.
- 0.7 seconds silence follows each complete note in the continuous master.
- Master duration: 300.550 seconds.

USAGE
Open Piano_C3-B4.sfz with an SFZ sampler, or use the individual note WAVs directly.
Looping is deliberately disabled, so all notes decay naturally and are suited to one-shots.
CSV uses # for sharps and filenames use s to avoid special characters in file paths.
For authentic piano damper behavior with keys released early, an envelope can be added
in your sampler; one_shot playback intentionally lets samples ring in full.

SOURCE AND QUALITY
SoundFont: TimGM6mb.sf2, as bundled on the sound synthesis host.
This is a rendered multi-sample extraction of a GM piano patch (not a physical piano
recording session). It contains one velocity layer at velocity 100 per chromatic note.
