# Overworld and Town biome pack — v1.0

Original muted medieval game art, following the Catacombs pack's 160 × 80 pixel grid. Start with PREVIEW.png and the labeled reference sheets. Game-ready transparent atlases are in sheets/; individually named PNGs are in sprites/.

## Inventory

| Assets | Frames | Contents |
|---|---:|---|
| Floors | 60 | 12 grass, 8 gravel, 12 dirt/mud, 8 stone, 8 concrete, 12 wood; all self-seamless |
| Transitions | 120 | 15 material pairs × 8 shapes |
| Walls | 120 | 6 materials × 16 connectivity forms + 4 directed panels |
| Roofs | 96 | 4 materials × 6 forms × 4 orientations |
| Gable infills | 24 | 6 wall materials × 4 orientations |
| Gateways | 12 | 3 designs × 4 orientations |
| Doors | 40 | 5 designs × 4 orientations × open/closed |
| Windows | 32 | 8 designs × 4 orientations |
| Shop signs | 96 | 12 shops × 4 orientations × plaque/projecting mounts |
| Unlit torches | 32 | 8 designs × 4 orientations |
| General scatter | 40 | Town fixtures, work tools, market goods, rocks and vegetation |
| Trees | 18 | 6 small, 6 medium, 6 large; separately authored designs |
| **Total** | **690** | Some geometrically equivalent directions share identical pixels; manifest records these aliases. |

## Placement

Use nearest-neighbor sampling, straight alpha, and integer screen positions. Do not trim transparent padding without updating the pivot. Every sprite has a canvas size, ground pivot and atlas rectangle in manifest.json and manifest.csv.

For world coordinates (u,v) and height z in pixels:

    x = origin_x + 80*(u-v)
    y = origin_y + 40*(u+v) - z
    sprite_top_left = (x,y) - pivot_px

Floor PNGs are exactly 160 × 80, with 6,400 opaque pixels. Their final row is intentionally transparent to match the original reference grid. Walls are 128 pixels tall and 0.2 tile thick. Four view labels SE, SW, NW, NE mean rotations 0°, 90°, 180°, 270° around world vertical, not rotating a flat PNG. At rotation zero the panel length runs along u. The rotated local front normals are +v, -u, -v, +u respectively. Connectivity bits are NE=1, SE=2, SW=4, NW=8.

Paint floor first, then depth-sort objects by their ground anchors. Place wall windows, plaques and torches over the matching panel, using the same ground anchor and orientation. They have baked mounting heights and visible-face offsets; do not add those heights a second time. Recessed windows are opaque dark recess artwork, not engine wall-cutout masks. For interiors, choose the direction whose visible material face is appropriate. Projecting signs extend perpendicular to the wall; reserve space at corners.

Doors replace one wall panel. Open and closed sprites have the same pivot, sockets, and fixed hinge. They are two states, not an animation sequence. General props and trees have estimated root/ground anchors and footprint hints; adjust collision shapes in the game. Tree silhouettes are single authored isometric views, not four-view turnarounds. Separate sheets/trees.png contains all 18; trees_small.png, trees_medium.png and trees_large.png provide one size class each.

## Terrain transitions and seamless use

The six transition bases are floor 01 grass, 13 gravel, 21 dirt, 22 mud, 33 stone and 41 concrete. Every unordered pair is included: grass–gravel/dirt/mud/stone/concrete; gravel–dirt/mud/stone/concrete; dirt–mud/stone/concrete; mud–stone/concrete; stone–concrete.

Shapes 1–4 split along u or v, with the two material sides reversed. Shapes 5–8 are the four diagonal triangular halves. In square terrain coordinates these supply vertical, horizontal and both diagonal directions; projection maps them into the game's diamond grid. A denotes the first material in the filename; B denotes the second.

All sixty base tiles repeat seamlessly **with themselves**. Different variants do not automatically blend with each other. Transitions target the six named base variants. Follow transition_compatibility.json for allowed neighbors. Edge signatures compare the 158 interior samples of each 160-pixel UV edge; diagonal tips use a one-pixel mixed-color corner tie. Do not treat these eight shapes as a complete 47-tile blob-autotile set: arbitrary concave junctions and every possible road intersection need additional masks. The included qa/transition_example_*.png files demonstrate valid straight and diagonal assemblies for all 15 pairs.

## Roof recipes

The simplest building uses the gable_2x2 or hip_2x2 roof centered over a 2 × 2 tile wall footprint. Its roof has a 0.1-tile overhang, intersects the wall centerline at z=128, and peaks at z=192. A gabled building also needs two matching wall gable infills, placed at the open ends. For a SE roof the ridge runs along u; place SW-oriented infills at u=-1 and u=+1, v=0. Rotate the entire arrangement for other directions. Hip roofs need no infill.

Modular slope pieces run from z=128 to z=192 across one tile. Ridge modules have both outside edges at z=192 and a center peak at z=224. Hip/valley corners connect corresponding 128/192 edges. Match both height and orientation at sockets. Complete 2×2 roofs and the modular ridge recipe are different roof profiles; do not mix them without matching elevations. Roof transparency is the projected surface; back slopes can appear narrow at this camera angle. The preview includes four assembled houses.

## Shops and torch designs

Shop symbols: blacksmith, spells, apothecary, inn, tavern, armorer, fletcher, general goods, stables, bakery, tailor and jeweler. Signs use symbols rather than readable shop names.

Unlit torch designs: wrapped stick, pitch cage, cold bowl, spiked crown, reed bundle, bronze lion, iron cresset and twin sconce. No flames, embers, glow, or baked light pools are included.

## Validation and source provenance

qa/validation.json records the exact floor mask, seamless edge equality, repeat coverage, transition neighbor checks, binary alpha, canvas clearance, atlas round trips, wall joins, roof joins, inventory and door state alignment. This is asset-level validation, not a live engine integration test. Check occlusion and collision in the target game.

Artwork was created with the built-in ImageGen tool. The original 15 sheets and exact prompt set are preserved in source_art/, along with compact normalized source textures. Mechanical projection, alpha cleanup, edge conditioning and atlas packing use the included offline builder. Delivered native floors are 160 × 80 and overlays use compact canvases; generated source resolution was tool-selected, so no measured compute-saving claim is made.

See template/CREATE_NEXT_BIOME.md for the reusable production specification and rebuild command.
