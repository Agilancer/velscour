# Reusable overworld biome specification

Use this pack as the reference artifact for future overworld packs. Preserve the projection, floor mask, pivots, wall height, material phase, naming and atlas contracts unless the next request explicitly changes them. Adapt the palette, vegetation, architecture and shop details to the new biome.

1. Copy this pack to a new output folder. Keep the original intact.
2. Read README.md, grid_spec.json and overworld_config.json. Review PREVIEW.png and the labeled sheets. The config fixes the inventory lengths: 60 floors, 6 walls, 4 roofs, 3 gateways, 5 doors, 8 windows, 12 signs, 8 torches, 40 props and 18 trees.
3. Generate the fifteen source sheets with the built-in ImageGen tool. Reuse source_art/generation_prompts.json as the exact starting prompt set, substituting the new biome. Preserve row/column ordering from the config. Terrain and wall/roof textures are full-bleed panels; isolated objects require real alpha and generous separation. Keep all torch designs unlit unless requested otherwise. Front and back gateway/door silhouettes must agree.
4. Request modest source dimensions and reduce to native scale before projection. Source resolution alone does not establish compute savings. Do not substitute enlarged previews for game assets. Preserve the exact 160×80 floor raster.
5. Update names and transition base indices in the copied config. Eight shapes per unordered pairing are mandatory; with six materials this gives 120 transitions. Preserve a common source texture phase within each pair. Do not rotate texture art to create masks.
6. Keep eighteen separately authored tree designs: six small, six medium, six large. Their scatter sheet is separate from the forty general props. Use the root pivot for depth sorting and estimate collision independently of canopy width.
7. Rebuild with Python 3.10+, Pillow and NumPy, from the root of the copied pack:

       python tools/build_overworld.py --source source_art --config template/overworld_config.json --out ../New_Biome_Pack

   The builder uses no image-generation API. It mechanically derives native sprites, clean/labeled atlases, manifests and numeric checks from the saved art. It does not recreate this pack's editorial preview or prose automatically. Review and replace those for the new biome.
8. Require all qa/validation.json checks to pass. Inspect every category, all four overlay directions, open/closed hinges, tree roots, roof assemblies and repeated terrain at native pixels. Add assembled straight/diagonal examples for every material pair and verify adjacency against the compatibility manifest.
9. Deliver a ZIP containing sprites, atlases, manifests, documentation, source prompts, source art, this reusable spec and offline builder. Record any unavailable angles or states explicitly. Do not claim a personal Codex gallery template is installed unless installation actually succeeds.

## Palette and source rules

Muted earthy medieval fantasy; weathered wood, mortar and stone; readable material differences; consistent upper-left lighting; no ground shadows baked outside isolated cutouts; no labels or grid lines inside game atlases; nearest-neighbor sampling and binary alpha at final scale. Keep source subjects centered and disconnected so component extraction can separate them. The builder's component threshold assumes sources similar to the included sheets: revalidate extraction if generating much smaller sources.

## Acceptance inventory

690 frames in twelve categories. Four directions for all wall-mounted windows, doors, signs and torches. At least eight distinct unlit torch designs. Sixty individually seamless floors. Fifteen material pairs with eight transitions each. Tree sheet has six small, six medium and six large designs. Preserve the JSON pivot/rectangle data and documented duplicate payload aliases.
