"""Offline overworld biome builder. Python 3.10+, Pillow and NumPy."""
from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np
import json,math,hashlib,csv,shutil,argparse,itertools
import pixel_engine as E
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,default=ROOT/'source');ap.add_argument('--out',type=Path,default=ROOT.parents[1]/'output'/'Overworld_Town_Biome_Pack');ap.add_argument('--config',type=Path);args=ap.parse_args()
SRC=args.source;OUT=args.out;OUT.mkdir(parents=True,exist_ok=True)
CATS=['floors','transitions','walls','roofs','gables','gateways','doors','windows','signs','torches','scatter','trees']
for d in [*(f'sprites/{c}' for c in CATS),'sheets','reference_sheets','qa','template','source_art','source_art/normalized','tools']:(OUT/d).mkdir(parents=True,exist_ok=True)
E.SRC=SRC;E.OUT=OUT;E.assets=[];E.images={};E.BIOME='OVERWORLD + TOWN'
FLOORS='olive_meadow,dense_meadow,dry_grass,sparse_grass,rough_field,moss_cover,trampled_verge,wildflower_grass,leaf_litter_grass,damp_grass,straw_grass,clover_grass,fine_gravel,coarse_gravel,limestone_gravel,dark_grit,wheel_worn_gravel,pebble_gravel,muddy_gravel,dusty_gravel,packed_dirt,damp_mud,cracked_clay,cart_rut_earth,red_earth,dusty_earth,mud_puddles,churned_clay,rooty_dirt,sandy_earth,twig_earth,stable_yard,grey_cobbles,irregular_flagstone,limestone_paving,slate_paving,brick_street,granite_setts,moss_pavers,herringbone_brick,rough_concrete,dark_concrete,cracked_concrete,coarse_mortar,damp_concrete,patched_concrete,lime_screed,aggregate_concrete,oak_boards,dark_pine,bleached_boards,cedar_boards,tavern_planks,barn_boards,diagonal_parquet,nailed_decking,repaired_planks,split_boards,workshop_planks,oak_parquet'.split(',')
WALLS=['oak_plaster','pine_siding','fieldstone','dressed_limestone','town_brick','wattle_daub']
ROOFS=['oak_shingles','blue_slate','terracotta','straw_thatch']
GATES=['fieldstone_round','timber_market','limestone_guildhall']
DOORS=['cottage_oak','tavern_tankard','smith_iron','mage_star','stable_pine']
WINDOWS=['square_leaded','roundtop_barred','shuttered_wide','pointed_lancet','round_bullseye','diamond_oak','twin_arch','wide_grille']
SIGNS=['blacksmith','spells','apothecary','inn','tavern','armorer','fletcher','general_goods','stables','bakery','tailor','jeweler']
TORCHES=['wrapped_stick','pitch_cage','cold_bowl','spiked_crown','reed_bundle','bronze_lion','iron_cresset','twin_sconce']
SCATTER='closed_barrel,water_barrel,crate_stack,cloth_crate,grain_sacks,hay_bale,handcart,broken_wheel,village_well,horse_trough,anvil_stump,cold_forge,smith_bellows,tool_rack,axe_stump,firewood_stack,workbench,stone_bench,split_rail_fence,stone_boundary,moss_boulder,fieldstone_cluster,leafy_shrub,thorn_bush,dry_reeds,wildflowers,mushrooms,hollow_stump,fallen_log,sawn_stump,vegetable_basket,market_table,scroll_rack,potion_jars,grain_handmill,water_bucket,rope_and_hook,cart_debris,tiles_and_bricks,arrow_milestone'.split(',')
TREES=['young_apple','young_birch','young_pine','crooked_oak','wind_juniper','dead_thorn','mature_ash','orchard_pear','medium_fir','twin_birch','medium_willow','dead_oak','ancient_oak','tall_elm','old_cedar','scots_pine','ancient_willow','storm_deadwood']
cfg={'biome_name':'Overworld and Town','floor_names':FLOORS,'wall_names':WALLS,'roof_names':ROOFS,'gateway_names':GATES,'door_names':DOORS,'window_names':WINDOWS,'sign_names':SIGNS,'torch_names':TORCHES,'scatter_names':SCATTER,'tree_names':TREES,'transition_materials':{'grass':1,'gravel':13,'dirt':21,'mud':22,'stone':33,'concrete':41}}
if args.config:
    incoming=json.loads(args.config.read_text(encoding='utf-8'))
    for key,value in incoming.items():
        if key.endswith('_names'):assert len(value)==len(cfg[key]),f'Wrong inventory length: {key}'
    cfg.update(incoming)
FLOORS,WALLS,ROOFS,GATES,DOORS,WINDOWS,SIGNS,TORCHES,SCATTER,TREES=[cfg[k] for k in ['floor_names','wall_names','roof_names','gateway_names','door_names','window_names','sign_names','torch_names','scatter_names','tree_names']]
E.WALLS=WALLS;E.BIOME=cfg['biome_name'].upper();E.floor_uv=[];uvs={};qa={'tests':{},'limitations':['Transitions connect only when the edge signatures match; the compatibility manifest lists allowed neighbors.','Generated props and trees are visually matched to the isometric view; their 3D geometry is not analytically reconstructed.','Wall overlays are projected textured reliefs; they do not cut live holes into engine walls.','Only door open/closed states are supplied. No fire, wind, tree or other animation.']}
orient=['SE','SW','NW','NE'];vecs=[(0,-1),(1,0),(0,1),(-1,0)]
def reg(id,cat,name,im,pivot,**kw):return E.register(id,cat,name,im,pivot,**kw)
def normsave(im,name):im.save(OUT/'source_art'/'normalized'/name)
def test(name,passed,**detail):qa['tests'][name]={'pass':bool(passed),**detail}

# All sixty terrain tiles are self-periodic. They are NOT arbitrary mutual blends.
for batch in range(3):
    for j,im in enumerate(E.split_texture(f'terrain_{batch*20+1:02}_{batch*20+20:02}.png',5,4)):
        i=batch*20+j;uv=E.periodic(E.reduce_art(im,(160,160)));E.floor_uv.append(uv);normsave(uv,f'floor_{i+1:02}.png')
        a=reg(f'floor_{i+1:02}_{FLOORS[i]}','floors',FLOORS[i],E.diamond(uv),(80,40),footprint_tiles=[1,1],seamless_self_repeat=True);uvs[a['id']]=np.array(uv)
floor_assets=E.assets.copy()

# Eight UV masks: 4 axis-aligned halves, 4 triangular diagonal halves.
# The same A/B material phase is kept in every mask; art is never rotated.
yy,xx=np.indices((160,160));u=xx/159;v=yy/159
fields=[u-.5,.5-u,v-.5,.5-v,u+v-1,1-u-v,u-v,v-u]
shape_names=['axis_u_A_low','axis_u_A_high','axis_v_A_low','axis_v_A_high','diagonal_A_NW','diagonal_A_SE','diagonal_A_SW','diagonal_A_NE']
materials=cfg['transition_materials'];pair_ids=[];edge_graph={}
def edges(a):return {'u0':a[1:-1,0,:3],'u1':a[1:-1,-1,:3],'v0':a[0,1:-1,:3],'v1':a[-1,1:-1,:3]}
def edgehash(a):return hashlib.sha256(a.tobytes()).hexdigest()[:20]
for (ma,ia),(mb,ib) in itertools.combinations(materials.items(),2):
    A=np.array(E.floor_uv[ia-1]);B=np.array(E.floor_uv[ib-1]);pair=f'{ma}__{mb}';pair_ids.append(pair);entries=[]
    for k,field in enumerate(fields):
        # Taper diagonal feathering to zero at the boundary, allowing diagonal
        # halves to connect to pure material edges. A mathematical corner is
        # not an edge interval; the four endpoint texels are excluded in hashes.
        feather=.055 if k<4 else np.maximum(1e-8,.055*np.minimum(1,12*np.minimum.reduce([u,1-u,v,1-v])))
        weight=np.clip(field/feather+.5,0,1);weight=weight*weight*(3-2*weight)
        col=np.floor(((A[:,:,:3]*(1-weight[:,:,None])+B[:,:,:3]*weight[:,:,None]))/4+.5)*4
        tex=np.dstack([col.clip(0,252).astype(np.uint8),np.full((160,160),255,np.uint8)]);uv=Image.fromarray(tex)
        a=reg(f'transition_{pair}_{k+1:02}_{shape_names[k]}','transitions',pair+' '+shape_names[k],E.diamond(uv),(80,40),pair=pair,material_A=ma,material_B=mb,base_floor_A=floor_assets[ia-1]['id'],base_floor_B=floor_assets[ib-1]['id'],shape=shape_names[k],seamless_self_repeat=False,footprint_tiles=[1,1]);uvs[a['id']]=tex;entries.append(a)
    candidates=[floor_assets[ia-1],floor_assets[ib-1]]+entries
    opposite={'u0':'u1','u1':'u0','v0':'v1','v1':'v0'}
    for a in candidates:
        ae=edges(uvs[a['id']]);key=pair+'/'+a['id'];edge_graph[key]={}
        for side,e in ae.items():
            compatible=[b['id'] for b in candidates if np.array_equal(e,edges(uvs[b['id']])[opposite[side]])]
            edge_graph[key][side]={'signature':edgehash(e),'compatible_neighbors':compatible}
    for a in entries:a['edge_compatibility_key']=pair+'/'+a['id']
(OUT/'transition_compatibility.json').write_text(json.dumps({'convention':'u0 meets neighbor u1; v0 meets neighbor v1; sample order unchanged. Compare 158 edge-interior texels; shared mathematical corner endpoints are excluded. Diagonal corner tips use a one-pixel mixed-color tie.','material_base_floors':materials,'pairs':pair_ids,'edges':edge_graph},indent=2))
test('transition_edge_coverage',all(e['compatible_neighbors'] for a in edge_graph.values() for e in a.values()),pairs=15,shapes_per_pair=8,frames=120,edges_checked=sum(len(v) for v in edge_graph.values()))

E.walltex=[E.reduce_art(im,(80,128)) for im in E.split_texture('building_walls.png',6,2)]
for i,im in enumerate(E.walltex):normsave(im,f'wall_{i%6+1:02}_{"front" if i<6 else "back"}.png')
for s,name in enumerate(WALLS):
    for mask in range(16):
        rr=E.Renderer();E.draw_cells(rr,E.node_cells(mask),s)
        reg(f'wall_{s+1:02}_{name}_{E.nodename(mask)}','walls',name+' '+E.nodename(mask),rr.image(),rr.pivot,wall_set=name,connection_mask=mask,topology=E.nodename(mask).split('_')[0],height_px=128,thickness_tiles=.2,connections=[{'direction':E.DIRS[k],'local_tiles':[vecs[k][0]*.5,vecs[k][1]*.5]} for k in range(4) if mask&(1<<k)])
    for r,di in enumerate(orient):
        rr=E.Renderer();E.draw_cells(rr,{(u,v) for u in range(-5,5) for v in [-1,0]},s,r)
        reg(f'wall_{s+1:02}_{name}_panel_{di}','walls',name+' panel '+di,rr.image(),rr.pivot,wall_set=name,topology='panel',orientation=di,rotation_degrees=r*90,height_px=128,thickness_tiles=.2,sockets_tiles=[E.rot((x,0,0),r)[:2] for x in [-.5,.5]])

# Roof surface mesh. All height values are measured from the ground pivot.
rooftex=[E.periodic(E.reduce_art(im,(160,160))) for im in E.split_texture('roof_materials.png',2,2)]
for i,im in enumerate(rooftex):normsave(im,f'roof_{i+1:02}.png')
def roof_face(rr,pts,tex,r=0,uv=((0,0),(1,0),(0,1)),triangle=False):
    pp=[E.rot(p,r) for p in pts];pn=np.array(pp,float);pn[:,2]/=80;n=np.cross(pn[1]-pn[0],pn[2]-pn[0]);n=n if n[2]>=0 else -n
    shade=float(np.clip(.76+.35*np.dot(n,np.array([-.35,-.15,1]))/(np.linalg.norm(n)+1e-9),.58,1.12))
    rr.quad(pp,tex,uv,shade,True,triangle)
def roof_render(kind,mat,r):
    rr=E.Renderer((512,384),(256,304));tex=rooftex[mat]
    if kind=='slope':roof_face(rr,[(-.5,-.5,128),(.5,-.5,128),(-.5,.5,192)],tex,r,((0,1),(1,1),(0,0)))
    elif kind=='ridge':
        for side in [-1,1]:roof_face(rr,[(-.5,side*.5,192),(.5,side*.5,192),(-.5,0,224)],tex,r,((0,.5),(1,.5),(0,0)))
    elif kind in ['hip_corner','valley_corner']:
        z=128 if kind=='hip_corner' else 192;p0=(-.5,-.5,128);p1=(.5,-.5,z);p2=(.5,.5,192);p3=(-.5,.5,z)
        roof_face(rr,[p0,p1,p2],tex,r,((0,1),(1,1),(1,0)),True);roof_face(rr,[p0,p2,p3],tex,r,((0,1),(1,0),(0,0)),True)
    elif kind=='gable_2x2':
        for side in [-1,1]:roof_face(rr,[(-1.1,side*1.1,121.6),(1.1,side*1.1,121.6),(-1.1,0,192)],tex,r,((0,1.1),(2.2,1.1),(0,0)))
    elif kind=='hip_2x2':
        corners=[(-1.1,-1.1,121.6),(1.1,-1.1,121.6),(1.1,1.1,121.6),(-1.1,1.1,121.6)]
        for k in range(4):roof_face(rr,[corners[k],corners[(k+1)%4],(0,0,192)],tex,r,((0,1.1),(2.2,1.1),(1.1,0)),True)
    return rr
roof_kinds=['slope','ridge','hip_corner','valley_corner','gable_2x2','hip_2x2']
for mat,name in enumerate(ROOFS):
    for kind in roof_kinds:
        for r,di in enumerate(orient):
            rr=roof_render(kind,mat,r);full='2x2' in kind
            reg(f'roof_{mat+1:02}_{name}_{kind}_{di}','roofs',name+' '+kind+' '+di,rr.image(),rr.pivot,roof_material=name,roof_kind=kind,orientation=di,rotation_degrees=r*90,footprint_tiles=[2.2,2.2] if full else [1,1],wall_top_px=128,height_range_px=[121.6,192] if full else [192,224] if kind=='ridge' else [128,192],placement='2x2 roof center on building center' if full else 'module ground pivot on grid; see roof recipes')
for s,name in enumerate(WALLS):
    for r,di in enumerate(orient):
        rr=E.Renderer((384,336),(192,248))
        for depth,tex in [(-.1,E.walltex[s+6]),(.1,E.walltex[s])]:
            rr.quad([E.rot(p,r) for p in [(-1,depth,128),(1,depth,128),(0,depth,192)]],tex,((0,1),(2,1),(1,.5)),.84,True,True)
        reg(f'gable_{s+1:02}_{name}_{di}','gables',name+' gable infill '+di,rr.image(),rr.pivot,wall_set=name,orientation=di,span_tiles=2,base_height_px=128,peak_height_px=192,placement='Use below an open end of a gable_2x2 roof; center on the corresponding outer wall')

gate_src=E.isolated('gateways.png',3,2)
for i,name in enumerate(GATES):
    h=[152,144,176][i];f=E.reduce_art(gate_src[i],(240,h));b=E.reduce_art(gate_src[i+3],(240,h));normsave(f,f'gateway_{i+1}_front.png');normsave(b,f'gateway_{i+1}_back.png')
    for r,di in enumerate(orient):
        rr=E.Renderer((384,336),(192,248));E.elevation(rr,f,b,3,h,r)
        reg(f'gateway_{i+1:02}_{name}_{di}','gateways',name+' '+di,rr.image(),rr.pivot,design=name,orientation=di,rotation_degrees=r*90,span_tiles=3,height_px=h,sockets_tiles=[E.rot((x,0,0),r)[:2] for x in [-1.5,1.5]])

door_src=E.isolated('door_leaves.png',5,2)
for i,name in enumerate(DOORS):
    f=E.reduce_art(door_src[i],(64,112));b=E.reduce_art(door_src[i+5],(64,112));normsave(f,f'door_{i+1}_front.png');normsave(b,f'door_{i+1}_back.png')
    for r,di in enumerate(orient):
        for state in ['closed','open']:
            rr=E.Renderer((320,288),(160,208));style=[0,1,4,3,5][i];E.draw_cells(rr,{(u,v) for u in [-5,4] for v in [-1,0]},style,r);E.draw_cells(rr,{(u,v) for u in range(-5,5) for v in [-1,0]},style,r,z0=112,z1=128)
            E.elevation(rr,f,b,.8,112,r,thickness=.05) if state=='closed' else E.elevation(rr,f,b,.8,112,(r+1)%4,origin=(.4,.4),thickness=.05)
            reg(f'door_{i+1:02}_{name}_{di}_{state}','doors',name+' '+di+' '+state,rr.image(),rr.pivot,design=name,orientation=di,state=state,doorway_span_tiles=1,hinge_tiles=E.rot((-.4,0,0),r)[:2],open_swing_degrees=90,sockets_tiles=[E.rot((x,0,0),r)[:2] for x in [-.5,.5]])

def offset_elevation(rr,im,width,height,r,vdepth,bottom,thick=.035):
    # Reuse the precise extrusion then shift it vertically by the mount height.
    temp=E.Renderer(rr.size,(rr.pivot[0],rr.pivot[1]-bottom));E.elevation(temp,im,im,width,height,r,origin=(0,vdepth),thickness=thick);rr.a=temp.a;rr.depth=temp.depth
def mount_depth(r):
    nx,ny,_=E.rot((0,1,0),r);return .125 if nx+ny>0 else -.125
window_src=E.isolated('windows.png',4,2);winsize=[(40,44),(32,70),(76,44),(32,78),(52,52),(44,50),(60,62),(68,40)]
for i,name in enumerate(WINDOWS):
    w,h=winsize[i];im=E.reduce_art(window_src[i],(w,h));normsave(im,f'window_{i+1:02}.png')
    for r,di in enumerate(orient):
        rr=E.Renderer();bottom=38;offset_elevation(rr,im,w/80,h,r,mount_depth(r),bottom)
        reg(f'window_{i+1:02}_{name}_{di}','windows',name+' '+di,rr.image(),rr.pivot,design=name,orientation=di,overlay=True,wall_anchor_tiles=[0,0],bottom_height_px=bottom,mount_surface_depth_tiles=mount_depth(r),opaque_recess=True)
torch_src=E.isolated('unlit_torches.png',4,2)
for i,name in enumerate(TORCHES):
    h=[62,70,44,64,64,62,66,66][i];w=min(46,max(20,round(torch_src[i].width/torch_src[i].height*h)));im=E.reduce_art(torch_src[i],(w,h));normsave(im,f'torch_{i+1:02}.png')
    for r,di in enumerate(orient):
        rr=E.Renderer();offset_elevation(rr,im,w/80,h,r,mount_depth(r),42,thick=.06)
        reg(f'torch_{i+1:02}_{name}_{di}','torches',name+' '+di,rr.image(),rr.pivot,design=name,orientation=di,overlay=True,unlit=True,bottom_height_px=42,wall_anchor_tiles=[0,0],mount_surface_depth_tiles=mount_depth(r))
sign_src=E.isolated('shop_signs.png',4,3)
for i,name in enumerate(SIGNS):
    im=E.reduce_art(sign_src[i],(52,48));normsave(im,f'sign_{i+1:02}.png')
    for r,di in enumerate(orient):
        for mounting in ['plaque','projecting']:
            rr=E.Renderer();dep=mount_depth(r)
            if mounting=='plaque':offset_elevation(rr,im,.65,48,r,dep,63)
            else:
                # Board perpendicular to wall, extending from its visible face.
                sign=1 if dep>0 else -1;v0=dep+sign*.10;v1=dep+sign*.75;pts=[(0,v0,100),(0,v1,100),(0,v0,52)]
                rr.quad([E.rot(p,r) for p in pts],im,shade=.95)
                metal=E.solidtex((76,68,52))
                for z in [108,110]:rr.quad([E.rot(p,r) for p in [(-.02,dep,z),(.02,dep,z),(-.02,v1,z)]],metal)
                for vv in [v0+sign*.08,v1-sign*.08]:rr.quad([E.rot(p,r) for p in [(-.016,vv,110),(.016,vv,110),(-.016,vv,100)]],metal)
            reg(f'sign_{i+1:02}_{name}_{mounting}_{di}','signs',name+' '+mounting+' '+di,rr.image(),rr.pivot,shop=name,orientation=di,mounting=mounting,overlay=True,wall_anchor_tiles=[0,0],mount_surface_depth_tiles=dep,symbol_only=True)

widths=[58,62,96,104,84,96,152,102,124,136,80,114,108,100,74,106,128,132,148,150,128,92,106,106,78,66,60,84,138,76,72,120,100,80,100,54,76,134,82,72]
for batch in range(2):
    for j,im in enumerate(E.isolated(f'scatter_{batch*20+1:02}_{batch*20+20:02}.png',5,4)):
        i=batch*20+j;w=widths[i];h=min(170,round(w*im.height/im.width));w=round(h*im.width/im.height);im=E.reduce_art(im,(w,h));canvas=Image.new('RGBA',(224,224));canvas.alpha_composite(im,((224-w)//2,208-h));pivot=(112,208-round(w*.15))
        reg(f'scatter_{i+1:02}_{SCATTER[i]}','scatter',SCATTER[i],canvas,pivot,orientation='authored_isometric',placement='estimated visible ground center',footprint_tiles_estimate=[round(w/160,2)]*2)
tree_heights=[112,126,118,104,96,110,208,194,226,216,202,214,316,350,326,352,330,322]
for batch,sizeclass in enumerate(['small','medium','large']):
    for j,im in enumerate(E.isolated(f'trees_{sizeclass}.png',3,2)):
        i=batch*6+j;h=tree_heights[i];w=round(h*im.width/im.height)
        if w>360:w=360;h=round(w*im.height/im.width)
        im=E.reduce_art(im,(w,h));canvas=Image.new('RGBA',(384,448));x=(384-w)//2;y=416-h;canvas.alpha_composite(im,(x,y));pivot=(192,416-max(5,round(w*.055)))
        reg(f'tree_{i+1:02}_{sizeclass}_{TREES[i]}','trees',TREES[i],canvas,pivot,size_class=sizeclass,design=TREES[i],orientation='authored_isometric',authored_height_px=h,authored_width_px=w,ground_anchor='root center estimate',footprint_tiles_estimate=[round(w*.30/160,2)]*2)

assets=E.assets;images=E.images
# Labeled and clean atlases use the same ordered entries.
for cat,cell,cols in [('floors',(164,84),10),('gateways',(388,340),4),('doors',(324,292),4),('windows',(260,260),4),('signs',(260,260),8),('torches',(260,260),4),('scatter',(228,228),8),('trees',(388,452),6),('gables',(388,340),4)]:E.atlas(cat,[a for a in assets if a['category']==cat],cell,cols)
for pair in pair_ids:E.atlas('transitions_'+pair,[a for a in assets if a.get('pair')==pair],(164,84),8)
for name in WALLS:E.atlas('walls_'+name,[a for a in assets if a['category']=='walls' and a['wall_set']==name],(260,260),5)
for name in ROOFS:E.atlas('roofs_'+name,[a for a in assets if a.get('roof_material')==name],(516,388),4)
# Supplemental size-specific tree sheets do not replace the main manifest atlas.
for size in ['small','medium','large']:
    im=Image.new('RGBA',(6*384,448))
    for k,a in enumerate(a for a in assets if a.get('size_class')==size):im.alpha_composite(images[a['id']],(k*384,0))
    im.save(OUT/'sheets'/f'trees_{size}.png')

counts={c:len([a for a in assets if a['category']==c]) for c in CATS};seen={}
for a in assets:
    h=hashlib.sha256(images[a['id']].tobytes()).hexdigest();a['pixel_sha256']=h
    if h in seen:a['pixel_identical_to']=seen[h]
    else:seen[h]=a['id']
manifest={'pack':cfg['biome_name'],'version':'1.0','grid':{'tile_size_px':[160,80],'basis_u_px':[80,40],'basis_v_px':[-80,40],'projection':'2:1 dimetric pixel isometric','screen_formula':'x=origin_x+80*(u-v); y=origin_y+40*(u+v)-z_px','placement':'top-left = projected ground anchor - pivot_px','floor_raster':'row widths 4,8,...,160,...,4,0; 6400 opaque pixels; keep last transparent row','orientation_order':orient,'rotations_degrees':[0,90,180,270],'mask_bits':{'NE':1,'SE':2,'SW':4,'NW':8}},'counts':counts,'total_frames':len(assets),'unique_pixel_payloads':len(seen),'coverage':{'self_seamless_floors':60,'transition_pairs':pair_ids,'transition_shapes':shape_names,'wall_families':WALLS,'wall_pieces_per_family':20,'roof_materials':ROOFS,'roof_shapes':roof_kinds,'gateway_designs':GATES,'door_designs':DOORS,'door_states':['closed','open'],'window_shapes':WINDOWS,'sign_shops':SIGNS,'sign_mounts':['plaque','projecting'],'unlit_torch_designs':TORCHES,'tree_classes':{'small':6,'medium':6,'large':6}},'assets':assets}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
with (OUT/'manifest.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['id','category','file','width','height','pivot_x','pivot_y','orientation','state','size_class'])
    for a in assets:w.writerow([a['id'],a['category'],a['file'],*a['size_px'],*a['pivot_px'],a.get('orientation',''),a.get('state',''),a.get('size_class','')])

# Reference raster, repetitions, saved-atlas identity and complete state coverage.
expected=np.zeros((80,160),bool)
for y in range(79):width=4*min(y+1,79-y);expected[y,(160-width)//2:(160+width)//2]=True
floor_mask_errors=[int(np.count_nonzero((np.array(images[a['id']])[:,:,3]>0)!=expected)) for a in assets if a['category'] in ['floors','transitions']]
test('exact_floor_raster',not any(floor_mask_errors),tiles_checked=len(floor_mask_errors),mismatched_pixels=sum(floor_mask_errors))
errs=[max(int(np.abs(a[:,0,:3].astype(int)-a[:,-1,:3]).max()),int(np.abs(a[0,:,:3].astype(int)-a[-1,:,:3]).max())) for a in [uvs[a['id']] for a in floor_assets]]
test('base_floor_periodicity',not any(errs),materials_checked=60,maximum_opposite_edge_error=max(errs))
field=Image.new('RGBA',(680,360));tile=images[floor_assets[0]['id']]
for iu in range(4):
    for iv in range(4):field.alpha_composite(tile,(340+80*(iu-iv)-80,50+40*(iu+iv)-40))
yy,xx=np.indices((360,680));wx=(xx+.5-340)/80;wy=(yy+1-50)/40;uu=(wx+wy)/2;vv=(wy-wx)/2;exp=(uu>=-.5)&(uu<3.5)&(vv>=-.5)&(vv<3.5);got=np.array(field)[:,:,3]>0
test('repeat_field_mask',np.array_equal(exp,got),repeat_size=[4,4],uncovered_pixels=int(np.count_nonzero(exp&~got)),extra_pixels=int(np.count_nonzero(got&~exp)))
atlas_cache={};wrong=[]
for a in assets:
    info=a['atlas'];path=info['file']
    if path not in atlas_cache:atlas_cache[path]=Image.open(OUT/path).convert('RGBA')
    x,y,w,h=info['rect_px']
    if atlas_cache[path].crop((x,y,x+w,y+h)).tobytes()!=images[a['id']].tobytes():wrong.append(a['id'])
test('atlas_roundtrip',not wrong,frames_checked=len(assets),mismatches=wrong)
test('binary_alpha',all(set(np.unique(np.array(im)[:,:,3])).issubset({0,255}) for im in images.values()),frames_checked=len(assets))
clipped=[a['id'] for a in assets if a['category'] not in ['floors','transitions'] and (a['alpha_bounds_px'][0]==0 or a['alpha_bounds_px'][1]==0 or a['alpha_bounds_px'][2]==a['size_px'][0] or a['alpha_bounds_px'][3]==a['size_px'][1])]
test('canvas_margins',not clipped,clipped_candidates=clipped)
test('unique_base_designs',all(len({a['pixel_sha256'] for a in assets if a['category']==cat})==n for cat,n in [('floors',60),('scatter',40),('trees',18)]),floors=60,scatter=40,trees=18)
door_ok=[]
for name in DOORS:
    for di in orient:
        pair=[a for a in assets if a['category']=='doors' and a['design']==name and a['orientation']==di];door_ok.append(len(pair)==2 and all(pair[0][k]==pair[1][k] for k in ['size_px','pivot_px','hinge_tiles','sockets_tiles']))
test('door_state_alignment',all(door_ok),pairs_checked=len(door_ok),fixed_fields=['canvas','pivot','hinge','sockets'])
wall_errors=[]
for s,name in enumerate(WALLS):
    for r,di in enumerate(orient):
        a=next(a for a in assets if a['id']==f'wall_{s+1:02}_{name}_panel_{di}');field=Image.new('RGBA',(512,384));o=(256,240);u,v,_=E.rot((1,0,0),r)
        for cu,cv in sorted([(0,0),(u,v)],key=lambda x:sum(x)):field.alpha_composite(images[a['id']],(round(o[0]+80*(cu-cv)-128),round(o[1]+40*(cu+cv)-192)))
        rr=E.Renderer((512,384),o);E.draw_cells(rr,{(u,v) for u in range(-5,15) for v in [-1,0]},s,r);wall_errors.append(int(np.count_nonzero((np.array(field)[:,:,3]>0)!=(rr.a[:,:,3]>0))))
test('wall_join_raster',not any(wall_errors),joins_checked=24,silhouette_mismatch_pixels=sum(wall_errors))
test('coverage_counts',counts=={'floors':60,'transitions':120,'walls':120,'roofs':96,'gables':24,'gateways':12,'doors':40,'windows':32,'signs':96,'torches':32,'scatter':40,'trees':18},counts=counts,total=len(assets))
# Adjacent roof sockets are derived independently from the documented profiles.
test('roof_socket_heights',128+64==192 and 192+64*.5==224 and 192-64*1==128,slope_low=128,slope_high=192,ridge_edge=192,ridge_peak=224,complete_roof_wall_intersection=128,complete_roof_peak=192)
roof_join_errors=[]
for mat,name in enumerate(ROOFS):
    for r,di in enumerate(orient):
        canvas=Image.new('RGBA',(720,480));origin=(360,360)
        a=next(a for a in assets if a['id']==f'roof_{mat+1:02}_{name}_slope_{di}')
        for offset in [0,1]:
            du,dv,_=E.rot((offset,0,0),r)
            canvas.alpha_composite(images[a['id']],(round(origin[0]+80*(du-dv)-a['pivot_px'][0]),round(origin[1]+40*(du+dv)-a['pivot_px'][1])))
        rr=E.Renderer(canvas.size,origin)
        roof_face(rr,[(-.5,-.5,128),(1.5,-.5,128),(-.5,.5,192)],rooftex[mat],r,((0,1),(2,1),(0,0)))
        roof_join_errors.append(int(np.count_nonzero((np.array(canvas)[:,:,3]>0)!=(rr.a[:,:,3]>0))))
test('roof_join_raster',not any(roof_join_errors),joins_checked=16,silhouette_mismatch_pixels=sum(roof_join_errors))
qa['overall_pass']=all(t['pass'] for t in qa['tests'].values());(OUT/'qa'/'validation.json').write_text(json.dumps(qa,indent=2))
cfg['source_layouts']={'terrain_01_20':'5x4 fullbleed','terrain_21_40':'5x4 fullbleed','terrain_41_60':'5x4 fullbleed','building_walls':'6x2 fullbleed; exterior then interior','roof_materials':'2x2 fullbleed','gateways':'3x2 isolated; front then back','door_leaves':'5x2 isolated; front then back','windows':'4x2 isolated','shop_signs':'4x3 isolated','unlit_torches':'4x2 isolated','scatter_01_20':'5x4 isolated','scatter_21_40':'5x4 isolated','trees_small':'3x2 isolated','trees_medium':'3x2 isolated','trees_large':'3x2 isolated'}
(OUT/'template'/'overworld_config.json').write_text(json.dumps(cfg,indent=2));(OUT/'template'/'grid_spec.json').write_text(json.dumps(manifest['grid'],indent=2))
for p in SRC.glob('*.png'):shutil.copy2(p,OUT/'source_art'/p.name)
for name in ['build_overworld.py','pixel_engine.py','inspect_sources.py']:
    if (ROOT/name).resolve()!=(OUT/'tools'/name).resolve():shutil.copy2(ROOT/name,OUT/'tools'/name)
if (ROOT/'generation_prompts.json').exists():shutil.copy2(ROOT/'generation_prompts.json',OUT/'source_art'/'generation_prompts.json')
print(json.dumps({'out':str(OUT),'counts':counts,'total':len(assets),'qa_pass':qa['overall_pass'],'failed_tests':[k for k,v in qa['tests'].items() if not v['pass']]}))
