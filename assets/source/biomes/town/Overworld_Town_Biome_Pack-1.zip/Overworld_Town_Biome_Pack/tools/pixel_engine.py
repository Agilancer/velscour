from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import numpy as np
import math
from inspect_sources import components
NEAREST=Image.Resampling.NEAREST
DIRS=['NE','SE','SW','NW']
assets=[]
images={}
BIOME='Overworld and Town'
def clean(im):
    a=np.array(im.convert('RGBA')).copy(); a[:,:,3]=np.where(a[:,:,3]>=128,255,0); a[a[:,:,3]==0,:3]=0
    return Image.fromarray(a)

def reduce_art(im,size):
    im=clean(im.resize(size,NEAREST)); a=np.array(im);a[:,:,:3]=(a[:,:,:3]//4)*4
    return Image.fromarray(a)

def split_texture(name,cols,rows):
    im=Image.open(SRC/name).convert('RGBA'); w,h=im.size
    return [im.crop((round(c*w/cols)+3,round(r*h/rows)+3,round((c+1)*w/cols)-3,round((r+1)*h/rows)-3)) for r in range(rows) for c in range(cols)]

def isolated(name,cols,rows):
    im=Image.open(SRC/name).convert('RGBA'); a=np.array(im); w,h=im.size; cs=components(a[:,:,3]>=128); groups={i:[] for i in range(cols*rows)}
    mains={}
    for c in cs:
        x,y=c['center']; i=min(rows-1,int(y*rows/h))*cols+min(cols-1,int(x*cols/w))
        if i not in mains and c['n']>800:mains[i]=c
    assert len(mains)==cols*rows,(name,mains.keys())
    for c in cs:
        if c['n']<6:continue
        x,y=c['center']
        def dist(m):
            x0,y0,x1,y1=m['box'];return max(x0-x,0,x-x1)**2+max(y0-y,0,y-y1)**2
        i=min(mains,key=lambda k:dist(mains[k]));groups[i].append(c)
    result=[]
    for i in range(cols*rows):
        b=np.zeros_like(a)
        for c in groups[i]:
            for y,x0,x1 in c['runs']:b[y,x0:x1]=a[y,x0:x1]
        obj=clean(Image.fromarray(b));obj=obj.crop(obj.getbbox());result.append(obj)
    return result

def periodic(im,band=18):
    a=np.array(im.convert('RGB'),dtype=float); n=a.shape[0]
    for axis in (1,0):
        for d in range(band):
            weight=(1-d/band)**2
            if axis==1:
                l=a[:,d].copy();r=a[:,-1-d].copy();avg=(l+r)/2;a[:,d]=l*(1-weight)+avg*weight;a[:,-1-d]=r*(1-weight)+avg*weight
            else:
                l=a[d].copy();r=a[-1-d].copy();avg=(l+r)/2;a[d]=l*(1-weight)+avg*weight;a[-1-d]=r*(1-weight)+avg*weight
    return Image.fromarray((np.round(a/4)*4).clip(0,252).astype(np.uint8)).convert('RGBA')

def diamond(im):
    tex=np.array(im); y,x=np.indices((80,160)); u=((x+.5-80)/80+(y+1)/40)/2;v=((y+1)/40-(x+.5-80)/80)/2
    valid=(u>=0)&(u<1)&(v>=0)&(v<1);out=np.zeros((80,160,4),np.uint8)
    out[valid]=tex[(v[valid]*tex.shape[0]).astype(int),(u[valid]*tex.shape[1]).astype(int)];out[:,:,3]=valid*255
    return Image.fromarray(out)

def register(id,category,name,im,pivot,**kw):
    im=clean(im); rel=f'sprites/{category}/{id}.png';im.save(OUT/rel)
    a={'id':id,'category':category,'name':name,'file':rel,'size_px':list(im.size),'pivot_px':list(pivot),'alpha_bounds_px':list(im.getbbox()),'filter':'nearest','alpha':'binary','animation':False,**kw}
    assets.append(a);images[id]=im;return a

def font(size=14):
    p=Path('C:/Windows/Fonts/consola.ttf')
    return ImageFont.truetype(str(p),size) if p.exists() else ImageFont.load_default()

def title(im,text,sub=''):
    text=text.replace('CATACOMBS',BIOME.upper())
    d=ImageDraw.Draw(im);d.text((22,15),text,font=font(25),fill='#e3d0aa');d.text((22,47),sub,font=font(13),fill='#a9aaa7')

def rot(p,r):
    u,v,z=p
    for _ in range(r):u,v=-v,u
    return (u,v,z)

class Renderer:
    def __init__(self,size=(256,256),pivot=(128,192)):
        self.size=size;self.pivot=pivot;self.a=np.zeros((size[1],size[0],4),np.uint8);self.depth=np.full((size[1],size[0]),-1e9)
    def quad(self,points,texture,uv=((0,0),(1,0),(0,1)),shade=1,repeat=False,triangle=False):
        p=np.array(points,float); q=np.array([[self.pivot[0]+80*(u-v),self.pivot[1]+40*(u+v)-z] for u,v,z in p]);a=q[1]-q[0];b=q[2]-q[0]
        det=a[0]*b[1]-a[1]*b[0]
        if abs(det)<1e-8:return
        fourth=q[1]+q[2]-q[0];xs=np.r_[q[:,0],fourth[0]];ys=np.r_[q[:,1],fourth[1]]
        x0=max(0,int(np.floor(xs.min())));x1=min(self.size[0],int(np.ceil(xs.max())));y0=max(0,int(np.floor(ys.min())));y1=min(self.size[1],int(np.ceil(ys.max())))
        if x0>=x1 or y0>=y1:return
        yy,xx=np.indices((y1-y0,x1-x0));dx=xx+x0+.5-q[0,0];dy=yy+y0+.5-q[0,1];s=(dx*b[1]-dy*b[0])/det;t=(a[0]*dy-a[1]*dx)/det
        valid=(s>=-1e-8)&(t>=-1e-8)&(s<1-1e-8)&(t<1-1e-8)
        if triangle:valid &= (s+t<1+1e-8)
        tex=np.asarray(texture);uv=np.array(uv,float);uu=uv[0,0]+s*(uv[1,0]-uv[0,0])+t*(uv[2,0]-uv[0,0]);vv=uv[0,1]+s*(uv[1,1]-uv[0,1])+t*(uv[2,1]-uv[0,1])
        if repeat:uu%=1;vv%=1
        tx=np.clip((uu*tex.shape[1]).astype(int),0,tex.shape[1]-1);ty=np.clip((vv*tex.shape[0]).astype(int),0,tex.shape[0]-1);pixels=tex[ty,tx].copy();pixels[:,:,:3]=(pixels[:,:,:3].astype(float)*shade).clip(0,255).astype(np.uint8)
        dep=p[:,0]+p[:,1]+p[:,2]/80;z=dep[0]+s*(dep[1]-dep[0])+t*(dep[2]-dep[0]); valid&=(pixels[:,:,3]>127)&(z>=self.depth[y0:y1,x0:x1]-1e-7)
        self.a[y0:y1,x0:x1][valid]=pixels[valid];self.depth[y0:y1,x0:x1][valid]=z[valid]
    def image(self):return Image.fromarray(self.a)

def node_cells(mask):
    cells=set((u,v) for u in [-1,0] for v in [-1,0])
    if mask&1:cells.update((u,v) for u in [-1,0] for v in range(-5,-1))
    if mask&2:cells.update((u,v) for u in range(1,5) for v in [-1,0])
    if mask&4:cells.update((u,v) for u in [-1,0] for v in range(1,5))
    if mask&8:cells.update((u,v) for u in range(-5,-1) for v in [-1,0])
    return cells

def draw_cells(rend,cells,style,rotation=0,z0=0,z1=128):
    front=walltex[style];back=walltex[style+len(WALLS)];top=floor_uv[[48,49,32,34,36,50][style]]
    for iu,iv in cells:
        u0,u1=iu/10,(iu+1)/10;v0,v1=iv/10,(iv+1)/10
        def q(p,tex,uv,shade=1):rend.quad([rot(x,rotation) for x in p],tex,uv,shade,True)
        q([(u0,v0,z1),(u1,v0,z1),(u0,v1,z1)],top,((u0+.5,v0+.5),(u1+.5,v0+.5),(u0+.5,v1+.5)),1.14)
        for du,dv in [(1,0),(-1,0),(0,1),(0,-1)]:
            if (iu+du,iv+dv) in cells:continue
            if du:
                u=u1 if du>0 else u0;p=[(u,v0,z1),(u,v1,z1),(u,v0,z0)];uv=((v0+.5,1-z1/128),(v1+.5,1-z1/128),(v0+.5,1-z0/128))
            else:
                v=v1 if dv>0 else v0;p=[(u0,v,z1),(u1,v,z1),(u0,v,z0)];uv=((u0+.5,1-z1/128),(u1+.5,1-z1/128),(u0+.5,1-z0/128))
            nu,nv,_=rot((du,dv,0),rotation); shade=.72 if nu>0 else .94 if nv>0 else .82
            q(p,front if du+dv>0 else back,uv,shade)

def nodename(mask):
    count=mask.bit_count(); typ='pillar' if count==0 else 'end' if count==1 else 'straight' if mask in (5,10) else 'corner' if count==2 else 'tee' if count==3 else 'cross'
    return typ+('_'+'_'.join(DIRS[i] for i in range(4) if mask&(1<<i)) if mask else '')

def solidtex(rgb):return np.array([[list(rgb)+[255]]],np.uint8)

def elevation(rend,front,back,width,height,rotation=0,origin=(0,0),thickness=.2):
    # Alpha-cut elevation extruded to a physical, grid-aligned slab.
    front=np.array(front);back=np.array(back).copy()
    # The generated reverse can differ in silhouette. Extend its nearest valid
    # colors before imposing the shared front mask; never turn empty RGB into
    # opaque black streaks on the rear face.
    valid=back[:,:,3]>127; target=front[:,:,3]>127
    while np.any(target & ~valid):
        acc=np.zeros(back.shape[:2]+(3,),float);count=np.zeros(valid.shape,float)
        for dy,dx in [(0,1),(0,-1),(1,0),(-1,0)]:
            vv=np.roll(valid,(dy,dx),(0,1));rgb=np.roll(back[:,:,:3],(dy,dx),(0,1))
            if dy==1:vv[0]=False
            if dy==-1:vv[-1]=False
            if dx==1:vv[:,0]=False
            if dx==-1:vv[:,-1]=False
            acc+=rgb*vv[:,:,None];count+=vv
        fill=(~valid)&(count>0)
        if not np.any(fill):break
        back[fill,:3]=(acc[fill]/count[fill,None]).astype(np.uint8);valid[fill]=True
    back[:,:,3]=front[:,:,3];back[front[:,:,3]==0,:3]=0
    h,w=front.shape[:2];u0=-width/2;du=width/w;dz=height/h
    def world(u,v,z):return rot((u+origin[0],v+origin[1],z),rotation)
    for v,tex in [(-thickness/2,back),(thickness/2,front)]:
        normal=rot((0,1 if v>0 else -1,0),rotation);shade=.98 if normal[1]>0 else .76
        rend.quad([world(u0,v,height),world(-u0,v,height),world(u0,v,0)],tex,shade=shade)
    mask=front[:,:,3]>127
    def contour_color(x,y):
        patch=front[max(0,y-4):min(h,y+5),max(0,x-4):min(w,x+5)]
        pix=patch[patch[:,:,3]>127,:3]
        if len(pix)==0:return np.array([60,56,48])
        # A dark one-pixel outline is not the material of an entire side face.
        # Sample the nearby interior stone/wood instead of stretching the outline.
        light=pix.mean(axis=1);pix=pix[light>=np.quantile(light,.45)]
        return np.median(pix,axis=0)
    # Compress straight runs on contour to keep the extrusion lightweight.
    for x in range(w+1):
        left=mask[:,x-1] if x else np.zeros(h,bool);right=mask[:,x] if x<w else np.zeros(h,bool);edge=left^right
        for y in np.where(edge)[0]:
            c=contour_color(x-1 if left[y] else x,y);u=u0+x*du;zt=height-y*dz
            rend.quad([world(u,-thickness/2,zt),world(u,thickness/2,zt),world(u,-thickness/2,zt-dz)],solidtex((c*.65).astype(int)),shade=1)
    for y in range(h+1):
        above=mask[y-1] if y else np.zeros(w,bool);below=mask[y] if y<h else np.zeros(w,bool);edge=above^below
        # Only top-facing silhouette edges are seen from above.
        for x in np.where(edge & below)[0]:
            c=contour_color(x,y);u=u0+x*du;z=height-y*dz
            rend.quad([world(u,-thickness/2,z),world(u+du,-thickness/2,z),world(u,thickness/2,z)],solidtex((c*1.13).clip(0,252).astype(int)))

def atlas(category,items,cell,cols):
    cw,ch=cell;rows=math.ceil(len(items)/cols);im=Image.new('RGBA',(cols*cw,rows*ch));ref=Image.new('RGB',(cols*cw,rows*(ch+35)+80),'#171c1e');title(ref,'CATACOMBS / '+category.upper(),f'{len(items)} sprites | native 1x pixels | grid 160 x 80 | labels are not in transparent sheets')
    d=ImageDraw.Draw(ref)
    for k,a in enumerate(items):
        x=(k%cols)*cw;y=(k//cols)*ch;img=images[a['id']];off=((cw-img.width)//2,(ch-img.height)//2);im.alpha_composite(img,(x+off[0],y+off[1]));a['atlas']={'file':f'sheets/{category}.png','rect_px':[x+off[0],y+off[1],img.width,img.height]}
        ry=80+(k//cols)*(ch+35);rx=(k%cols)*cw;d.rectangle((rx,ry,rx+cw-1,ry+ch+34),outline='#303b3e');ref.paste(img,(rx+off[0],ry+off[1]),img)
        label=a['id'].replace('scatter_','').replace('floor_','').replace('wall_','').replace('arch_','').replace('door_','')
        if len(label)>cw//7:
            cutoff=label.rfind('_',0,cw//7); cutoff=cutoff if cutoff>0 else cw//7;d.text((rx+5,ry+ch+2),label[:cutoff],font=font(11),fill='#c9c3b5');d.text((rx+5,ry+ch+16),label[cutoff:].strip('_'),font=font(11),fill='#c9c3b5')
        else:d.text((rx+5,ry+ch+7),label,font=font(11),fill='#c9c3b5')
    im.save(OUT/'sheets'/f'{category}.png');ref.save(OUT/'reference_sheets'/f'{category}_labeled.png')