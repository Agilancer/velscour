# Castle Keep biome pack

Original Castle Keep floors, scatter, and wall material artwork with the Catacombs 160×80 isometric contract. The five wall-family component silhouettes, three arch geometries, and three door geometries intentionally retain the Catacombs source geometry and pivots for renderer compatibility; the generated Castle Keep material panels texture their surfaces.

Inventory: 60 floors (10 tagged seamless), 100 wall pieces across 5 families and all 16 masks, 3 arch designs × 4 directions, 3 doors × 4 directions × open/closed, and 40 scatter props. All floor and prop pixels are Castle Keep generated; topology and pivots remain template-compatible. The runtime wall hanging supplement uses 16 designs with two separately authored front-facing angles.

Import with `python tools/process_assets.py biomes castle_keep`. The generated pack uses nearest-neighbor sampling and the exact Catacombs floor diamond mask. See the pack manifest for frame sizes, pivots, geometry, and checksums.
