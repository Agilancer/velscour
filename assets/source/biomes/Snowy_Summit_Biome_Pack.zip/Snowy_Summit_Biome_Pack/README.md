# Snowy Summit

Fresh snowy overworld biome art for VELSCOUR. Created from scratch with Sol, using the public repository's biome sheet guide and Grim Nocturne art bible. No artwork from the earlier Snowy_Summit attempt is used.

Start with `previews/snowy_summit_scene.png` and `reference_sheets/scatter.png`. The scene is an assembly of the delivered sprites, not an in-game screenshot.

## Contents

- **236 transparent PNG sprites:** 60 floors, 100 wall pieces (five families, sixteen connection masks and four directed panels each), 12 arches, 24 open/closed doors, and 40 scatter pieces.
- Floors use the documented **160 x 80, 2:1 dimetric** geometry. Walls are 128px tall before the game importer's height adjustment. All sprites have pivots and geometry metadata in `manifest.json`.
- Nine normalized PNG source sheets in `sheets/`, plus `names.json`, in the repository guide's format. Source sheets retain magenta object backgrounds; extracted sprites have clean transparency. Prop sheet guide borders are excluded during extraction.
- `runtime/snowy_summit/`: prepared `floors.webp`, `walls.webp`, `scatter.webp`, and `pack.json`, generated successfully with the repository's unmodified `tools/biomepack.py`.
- Four reference contact sheets, an assembled scene preview, and machine-readable QA reports in `qa/`.
- Rebuild tools in `tools/` and `integration.json` listing walk-over and light props.

## Visual direction

Wind-packed snow, powder over gravel, fractured slate, frost-covered paving, glacier ice, snowy granite cliffs, and weathered summit shrine masonry. Natural scatter includes snow-capped boulders, ice spires, cairns, fallen timber, and rock fragments. Expedition scatter includes a sled, crates, bedroll, rope, tools, lanterns, and mountain boots. Small shrine remnants provide landmarks.

## Using the prepared runtime files

1. Copy `runtime/snowy_summit/` to the game's `assets/tiles/snowy_summit/`.
2. In `src/data/biomes.js`, point the intended overworld biome's `ART` entry at `{ pack: 'snowy_summit' }`.
3. Add the light names in `integration.json` to `LIT` in `src/world/dungeon.js`.
4. Add the walk-over names in `integration.json` to `WALK_OVER` in `tools/biomepack.py` before any future imports. The supplied runtime files already contain those collision flags.
5. Run the repository's normal data, pack, wall, and biome survey checks, then inspect gameplay and screenshots. Overworld layout and spawn rules still belong to the game; this asset package does not edit the repository's biome definitions.

The entire folder can also be zipped, with `Snowy_Summit_Biome_Pack/manifest.json` at its root, and placed at `assets/source/biomes/Snowy_Summit_Biome_Pack.zip` for the repository importer. Do not place the source pack ZIP in `assets/tiles`.

## Rebuilding locally

Requires Python 3.10+, Pillow, NumPy, and SciPy. No game-dev package or external art service is required to rebuild the delivered artwork.

From this folder:

```bash
python tools/build_snowy_summit.py
python tools/validate_geometry.py
python tools/prepare_runtime.py
```

The builder crops, keys, samples, and projects the painted source sheets. It is an independent local implementation of the documented geometry. The original Catacombs ZIP's builder was unavailable through the connected file API; it was not used. The supplied nine sheets and names JSON remain suitable for the repository's own `chatgpt_biome.py` preparation workflow when that ZIP is present.

## Validation and limits

Passed: 236 inventory entries and unique IDs; PNG sizes and nonempty content; binary alpha; no magenta key color in sprite pixels; exact floor diamond masks; opposite-edge equality for all ten base textures; all sixteen wall connection masks per family; all door states and directions. Twenty directed wall panel aliases intentionally share pixels with straight connection nodes, as declared in the manifest.

All **136 architecture sprites** were checked against the actual upstream importer's native geometry: **zero opaque pixels outside the declared geometry**. The upstream importer successfully produced all runtime atlases and expected category counts. Its 1.6x height adjustment changes overlap visibility; the recorded source-visibility counts at that scale are not native geometry failures.

No game runtime or gameplay test was performed. Collision/light registration and overworld distribution should be reviewed in the destination game. No remote repository files were changed.

## Sources

- Biome workflow: https://github.com/Agilancer/velscour/blob/main/docs/CHATGPT_BIOME_SPRITES.md
- Art bible: https://github.com/Agilancer/velscour/blob/main/docs/art_style/01_VELSCOUR_ART_BIBLE.md
- Importer: https://github.com/Agilancer/velscour/blob/main/tools/biomepack.py

The new art was generated for this package. The included upstream importer remains the project's source code; its use is subject to the repository's licensing terms. No third-party asset pack art is included.
