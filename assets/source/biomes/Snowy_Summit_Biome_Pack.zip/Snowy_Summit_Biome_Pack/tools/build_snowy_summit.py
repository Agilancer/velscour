#!/usr/bin/env python3
"""Project freshly painted biome sheets into VELSCOUR's documented 160x80 contract.

This standalone projection builder does not require game-dev or network access.
It is an independent implementation, not the Catacombs ZIP's unavailable builder.
"""
from pathlib import Path
from collections import Counter
import hashlib, json, math, shutil, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT
DIRS={'NE':(0,-1),'SE':(1,0),'SW':(0,1),'NW':(-1,0)}
BITS={'NE':1,'SE':2,'SW':4,'NW':8}
NEAR=Image.Resampling.NEAREST
BASES=['windpacked_snow','powdered_gravel','snowy_slate_flags','glacier_ice','granite_scree','frosted_cobbles','compact_snow_path','snow_seamed_shale','summit_shrine_paving','blue_snow_crust']
FEATURES=['wind_ripples','exposed_pebbles','fractured_slab','branching_ice_crack','exposed_rock','worn_compass_notch','bootprints','shale_fissure','copper_inlay','paw_tracks','dry_alpine_grass','slate_chips','broken_flag_corner','trapped_stone','scree_drift','cobble_crack','sled_groove','coal_fracture','carved_knot','frozen_puddle','exposed_flat_stone','small_bones','chipped_flagstone','frost_star','alpine_tuft','frozen_drain','runner_tracks','shale_splinters','weathered_sun','fallen_feather','buried_crimson_stain','antler_fragment','shallow_depression','opaque_frost','scree_frost_cracks','copper_plate','wind_swirl','cairn_fragments','wind_knot_paving','hare_tracks','drift_lip','buried_buckle','displaced_slate','trapped_branches','thawed_scree','drain_grate','crossed_bootprints','quartz_seam','shattered_shrine_tile','hoof_impressions']
WALLS=['snow_capped_granite','frost_niche_slate','summit_shrine_ashlar','ice_bound_shale','ruined_alpine_drywall']
ARCHES=['granite_passage','summit_shrine_portal','slate_pass_gateway']
DOORS=['larch_storm_door','frozen_iron_gate','summit_shrine_door']
PROPS=['snow_capped_boulder','frost_split_boulder','fallen_slate_slab','snowy_rock_cairn','slate_chip_scatter','fallen_alpine_branch','glacier_ice_spire','broken_ice_chunk','expedition_strongbox','summit_floor_lantern','snowbound_votive_candles','hooked_lantern_stand','mountain_shrine_altar','trail_cairn_pedestal','kneeling_pilgrim_stone','standing_stone_sentinel','fallen_snowy_pine','granite_column_stump','snowy_boulder_rubble','notched_trail_marker','snowbound_supply_crate','shattered_expedition_crate','abandoned_summit_sled','frozen_shrine_basin','frosted_iron_brazier','summit_torch_stand','glacier_crystal_cluster','fur_bedroll','snowy_timber_heap','climbing_rope_and_pitons','leaning_wind_knot_slab','alpine_menhir','jagged_slate_spur','stone_owl_idol','frosted_offering_bowl','summit_warning_bell','broken_timber_fence','snowbound_bench','climbing_pick_and_map','mountain_boots_and_belt']
WIDTHS=[136,136,122,86,98,130,54,78,86,38,50,58,136,76,68,88,106,80,122,64,128,134,148,100,58,60,84,80,112,70,80,58,90,58,50,100,110,126,70,74]
WALK={4,5,10,27,28,29,34,36,38,39}
LIGHT={9,10,11,24,25}
assets=[]

def cells(n,cols,rows,size):
    paths=sorted((ROOT/'sheets').glob(str(n)+'_*'))
    if not paths: raise FileNotFoundError('Missing sheet '+str(n))
    im=Image.open(paths[0]).convert('RGBA').resize(size,NEAR)
    out=[]
    for r in range(rows):
        for c in range(cols):
            box=(round(c*size[0]/cols),round(r*size[1]/rows),round((c+1)*size[0]/cols),round((r+1)*size[1]/rows))
            out.append(im.crop(box))
    return out

def crop_texture(im,fraction=.015):
    # Atlas normalization only: remove accidental cell-boundary edge pixels.
    x,y=round(im.width*fraction),round(im.height*fraction)
    return im.crop((x,y,im.width-x,im.height-y)).convert('RGB')

def isolate(im):
    a=np.array(im);r,g,b=[a[:,:,i].astype(int) for i in range(3)]
    key=((r>125)&(b>125)&(g<.58*np.minimum(r,b))&(abs(r-b)<95)) | ((r-g>18)&(b-g>18)&(abs(r-b)<100))
    solid=(a[:,:,3]>=128)&~key
    solid[:3]=False;solid[-3:]=False;solid[:,:3]=False;solid[:,-3:]=False
    lab,count=ndimage.label(solid,structure=np.ones((3,3)))
    if not count: raise ValueError('Object cell is empty')
    sizes=np.bincount(lab.ravel());sizes[0]=0
    main=int(sizes.argmax()); keep=(lab==main)
    # Keep physically adjacent shards and fittings, reject disconnected guide pixels.
    reach=ndimage.binary_dilation(keep,iterations=12)
    ids=np.unique(lab[reach]);ids=[i for i in ids if i and sizes[i]>=12]
    keep=np.isin(lab,ids)
    if keep.sum()<80: raise ValueError('Object cell too small')
    a[:,:,3]=np.where(keep,255,0);a[~keep,:3]=0
    im=Image.fromarray(a);return im.crop(im.getbbox())

def periodic(im):
    # Atlas seam normalization: cross-match the outer 8% of the painted texture.
    # The centre stays the original painted material; no mirrored motifs.
    t=np.array(im.resize((128,128),NEAR)).astype(float)
    for axis in (0,1):
        src=t.copy()
        for k in range(10):
            weight=.5*(1-k/10)
            if axis==0:
                t[k]=src[k]*(1-weight)+src[-1-k]*weight
                t[-1-k]=src[-1-k]*(1-weight)+src[k]*weight
            else:
                t[:,k]=src[:,k]*(1-weight)+src[:,-1-k]*weight
                t[:,-1-k]=src[:,-1-k]*(1-weight)+src[:,k]*weight
    return np.array(Image.fromarray(np.uint8(t)).quantize(colors=32,dither=Image.Dither.NONE).convert('RGB'))

def floor_image(tex):
    t=np.array(tex.convert('RGBA')) if isinstance(tex,Image.Image) else tex
    h,w=t.shape[:2]; yy,xx=np.indices((80,160),dtype=float)
    x=(xx+.5-80)/80;y=(yy+.5)/40
    u=(y+x)/2;v=(y-x)/2
    ok=(u>=0)&(u<1)&(v>=0)&(v<1)
    out=np.zeros((80,160,4),np.uint8)
    sx=np.clip((u*w).astype(int),0,w-1);sy=np.clip((v*h).astype(int),0,h-1)
    out[ok,:3]=t[sy[ok],sx[ok],:3];out[ok,3]=255
    return Image.fromarray(out)

def rot(a,p,d):
    du,dv=DIRS[d];return a*du-p*dv,a*dv+p*du

def span(d,a0,a1,p0,p1,h):
    pts=[rot(a,p,d) for a in (a0,a1) for p in (p0,p1)]
    return min(u for u,v in pts),max(u for u,v in pts),min(v for u,v in pts),max(v for u,v in pts),h

def render_boxes(boxes,front,back,cap,W=176,H=224,pivot=(88,176)):
    yy,xx=np.indices((H,W),dtype=float);X=xx+.5-pivot[0];Y=yy+.5-pivot[1]
    delta=X/80;best=np.full((H,W),-1e9);tags=np.full((H,W),-1,int)
    for k,(u0,u1,v0,v1,h) in enumerate(boxes):
        lo=np.maximum.reduce([2*u0-delta,2*v0+delta,Y/40])
        hi=np.minimum.reduce([2*u1-delta,2*v1+delta,(Y+h)/40])
        hit=(lo<=hi)&(hi>best);best[hit]=hi[hit];tags[hit]=k
    hit=tags>=0;t=np.where(hit,best,0);u=(t+delta)/2;v=(t-delta)/2;z=40*t-Y
    out=np.zeros((H,W,4),np.uint8)
    for k,(u0,u1,v0,v1,h) in enumerate(boxes):
        area=tags==k
        top=area&(abs(z-h)<.01)
        sideu=area&~top&(abs(u-u1)<.001)
        sidev=area&~top&~sideu
        for mask,tex,along in [(sideu,back,v),(sidev,front,u)]:
            th,tw=tex.shape[:2]
            sx=np.floor(np.mod(along+.5,1)*tw).astype(int)%tw
            sy=np.clip(((h-z)/h*th).astype(int),0,th-1)
            out[mask,:3]=tex[sy[mask],sx[mask],:3]
        ch,cw=cap.shape[:2]
        tx=np.floor(np.mod(u+.5,1)*cw).astype(int)%cw;ty=np.floor(np.mod(v+.5,1)*ch).astype(int)%ch
        out[top,:3]=cap[ty[top],tx[top],:3];out[area,3]=255
    return Image.fromarray(out)

def plane_layer(tex,d,a0,a1,height,p=0,W=544,H=400,pivot=(272,324)):
    # Exact affine plane sampling: x=80(u-v), y=40(u+v)-z.
    yy,xx=np.indices((H,W),dtype=float);X=xx+.5-pivot[0];Y=yy+.5-pivot[1]
    du,dv=DIRS[d]
    a=(X/80+p*(du+dv))/(du-dv)
    u,v=rot(a,p,d);z=40*(u+v)-Y
    ok=(a>=a0)&(a<a1)&(z>=0)&(z<height)
    sx=np.clip(((a-a0)/(a1-a0)*tex.width).astype(int),0,tex.width-1)
    sy=np.clip(((height-z)/height*tex.height).astype(int),0,tex.height-1)
    arr=np.array(tex);out=np.zeros((H,W,4),np.uint8);out[ok]=arr[sy[ok],sx[ok]]
    return Image.fromarray(out)

def extrude(tex,back,d,a0,a1,height,W,H,pivot,thickness=.2):
    # Stack the painted silhouette through a 0.2 tile thickness. This adds depth
    # without generating any replacement art or filling an arch's walk opening.
    out=Image.new('RGBA',(W,H));du,dv=DIRS[d]
    seq=np.linspace(-thickness/2,thickness/2,17)
    if du-dv<0: seq=seq[::-1]
    face=tex if du-dv>0 else back
    for p in seq:
        out.alpha_composite(plane_layer(face,d,a0,a1,height,float(p),W,H,pivot))
    return out

def save_asset(im,name,category,pivot,**extra):
    p=Path('sprites')/category/(name+'.png');(OUT/p).parent.mkdir(parents=True,exist_ok=True)
    im.save(OUT/p)
    rec={'id':name,'name':extra.pop('display_name',name),'category':category,'file':p.as_posix(),'size_px':list(im.size),'pivot_px':list(pivot),**extra}
    assets.append(rec);return rec

def contact(name,items,cw,ch,cols,title):
    rows=math.ceil(len(items)/cols);im=Image.new('RGB',(cols*cw,rows*ch+54),(22,29,39));draw=ImageDraw.Draw(im)
    try: font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',13);head=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',22)
    except OSError:font=head=None
    draw.text((16,13),title,fill=(218,229,237),font=head)
    for i,(label,src) in enumerate(items):
        x=(i%cols)*cw;y=54+(i//cols)*ch
        draw.rectangle((x+3,y+3,x+cw-4,y+ch-4),fill=(33,43,55))
        s=min((cw-12)/src.width,(ch-35)/src.height,2)
        pic=src.resize((max(1,round(src.width*s)),max(1,round(src.height*s))),NEAR)
        im.paste(pic,(x+(cw-pic.width)//2,y+8+(ch-35-pic.height)//2),pic)
        draw.text((x+8,y+ch-24),label,fill=(174,197,213),font=font)
    (OUT/'reference_sheets').mkdir(exist_ok=True);im.save(OUT/'reference_sheets'/name)

def main():
    OUT.mkdir(parents=True,exist_ok=True);(OUT/'materials').mkdir(exist_ok=True)
    rawfloors=sum([cells(i,4,4,(1024,1024)) for i in range(1,5)],[])[:60]
    floors=[crop_texture(t) for t in rawfloors]
    bases=[periodic(t) for t in floors[:10]]
    floorimgs=[]
    for i,t in enumerate(floors):
        name=BASES[i] if i<10 else FEATURES[i-10]
        tex=bases[i] if i<10 else np.array(t)
        pic=floor_image(tex);floorimgs.append(pic)
        save_asset(pic,name,'floors',(80,40),seamless_self_repeat=i<10,base_material=BASES[i] if i<10 else BASES[(i-10)%10])
    wallcells=cells(5,5,2,(1536,1024));walltex=[np.array(crop_texture(t,.025).resize((160,256),NEAR)) for t in wallcells]
    mats={}
    for fam in range(5):
        fp='materials/'+WALLS[fam]+'.png';Image.fromarray(walltex[fam]).save(OUT/fp);mats[WALLS[fam]]=fp
        cap=bases[[0,2,5,8,0][fam]]
        for mask in range(16):
            fp_cells=[]
            for i in range(-5,5):
                for j in range(-5,5):
                    post=(-1<=i<=0 and -1<=j<=0)
                    arm=(mask&1 and -1<=i<=0 and j<0) or (mask&2 and i>=0 and -1<=j<=0) or (mask&4 and -1<=i<=0 and j>=0) or (mask&8 and i<0 and -1<=j<=0)
                    if post or arm:fp_cells.append([i,j])
            boxes=[(i/10,(i+1)/10,j/10,(j+1)/10,128) for i,j in fp_cells]
            im=render_boxes(boxes,walltex[fam],walltex[fam+5],cap)
            save_asset(im,WALLS[fam]+'_join_%02d'%mask,'walls',(88,176),wall_set=WALLS[fam],height_px=128,topology='connection_node',connection_mask=mask,footprint_cells_0_1_tile=fp_cells)
        for d in DIRS:
            im=render_boxes([span(d,-.5,.5,-.1,.1,128)],walltex[fam],walltex[fam+5],cap)
            save_asset(im,WALLS[fam]+'_panel_'+d,'walls',(88,176),wall_set=WALLS[fam],height_px=128,topology='directed_panel',orientation=d,pixel_identical_to=WALLS[fam]+'_join_'+('05' if d in ('NE','SW') else '10'))
    archobjs=[isolate(t) for t in cells(6,3,2,(1536,1024))]
    for i,name in enumerate(ARCHES):
        for d in DIRS:
            h=[160,184,144][i];pic=extrude(archobjs[i],archobjs[i+3],d,-1.5,1.5,h,544,400,(272,324))
            save_asset(pic,name+'_'+d,'arches',(272,324),arch_design=name,orientation=d,height_px=h,outer_span_tiles=3)
    doorobjs=[isolate(t) for t in cells(7,3,2,(1536,1024))]
    for i,name in enumerate(DOORS):
        fam=[0,3,1][i]
        for d in DIRS:
            frame=[span(d,-.5,-.4,-.1,.1,128),span(d,.4,.5,-.1,.1,128)]
            # Lintel is a raised box: render separately and shift by 112px.
            framepic=render_boxes(frame,walltex[fam],walltex[fam+5],bases[[0,2,5,8,0][fam]],W=256,H=272,pivot=(128,216))
            lintel=render_boxes([span(d,-.5,.5,-.1,.1,16)],walltex[fam],walltex[fam+5],bases[0],W=256,H=272,pivot=(128,104))
            framepic.alpha_composite(lintel)
            hu,hv=rot(-.4,0,d)
            for state in ('closed','open'):
                if state=='closed':leaf=extrude(doorobjs[i],doorobjs[i+3],d,-.4,.4,112,256,272,(128,216),thickness=.1)
                else:
                    # Rotate about the fixed left hinge. Leaf extends 0.8 tile across.
                    ds=list(DIRS);od=ds[(ds.index(d)+1)%4]
                    leaf=extrude(doorobjs[i],doorobjs[i+3],od,0,.8,112,256,272,(round(128+80*(hu-hv)),round(216+40*(hu+hv))),thickness=.1)
                im=Image.new('RGBA',(256,272));im.alpha_composite(leaf);im.alpha_composite(framepic)
                save_asset(im,name+'_'+d+'_'+state,'doors',(128,216),door_design=name,orientation=d,state=state,height_px=128,leaf_height_px=112,hinge_tiles=[hu,hv])
    props=[isolate(t) for n in (8,9) for t in cells(n,5,4,(1536,1024))]
    for i,(name,im,w) in enumerate(zip(PROPS,props,WIDTHS)):
        s=min(w/im.width,150/im.height);im=im.resize((max(1,round(im.width*s)),max(1,round(im.height*s))),NEAR)
        canvas=Image.new('RGBA',(im.width+16,im.height+16));canvas.alpha_composite(im,(8,8));pivot=(8+im.width//2,8+im.height-2)
        save_asset(canvas,name,'scatter',pivot,footprint_tiles_estimate=[round(w/160,3),round(w/160,3)],walk_over=i in WALK,light=i in LIGHT)
    manifest={'pack':'Snowy Summit','version':'1.0','coordinate_system':{'projection':'2:1 dimetric','tile_size_px':[160,80],'world_to_screen':'x=80*(u-v), y=40*(u+v)-z','light':'upper left','units':'pixels'},'wall_materials':mats,'assets':assets,'provenance':{'art':'Fresh image-generation sheets, November 2026; no prior Snowy_Summit art reused','builder':'Independent local projection builder based on docs/CHATGPT_BIOME_SPRITES.md and tools/biomepack.py contracts','upstream_repository':'https://github.com/Agilancer/velscour','runtime_playtested':False}}
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    cfg={'biome_name':'Snowy_Summit','floor_names':BASES+FEATURES,'wall_names':WALLS,'arch_names':ARCHES,'door_names':DOORS,'scatter_names':PROPS,'scatter_widths_px':WIDTHS}
    (ROOT/'sheets'/'names.json').write_text(json.dumps(cfg,indent=2)+'\n')
    def getcat(cat):return [(a['name'],Image.open(OUT/a['file']).convert('RGBA')) for a in assets if a['category']==cat]
    contact('floors.png',getcat('floors'),200,124,6,'SNOWY SUMMIT / 60 floor tiles')
    contact('walls.png',[(a['wall_set']+' / '+str(a.get('connection_mask',a.get('orientation'))),Image.open(OUT/a['file']).convert('RGBA')) for a in assets if a['category']=='walls'],200,240,5,'SNOWY SUMMIT / 100 walls and joins')
    contact('architecture.png',getcat('arches')+getcat('doors'),288,280,4,'SNOWY SUMMIT / arches and doors')
    contact('scatter.png',getcat('scatter'),224,210,5,'SNOWY SUMMIT / 40 scatter pieces')
    validate(manifest,bases)
    make_scene(manifest)
    print('Built',len(assets),'sprites at',OUT)

def validate(manifest,bases):
    tests={};counts=Counter(a['category'] for a in assets)
    tests['inventory']={'pass':dict(counts)=={'floors':60,'walls':100,'arches':12,'doors':24,'scatter':40},'counts':dict(counts),'expected_total':236}
    tests['unique_ids']={'pass':len({a['id'] for a in assets})==236}
    tests['all_pngs_valid']={'pass':True};tests['binary_alpha']={'pass':True};tests['no_magenta_fringe']={'pass':True};tests['floor_diamonds']={'pass':True}
    hashes=[];files={}
    for a in assets:
        p=OUT/a['file'];im=Image.open(p).convert('RGBA');arr=np.array(im);alpha=arr[:,:,3]
        tests['all_pngs_valid']['pass'] &= im.size==tuple(a['size_px']) and bool((alpha>0).any())
        tests['binary_alpha']['pass'] &= bool(np.isin(alpha,[0,255]).all())
        pix=arr[alpha>0];bad=(pix[:,0]>140)&(pix[:,2]>140)&(pix[:,1]<.5*np.minimum(pix[:,0],pix[:,2]))
        tests['no_magenta_fringe']['pass'] &= not bool(bad.any())
        if a['category']=='floors':tests['floor_diamonds']['pass'] &= im.size==(160,80) and int((alpha>0).sum())==6400
        files[a['file']]=hashlib.sha256(p.read_bytes()).hexdigest();hashes.append(files[a['file']])
    tests['base_texture_opposite_edges']=[{'material':BASES[i],'pass':bool(np.array_equal(b[0],b[-1]) and np.array_equal(b[:,0],b[:,-1]))} for i,b in enumerate(bases)]
    tests['all_wall_connection_masks']={'pass':all({a['connection_mask'] for a in assets if a['category']=='walls' and a['wall_set']==w and a['topology']=='connection_node'}==set(range(16)) for w in WALLS)}
    tests['all_door_states_and_directions']={'pass':all(len([a for a in assets if a['category']=='doors' and a['door_design']==w])==8 for w in DOORS)}
    groups={}
    for a in assets:groups.setdefault(files[a['file']],[]).append(a)
    duplicate_groups=[g for g in groups.values() if len(g)>1]
    tests['only_declared_orientation_duplicates']={'pass':all(sum('pixel_identical_to' not in a for a in g)==1 and all(a.get('pixel_identical_to') in {b['id'] for b in g} for a in g if 'pixel_identical_to' in a) for g in duplicate_groups),'distinct_pixel_images':len(set(hashes)),'declared_panel_aliases':20}
    (OUT/'qa').mkdir(exist_ok=True)
    report={'tests':tests,'validation_scope':'Local asset inventory, alpha, dimensions, periodic material boundaries and geometry metadata. Original Catacombs builder and running game not exercised. See integration notes.','sha256':files}
    (OUT/'qa'/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    for k,v in tests.items():print(k,all(t['pass'] for t in v) if isinstance(v,list) else v['pass'])

def make_scene(manifest):
    # Actual sprites composed on the same coordinate/pivot system; no concept-art substitute.
    im=Image.new('RGBA',(1600,1120),(14,23,33,255));draw=ImageDraw.Draw(im)
    byid={a['id']:a for a in assets};items=[]
    def add(name,u,v,z=0):
        a=byid[name];x=800+80*(u-v);y=500+40*(u+v)-z
        items.append((u+v,z,a,round(x),round(y)))
    rng=np.random.default_rng(7)
    for u in range(-4,6):
        for v in range(-4,6):
            if abs(u-v)>8:continue
            material=0 if u<1 else 1
            if -1<=v<=1:material=6
            if u>=3 and v<=-2:material=3
            name=BASES[material]
            if rng.random()<.13:name=FEATURES[int(rng.integers(0,len(FEATURES)))]
            add(name,u-.5,v-.5)
    # Draw floors first, architecture and props follow depth sorted.
    for _,_,a,x,y in items:
        pic=Image.open(OUT/a['file']).convert('RGBA');px,py=a['pivot_px'];im.alpha_composite(pic,(x-px,y-py))
    items=[]
    for u in range(-4,5):
        mask=2|8
        if u==-4:mask=2|4
        if u==4:mask=8
        add(WALLS[0]+'_join_%02d'%mask,u,-4)
    for v in range(-3,3):
        mask=1|4 if v<2 else 1
        add(WALLS[0]+'_join_%02d'%mask,-4,v)
    add(ARCHES[0]+'_SE',1,-2.4)
    for name,u,v in [('snow_capped_boulder',-2,-1.2),('frost_split_boulder',3.7,3.5),('glacier_ice_spire',4,-2.9),('glacier_crystal_cluster',4.6,-1.9),('snowy_rock_cairn',-1.5,2.8),('fallen_snowy_pine',-1,4),('abandoned_summit_sled',2.6,2),('expedition_strongbox',2,3.2),('summit_floor_lantern',1.2,2.9),('snowy_boulder_rubble',-2.8,3.6),('notched_trail_marker',.3,-.4),('mountain_shrine_altar',-1.3,-2.2),('stone_owl_idol',-1.4,-3),('fur_bedroll',3,3.8),('climbing_rope_and_pitons',3.7,2.7),('snowbound_supply_crate',4.3,1.4),('summit_warning_bell',-2.8,.7)]:add(name,u,v)
    for _,_,a,x,y in sorted(items,key=lambda q:(q[0],q[1])):
        pic=Image.open(OUT/a['file']).convert('RGBA');px,py=a['pivot_px'];im.alpha_composite(pic,(x-px,y-py))
    d=ImageDraw.Draw(im)
    try:big=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',36);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',17)
    except OSError:big=small=None
    d.text((54,43),'SNOWY SUMMIT',font=big,fill='#d0d9e6');d.text((56,94),'236 SPRITES  /  160 x 80 DIMETRIC  /  FRESH ART',font=small,fill='#849db5')
    d.text((56,1060),'Local sprite assembly preview - not a game runtime screenshot',font=small,fill='#849db5')
    (OUT/'previews').mkdir(exist_ok=True);im.convert('RGB').save(OUT/'previews'/'snowy_summit_scene.png')

if __name__=='__main__':main()
