#!/usr/bin/env python3
"""Check rendered architecture against the actual upstream importer geometry."""
from pathlib import Path
import importlib.util,json,numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent;PACK=ROOT/'Snowy_Summit_Biome_Pack'
if not PACK.exists():PACK=ROOT
upstream=ROOT/'repository'/'tools'/'biomepack.py'
if not upstream.exists():upstream=ROOT/'tools'/'upstream_biomepack.py'
spec=importlib.util.spec_from_file_location('velscour_biomepack',upstream);b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
man=json.loads((PACK/'manifest.json').read_text());records=[]
for a in man['assets']:
    cat=a['category']
    if cat not in ('walls','arches','doors'):continue
    arr=np.array(Image.open(PACK/a['file']).convert('RGBA'))
    if cat=='walls':_,boxes=b.wall_boxes(a)
    elif cat=='arches':
        n=a['outer_span_tiles'];boxes=[b.span_box(a['orientation'],-n/2+k*.1,-n/2+(k+1)*.1,-.1,.1,a['height_px'],k//5) for k in range(10*n)]
    else:
        d=a['orientation'];boxes=[b.span_box(d,-.5+k*.1,-.5+(k+1)*.1,-.1,.1,128,'frame') for k in range(10)]
        if a['state']=='open':
            hu,hv=a['hinge_tiles'];ha=hu*b.DIRS[d][0]+hv*b.DIRS[d][1];options=[]
            for side in (1,-1):
                leaf=b.span_box(d,ha-.05,ha+.05,0,side*.85,a['leaf_height_px'],'leaf')
                options.append((b.raycast(arr,a['pivot_px'],boxes+[leaf],1)[3],leaf))
            boxes.append(min(options)[1])
    native=b.raycast(arr,a['pivot_px'],boxes,1)[3]
    raised=b.raycast(arr,a['pivot_px'],boxes,1.6)[3]
    records.append({'id':a['id'],'native_pixels_outside_geometry':native,'raised_source_visibility_loss':raised,'opaque_source_pixels':int((arr[:,:,3]>0).sum())})
report={'pass':all(r['native_pixels_outside_geometry']==0 for r in records),'architecture_sprites_checked':len(records),'native_geometry_outside_pixels':sum(r['native_pixels_outside_geometry'] for r in records),'notes':'Native 1.0x coverage must be exact. At 1.6x the importer changes surface visibility; those coverage counts are recorded, not misrepresented as native geometry failures. Runtime game tests have not been run.','records':records}
(PACK/'qa'/'geometry_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Native importer geometry:',report['pass'],'checked',len(records),'outside pixels',report['native_geometry_outside_pixels'])
if not report['pass']:raise SystemExit(1)
