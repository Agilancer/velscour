#!/usr/bin/env python3
"""Prepare VELSCOUR runtime atlases with the repository's unmodified importer."""
from pathlib import Path
import importlib.util, json, shutil
ROOT=Path(__file__).resolve().parent.parent
PACK=ROOT/'Snowy_Summit_Biome_Pack'
if not PACK.exists():PACK=ROOT
upstream=ROOT/'repository'/'tools'/'biomepack.py'
if not upstream.exists():upstream=ROOT/'tools'/'upstream_biomepack.py'
spec=importlib.util.spec_from_file_location('velscour_biomepack',upstream)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
manifest=json.loads((PACK/'manifest.json').read_text())
mod.WALK_OVER.update(a['name'] for a in manifest['assets'] if a.get('walk_over'))
mod.OUT=str(PACK/'runtime');mod.import_pack([str(PACK)],'snowy_summit')
runtime=PACK/'runtime'/'snowy_summit'
meta=json.loads((runtime/'pack.json').read_text())
report={'importer':'Upstream tools/biomepack.py, unchanged','source':'Agilancer/velscour main','status':'success','counts':{'floors':len(meta['floors']),'wall_families':len(meta['walls']),'arches':len(meta['arches']),'doors':len(meta['doors']),'scatter':len(meta['scatter'])},'runtime_playtested':False,'geometry_note':'The importer raises architecture from 128 to 205px and changes visibility at overlaps. Its source-coverage counts at 1.6x include source pixels occluded by the raised geometry; native 1.0x geometry coverage is checked separately.'}
(PACK/'qa'/'importer_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Runtime prepared:',runtime)
