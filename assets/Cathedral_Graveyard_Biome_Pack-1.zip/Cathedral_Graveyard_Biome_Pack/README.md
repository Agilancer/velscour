# Cathedral and Graveyard biome pack

Extract the ZIP and open **START_HERE.html** for the offline searchable browser. **Overview.png**, **Cathedral_Assembly.png**, and **Graveyard_Assembly.png** use the delivered sprites. The overview reduces thumbnails; the separate assembly images and reference sheets use native pixels.

## Inventory

| Category | Designs and coverage | Frames |
|---|---|---:|
| Floors | 60 distinct designs, including 10 self-repeat materials | 60 |
| Walls | 5 families, all 16 neighbor masks plus 4 directed panels each | 100 |
| Arches | 6 unique designs, two each at outer spans 3, 5 and 7 tiles; 4 views each | 24 |
| Doors | 3 designs, 4 views, open and closed states | 24 |
| Scatter | 40 unique props, one authored view each | 40 |
| Total | Static artwork; only doors have alternate states | 248 |

There are 243 distinct pixel payloads. Five directed wall panels deliberately share pixels with equivalent topology pieces; `pixel_identical_to` marks these placement aliases. All 60 floors and 40 props have unique pixel payloads. `orientation_state_coverage.json` enumerates every view/state/mask explicitly.

Floors 01–05 and 11–30 are cathedral interiors (25 designs). Floors 06–10 and 31–60 cover graveyard soil, paths, paving and burial details (35 designs). Props 01–20 and 36–40 focus on the graveyard; 21–35 provide cathedral furnishings, buttress fragments and sculpture.

## Import and placement

Import PNG RGBA with nearest/point filtering, integer positioning, no lossy compression, and no smoothing. Disable mipmaps for fixed-resolution pixel art. Use a common integer scale for the whole pack. Keep transparent canvas padding; if an engine trims a sprite, subtract the trim offset from its pivot.

Tile size is **160 x 80**. Basis vectors are `u=(80,40)` and `v=(-80,40)`. All pivots use pixel-edge coordinates:

```
ground_x = origin_x + 80 * (u - v)
ground_y = origin_y + 40 * (u + v)
image_top_left = ground - pivot_px
```

Height subtracts from screen y. Draw floors first. Depth `u+v` is a starting sort key for props. Tall combined arches require engine occlusion masks or sprite splitting for characters that must walk both in front and behind them. Collision is not generated: use the opening profiles and estimated prop footprints as starting data.

| Category | Canvas | Pivot |
|---|---|---|
| Floors | 160 x 80 | 80, 40 |
| Walls | 256 x 256 | 128, 192 |
| Doors, both states | 320 x 288 | 160, 208 |
| Scatter | 192 x 192 | Per sprite in manifest |
| Arches | Per design below | Per design below |

SE means +u; SW +v; NW -u; NE -v. These names describe the direction **along** the architecture, not the outward camera-facing normal. The four views are 0, 90, 180, 270 degree geometry reprojections. Front and reverse art are separate generated surfaces fitted to the shared front silhouette; no horizontal-flip substitute is used.

Wall masks use `NE=1, SE=2, SW=4, NW=8`. Add bits for connected neighbors. Node sockets lie half a tile from the node center; adjacent wall nodes are one tile apart. Walls are 128 pixels high and 0.2 tile thick. Families are nave ashlar, stained-glass chapel, buttressed masonry, cemetery limestone, and cemetery iron. Buttress relief on the modular wall is surface art; a freestanding dimensional buttress prop is also included. The iron family has real geometric openings above its low stone plinth.

Doors occupy one wall tile with a 0.8-tile leaf, 112 pixels high. The open leaf rotates 90 degrees around the same hinge used by the closed leaf. Never move the sprite when switching state. Leave an adjacent tile clear for the swing. The cemetery gate is a one-tile pedestrian gate, independent of the larger monumental arch openings. No intermediate animation frames are supplied.

## Expanded arches

Outer span includes both piers. Clear opening is measured from the normalized source alpha at the narrowest row within the bottom 16 pixels. Center opening height is the highest center-connected interior transparent row. Decorative tracery can make the opening narrower above the base; consult `opening_profile` in the manifest for each elevation row. These are visual geometry measurements, not a navigation certification.

| # | Design | Outer tiles | Clear base tiles | Center clearance px | Height px | Canvas px | Pivot px |
|---|---|---:|---:|---:|---:|---|---|
| 1 | chapel_lancet | 3 | 1.05 | 155 | 256 | 336 x 472 | 168, 356 |
| 2 | churchyard_cross | 3 | 1.1 | 134 | 232 | 336 x 448 | 168, 332 |
| 3 | nave_triumphal | 5 | 1.925 | 224 | 352 | 496 x 648 | 248, 492 |
| 4 | ruined_cloister | 5 | 2.0375 | 204 | 320 | 496 x 616 | 248, 460 |
| 5 | grand_westwork | 7 | 2.5 | 330 | 448 | 656 x 824 | 328, 628 |
| 6 | processional_cemetery | 7 | 2.75 | 234 | 400 | 656 x 776 | 328, 580 |

For span S, the endpoints in SE are `(-S/2,0)` and `(S/2,0)`; rotate these for the other views. Neighbor wall centers lie at `-(S+1)/2` and `+(S+1)/2` along the same axis. Thus 3-, 5-, and 7-tile arches join walls centered at ±2, ±3, and ±4 tiles respectively. Sockets are logical centerline locations at the outer structural extent. Sculpted piers taper above the plinth; the compatible socket height does not promise rectangular alpha occupancy. All endpoints, canvas sizes, pivots, socket thicknesses and measured spans are explicit in `manifest.json` and `template/arch_geometry.json`.

Every size has independent original artwork and native geometry. Larger sprites were not made by stretching a finished small arch. Each source elevation is normalized to 80 pixels per tile along its axis, extruded 0.2 tile, and reprojected on the same base grid. All four directions of all six designs have separate wall-join QA boards.

## Floors and seamless scope

Floors 01–10 are certified for repeating each material with itself. Their opposite UV edges match exactly; native 4x4 layouts have zero uncovered pixels and zero pixels outside the expected footprint. Repeated motifs remain visible, especially the checker and grass. This is not a claim that different materials blend seamlessly or that feature tiles 11–60 repeat without visible motifs.

The reference diamond has 6,400 opaque pixels and row widths `4,8,...,160,...,4,0`: 79 occupied rows plus one transparent row. All 60 masks match exactly. Keep the full 160x80 slot and do not infer spacing from the alpha bounds.

## Validation and provenance

Ten original source sheets were generated with the **built-in imagegen tool**. Exact prompts and untouched generated sheets are retained in `source_art`. The original game reference informed style and the measured grid; its artwork is not redistributed. Catacombs source art was not reused or recolored. Only its portable builder and placement conventions were adapted.

Processing uses connected-component extraction, nearest-neighbor sampling, binary alpha, transparent-RGB cleanup, texture quantization, periodic UV edges, and deterministic 2.5D projection. Automated results are in `qa/validation.json`: inventory, uniqueness, every floor mask, UV edges, repeat coverage, atlas round trips, unclipped canvases, door pivots/hinges, wall mask/view coverage, continuous wall silhouette joins, arch span measurements and socket coordinates. `qa/visual_review.md` records the visual review scope and limitations.

The grid and architecture transformations are analytically verified. Scatter perspective and anchors are visually matched/estimated from generated art, not recovered 3D geometry. Architectural relief and rear textures are artistic approximations on extruded elevation silhouettes. This is an **engine-neutral PNG pack**, not native DT1/DCC data or a tested engine project.

## Files

- `sprites/`: 248 clean transparent individual PNGs.
- `sheets/`: 11 transparent atlases; exact rectangles in the manifest.
- `reference_sheets/`: all 11 matching labeled inventories.
- `manifest.json`, `manifest.csv`, `orientation_state_coverage.json`: import and coverage data.
- `qa/`: repeat boards, 6 arch alignment boards, wall junctions, door state joins, transparent scenes and validation evidence.
- `template/`: editable inventory/configuration, expanded arch guides, measured arch table, sample scene placements and next-biome brief.
- `source_art/`: all original generated images, normalized elevation/UV art and exact prompts.
- `tools/`: offline builder, preview builder and finalization utility; Python 3.10+, Pillow, NumPy.
- `SHA256SUMS.txt`: file integrity hashes.

## Rebuild or reuse

From the extracted folder, with Python, Pillow and NumPy available:

```
python tools/build_pack.py --source source_art --config template/cathedral_config.json --out Rebuilt_Cathedral
python tools/make_previews.py Rebuilt_Cathedral
python tools/finalize_pack.py Rebuilt_Cathedral
```

For another biome, copy `template/biome_template.json` to a new config, replace the biome/design names and generate ten replacement source sheets in the specified layouts. Keep six arch specs (two per span), provide separate front/reverse artwork, and adjust each height and prop width as needed. Set `wall_family` to the zero-based family used in its QA connections. The iron geometry currently belongs to wall family 5; adjust the builder if a new biome changes that construction. Adapt the cathedral/graveyard-specific scene placements and presentation copy for a new theme. Run all validation and review every sheet and scene again.

Created October 12, 2026. The source Catacombs pack and separate character/monster workspaces were not modified.
