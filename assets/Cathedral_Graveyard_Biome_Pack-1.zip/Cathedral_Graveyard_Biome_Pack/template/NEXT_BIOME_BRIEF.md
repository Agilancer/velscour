# Expanded reusable biome brief

Use this portable pack as the mechanical template for [BIOME]. Create original artwork in [THEME], preserving the exact 160x80 diamond raster, 2:1 basis, native pixel scale, pivots, wall masks and hinged door states. Read README.md, biome_template.json, arch_geometry.json, manifest.json and source_art/generation_prompts.json first.

Deliver 60 floors including 10 tested self-repeat materials; five wall families with all 16 masks and four directed panels; six arches with four directed views each, two at three-tile outer span, two at five and two at seven; three doors in four views with open/closed states; and 40 distinct one-view props. No other animation. Generate independent source art for each arch size; never stretch a finished smaller sprite. Configure each arch height, span, source sheet/column and wall family in arch_specs. Preserve front/reverse artwork and exact prompts.

Use the offline builder for mechanical projection, alpha cleanup, atlases and metadata. Validate all floor masks, periodic edges and repeats, inventory and unique designs, canvas bounds, atlas round trips, stable door hinges/pivots, all wall masks/views, and measured arch openings/spans/sockets. Visually inspect every sheet, all arch directions and representative assembled scenes. Distinguish analytical checks from visually matched scatter perspective and estimated anchors.

Deliver transparent PNGs and atlases, labeled sheets, offline searchable browser, manifests, scene previews, QA evidence, retained original generated art/prompts, updated reusable configuration/guides/tools, import instructions and one ZIP. Use a separate workspace and never modify the source pack. This remains engine-neutral PNG data, not native DT1/DCC.
