from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, sys, hashlib, shutil
P=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent.parent
m=json.loads((P/'manifest.json').read_text());aa=m['assets'];by={a['id']:a for a in aa};imgs={a['id']:Image.open(P/a['file']).convert('RGBA') for a in aa}
def font(n):
    try:return ImageFont.truetype('C:/Windows/Fonts/consola.ttf',n)
    except OSError:return ImageFont.load_default()
def asset(cat,n,**kw):
    prefix={'floors':'floor','walls':'wall','arches':'arch','doors':'door','scatter':'scatter'}[cat]+f'_{n:02}_'
    return next(a for a in aa if a['category']==cat and a['id'].startswith(prefix) and all(a.get(k)==v for k,v in kw.items()))
def paste(im,a,u,v,origin):
    im.alpha_composite(imgs[a['id']],(round(origin[0]+80*(u-v)-a['pivot_px'][0]),round(origin[1]+40*(u+v)-a['pivot_px'][1])))
def thumbnail(board,a,box,label=None):
    x,y,w,h=box;im=imgs[a['id']];bb=im.getbbox();crop=im.crop(bb);board.paste(crop,(x+(w-crop.width)//2,y+max(0,(h-24-crop.height)//2)),crop)
    if label:ImageDraw.Draw(board).text((x+12,y+h-20),label,font=font(13),fill='#c3b89f')


def scene(which):
    board=Image.new('RGBA',(1700,1350));origin=(780,440);placements=[];data={'origin_px':origin,'floors':[],'objects':[]}
    for u in range(9):
        for v in range(8):
            if which=='Cathedral':
                n=1 if u not in (3,4) else 17
                if v==0:n=4
                if (u,v)==(1,4):n=13
            else:
                n=7 if u in (3,4) else 6
                if u not in (3,4) and (u+v)%3==0:n=9
                if (u,v)==(7,5):n=33
            a=asset('floors',n);paste(board,a,u,v,origin);data['floors'].append({'id':a['id'],'u':u,'v':v})
    if which=='Cathedral':
        for u in range(9):placements.append((u,-.5,asset('walls',2 if u%3 else 3,topology='directed_panel',orientation='SE')))
        for v in range(8):placements.append((-.5,v,asset('walls',1,topology='directed_panel',orientation='NE')))
        placements.append((4,1.4,asset('arches',5,orientation='SE')))
        props=[(21,4,.1),(28,.6,.6),(27,.5,2),(30,7.8,.6),(24,1.2,5.8),(23,5.7,.6),(25,6.8,1),(22,2.2,4.1),(22,5.8,4.1),(22,2.2,5.8),(22,5.8,5.8),(26,4.7,7),(31,.6,7),(32,7.8,6.5),(29,8,3)]
        placements.append((8.3,5,asset('doors',1,orientation='NE',state='open')))
    else:
        for u in [0,8]:placements.append((u,-.5,asset('walls',4,topology='directed_panel',orientation='SE')))
        placements.append((4,-.5,asset('arches',6,orientation='SE')))
        for v in range(8):placements.append((-.5,v,asset('walls',5,topology='directed_panel',orientation='NE')))
        props=[(1,.8,1),(9,.8,1.8),(2,2,2),(10,2,2.8),(3,6,1.4),(9,6,2.2),(5,7.6,3),(10,7.6,3.8),(6,1,4.2),(7,5.8,5),(8,1.2,6.4),(11,7.7,1),(12,7.4,6.3),(13,5.4,.7),(14,6.4,6.7),(15,4.7,4),(16,6,4.8),(17,2.5,6.6),(18,4.7,7),(19,7.3,7),(20,.7,7.3),(36,8,4.8),(37,1,0),(38,3.4,7),(39,6.6,7.2),(40,1.8,4.1),(4,2.4,.6)]
        placements.append((4,3.7,asset('doors',3,orientation='SE',state='open')))
    for n,u,v in props:placements.append((u,v,asset('scatter',n)))
    for u,v,a in sorted(placements,key=lambda p:(p[0]+p[1],p[1])):
        paste(board,a,u,v,origin);data['objects'].append({'id':a['id'],'u':u,'v':v})
    board.save(P/'qa'/f'{which.lower()}_scene_transparent.png')
    bg=Image.new('RGB',board.size,'#111a1d');bg.paste(board,(0,0),board);d=ImageDraw.Draw(bg)
    d.text((44,24),which.upper(),font=font(36),fill='#dcc89d');d.text((44,76),'Assembly from delivered sprites | native 160 x 80 grid',font=font(17),fill='#a8b6b5')
    bg.save(P/f'{which}_Assembly.png');(P/'template'/f'{which.lower()}_scene.json').write_text(json.dumps(data,indent=2))
    return bg
c=scene('Cathedral');g=scene('Graveyard')
overview=Image.new('RGB',(1700,1580),'#111a1d');d=ImageDraw.Draw(overview)
d.text((36,24),'CATHEDRAL & GRAVEYARD',font=font(42),fill='#dec798')
d.text((36,83),'248 frames | 60 floors | 5 wall families | 6 arches | 3 doors | 40 props',font=font(20),fill='#b7c0b8')
for k,(im,label) in enumerate([(c,'CATHEDRAL'),(g,'GRAVEYARD')]):
    crop=im.crop((0,110,1700,1320));crop=crop.resize((850,605),Image.Resampling.NEAREST);overview.paste(crop,(k*850,132));d.text((36+k*850,750),label,font=font(24),fill='#dec798')
d.text((36,807),'SIX ORIGINAL ARCH DESIGNS / 3, 5 AND 7 TILE SPANS',font=font(24),fill='#dec798')
for i in range(6):
    a=asset('arches',i+1,orientation='SE');im=imgs[a['id']];im=im.crop(im.getbbox());ratio=min(260/im.width,380/im.height);im=im.resize((round(im.width*ratio),round(im.height*ratio)),Image.Resampling.NEAREST);x=15+i*280;overview.paste(im,(x+(270-im.width)//2,1230-im.height),im);d.text((x+8,1250),a['arch_design'].replace('_',' '),font=font(13),fill='#bdc8c1');d.text((x+8,1275),f"{a['span_tiles']} tiles | {a['height_px']} px high",font=font(14),fill='#bdc8c1')
d.text((36,1350),'ENGINE-NEUTRAL TRANSPARENT PNG PACK',font=font(26),fill='#dec798');d.text((36,1400),'Four directed architecture views | Persistent door hinges | Exact reference floor raster',font=font(19),fill='#a6b5b1');d.text((36,1440),'Original imagegen art, source prompts, atlases, searchable browser and reusable expanded template',font=font(18),fill='#a6b5b1');d.text((36,1500),'Scene and arch thumbnails reduced for overview; full native-scale assembly PNGs included.',font=font(15),fill='#879997');overview.save(P/'Overview.png')
# Junction scenes visually check every wall family in an assembled L / T / cross arrangement.
board=Image.new('RGB',(1700,5*370+90),'#161e21');bd=ImageDraw.Draw(board);bd.text((24,18),'WALL JUNCTION ASSEMBLY TESTS',font=font(27),fill='#dfc99f');bd.text((24,56),'Each family: straight run / all corner rotations / T junction / cross junction',font=font(14),fill='#b4b5aa')
nodesets=[[(0,0,10),(-1,0,2),(1,0,8)],[(0,0,6),(1,0,12),(0,1,3),(1,1,9)],[(0,0,14),(-1,0,2),(1,0,8),(0,1,1)],[(0,0,15),(-1,0,2),(1,0,8),(0,1,1),(0,-1,4)]]
for style in range(5):
    for k,nodes in enumerate(nodesets):
        cell=Image.new('RGBA',(425,340));origin=(210,215)
        for u in [-1,0,1]:
            for v in [-1,0,1]:paste(cell,asset('floors',1),u,v,origin)
        for u,v,mask in sorted(nodes,key=lambda p:p[0]+p[1]):paste(cell,asset('walls',style+1,connection_mask=mask),u,v,origin)
        board.paste(cell,(k*425,90+style*370),cell);bd.text((k*425+16,90+style*370+341),asset('walls',style+1,connection_mask=0)['wall_set']+' / '+['run','corners','tee','cross'][k],font=font(12),fill='#bdb49f')
board.save(P/'qa'/'wall_junctions.png')

# State-pair comparison on the same floor, with ground origin and hinge marked.
board=Image.new('RGB',(1440,3*660+90),'#161e21');bd=ImageDraw.Draw(board);bd.text((24,18),'DOOR / WALL / STATE ALIGNMENT',font=font(27),fill='#dfc99f');bd.text((24,55),'Cyan = doorway pivot, gold = fixed hinge | unchanged wall sockets and ground origin',font=font(14),fill='#b4b5aa')
for i in range(3):
    for k,di in enumerate(['SE','SW','NW','NE']):
        r=k
        def rotation(u,v):
            for _ in range(r):u,v=-v,u
            return u,v
        for st,state in enumerate(['closed','open']):
            cell=Image.new('RGBA',(360,320));o=(180,205)
            for u,v in [(-1,0),(0,0),(1,0),(0,1)]:paste(cell,asset('floors',1),u,v,o)
            objects=[]
            for s in [-1,1]:
                u,v=rotation(s,0);objects.append((u,v,asset('walls',[1,2,4][i],topology='directed_panel',orientation=di)))
            a=asset('doors',i+1,orientation=di,state=state);objects.append((0,0,a))
            for u,v,obj in sorted(objects,key=lambda p:p[0]+p[1]):paste(cell,obj,u,v,o)
            cd=ImageDraw.Draw(cell);x,y=o;cd.line((x-4,y,x+4,y),fill='#3df7ee',width=1);cd.line((x,y-4,x,y+4),fill='#3df7ee');hu,hv=a['hinge_tiles'];hx=round(x+80*(hu-hv));hy=round(y+40*(hu+hv));cd.ellipse((hx-2,hy-2,hx+2,hy+2),fill='#ffb744')
            bx=k*360;byy=90+i*660+st*330;board.paste(cell,(bx,byy),cell);bd.text((bx+12,byy+303),a['door_design']+' / '+di+' / '+state,font=font(12),fill='#bdb49f')
board.save(P/'qa'/'door_wall_alignment.png')

compact=[{k:a[k] for k in ['id','category','name','file','size_px','pivot_px','alpha_bounds_px']}|{'orientation':a.get('orientation',''),'state':a.get('state',''),'seamless':a.get('seamless_self_repeat',False)} for a in aa]
html='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cathedral and Graveyard asset browser</title><style>
:root{color-scheme:dark;font-family:system-ui,sans-serif;background:#11191d;color:#d7d8ce}body{margin:0}header{padding:28px 4vw;background:#1a252a;border-bottom:1px solid #46545a}h1{font-family:Georgia,serif;font-size:38px;letter-spacing:3px;color:#dcc391;margin:0 0 12px}p{line-height:1.6;max-width:1000px}a{color:#a8d7d0}nav{display:flex;gap:16px;flex-wrap:wrap;margin-top:18px}.controls{position:sticky;top:0;z-index:2;background:#172126ee;backdrop-filter:blur(8px);padding:16px 4vw;display:flex;gap:12px;flex-wrap:wrap;align-items:center}input,select{background:#243139;color:#ece6d7;border:1px solid #53636a;border-radius:4px;padding:10px;font:inherit}input{min-width:250px}#grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:14px;padding:20px 4vw}article{background:#1b272d;border:1px solid #35434a;border-radius:6px;overflow:hidden}canvas{display:block;image-rendering:pixelated;background:repeating-conic-gradient(#1b252b 0% 25%,#202e34 0% 50%) 50% / 24px 24px;width:100%;height:260px;object-fit:contain}.meta{padding:13px}h2{font-size:16px;color:#ded0ad;margin:0 0 8px}.detail{font-size:12px;color:#a2b5ba;line-height:1.5;font-family:monospace}.download{display:inline-block;margin-top:10px;font-size:13px}#count{color:#c3c9be}footer{padding:20px 4vw;color:#9cacae}small{color:#a4b3b8}</style>
<header><h1>CATHEDRAL &amp; GRAVEYARD</h1><p>248 transparent sprite frames on a measured 160 × 80 grid. 60 floors (10 self-seamless), 5 wall families, 6 arches spanning 3, 5 and 7 tiles, 3 doors with open and closed states, and 40 scatter props.</p><small>Four directed views for walls, arches and doors. Scatter props have one authored view. All art previews below use the delivered PNGs.</small><nav><a href="README.md">Instructions</a><a href="Overview.png">Pack overview</a><a href="Cathedral_Assembly.png">Cathedral scene</a><a href="Graveyard_Assembly.png">Graveyard scene</a><a href="manifest.json">Full metadata</a><a href="manifest.csv">CSV inventory</a><a href="template/arch_geometry.json">Layout template</a><a href="qa/seamless_repeats.png">Seamless tests</a><a href="qa/arch_05_wall_alignment.png">Arch tests</a><a href="qa/door_wall_alignment.png">Door tests</a><a href="qa/wall_junctions.png">Wall tests</a></nav></header>
<div class="controls"><input id="search" type="search" placeholder="Search names, states, directions…" aria-label="Search assets"><select id="category" aria-label="Category"><option value="">All categories</option><option>floors</option><option>walls</option><option>arches</option><option>doors</option><option>scatter</option></select><label><input id="pivot" type="checkbox" style="min-width:0"> Show pivots</label><span id="count"></span></div><main id="grid"></main><footer>Open this file directly after extracting the ZIP. No server or internet connection is needed. Use nearest-neighbor filtering in your engine. See README for import and placement rules.</footer>
<script>const assets=__ASSETS__;const grid=document.getElementById('grid');function render(){const q=document.getElementById('search').value.toLowerCase().replaceAll(' ','_'),cat=document.getElementById('category').value,pivot=document.getElementById('pivot').checked,list=assets.filter(a=>(!cat||a.category===cat)&&a.id.includes(q));document.getElementById('count').textContent=list.length+' / '+assets.length+' frames';grid.replaceChildren();for(const a of list){const el=document.createElement('article'),cv=document.createElement('canvas');const W=Math.max(384,a.size_px[0]),H=Math.max(336,a.size_px[1]);cv.width=W;cv.height=H;const c=cv.getContext('2d');c.imageSmoothingEnabled=false;const im=new Image();im.onload=()=>{const x=Math.round((W-im.width)/2),y=Math.round((H-im.height)/2);c.drawImage(im,x,y);if(pivot){c.strokeStyle='#3bf6de';c.beginPath();c.moveTo(x+a.pivot_px[0]-5,y+a.pivot_px[1]);c.lineTo(x+a.pivot_px[0]+5,y+a.pivot_px[1]);c.moveTo(x+a.pivot_px[0],y+a.pivot_px[1]-5);c.lineTo(x+a.pivot_px[0],y+a.pivot_px[1]+5);c.stroke()}};im.src=a.file;const meta=document.createElement('div');meta.className='meta';const h=document.createElement('h2');h.textContent=a.name.replaceAll('_',' ');const de=document.createElement('div');de.className='detail';de.textContent=a.id+' | '+a.size_px.join(' × ')+' px | pivot '+a.pivot_px.join(', ')+(a.seamless?' | SELF-SEAMLESS':'');const link=document.createElement('a');link.href=a.file;link.download=a.id+'.png';link.className='download';link.textContent='Open / save transparent PNG';meta.append(h,de,link);el.append(cv,meta);grid.append(el)}}for(const id of ['search','category','pivot'])document.getElementById(id).addEventListener('input',render);render();</script></html>'''.replace('__ASSETS__',json.dumps(compact,separators=(',',':')))
(P/'START_HERE.html').write_text(html,encoding='utf-8')
print('Previews, template guides and asset browser created.')
