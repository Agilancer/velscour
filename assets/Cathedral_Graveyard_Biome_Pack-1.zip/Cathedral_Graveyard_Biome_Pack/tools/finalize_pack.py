from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,sys,hashlib,re,shutil
import numpy as np
P=Path(sys.argv[1]);m=json.loads((P/'manifest.json').read_text());aa=m['assets'];q=json.loads((P/'qa/validation.json').read_text())
arches=[a for a in aa if a['category']=='arches'];dirs=['SE','SW','NW','NE']
def dump(path,data):(P/path).write_text(json.dumps(data,indent=2),encoding='utf-8')
expected=np.zeros((80,160),bool)
for y in range(79):
    w=4*min(y+1,79-y);expected[y,(160-w)//2:(160+w)//2]=True
if len(sys.argv)>2:
    reference=np.array(Image.open(sys.argv[2]).convert('RGB'))[494:574,:160];refmask=np.any(reference!=[255,0,255],axis=2)
    assert np.array_equal(refmask,expected)
    q['tests']['reference_floor_mask']['source']='user supplied 56242.png directly rechecked, reference artwork not redistributed'
badalpha=[];badfloor=[]
for a in aa:
    ar=np.array(Image.open(P/a['file']))
    if np.any(ar[ar[:,:,3]==0,:3]):badalpha.append(a['id'])
    if a['category']=='floors' and not np.array_equal(ar[:,:,3]>0,expected):badfloor.append(a['id'])
q['tests']['all_floor_masks']={'checked':60,'opaque_pixels_each':6400,'mismatches':badfloor,'pass':not badfloor}
q['tests']['transparent_rgb']={'checked':248,'nonzero_rgb_under_alpha_zero':badalpha,'pass':not badalpha}
coverage={'floors':[],'walls':{},'arches':{},'doors':{},'scatter':[]}
for a in aa:
    cat=a['category']
    if cat in ('floors','scatter'):coverage[cat].append(a['id'])
    elif cat=='walls':coverage[cat].setdefault(a['wall_set'],{})['mask_'+str(a['connection_mask']) if 'connection_mask' in a else a['orientation']]=a['id']
    elif cat=='arches':coverage[cat].setdefault(a['arch_design'],{})[a['orientation']]=a['id']
    else:coverage[cat].setdefault(a['door_design'],{}).setdefault(a['orientation'],{})[a['state']]=a['id']
dump('orientation_state_coverage.json',coverage)
archtests=[];rows=[]
for a in arches:
    f=Image.open(P/a['source_front']);bounds=f.getbbox();measured=(bounds[2]-bounds[0])/80
    a['measured_front_alpha_span_tiles']=measured;a['measured_front_alpha_height_px']=bounds[3]-bounds[1]
    a['socket_note']='Logical outer centerline sockets. Sculpted piers taper above the plinth; z_range is the compatible wall height, not a rectangular alpha occupancy promise.'
    archtests.append({'id':a['id'],'measured_elevation_span_tiles':measured,'required_span_tiles':a['span_tiles'],'clear_opening_base_tiles':a['clear_opening_base_tiles'],'pass':measured==a['span_tiles'] and a['clear_opening_base_tiles']>0 and a['measured_front_alpha_height_px']==a['height_px']})
    if a['orientation']=='SE':rows.append({k:a[k] for k in ['arch_design','outer_span_tiles','measured_front_alpha_span_tiles','clear_opening_base_tiles','clear_opening_center_height_px','height_px','size_px','pivot_px','connection_endpoints_tiles','connection_sockets','neighbor_wall_centers_tiles']})
q['tests']['measured_arch_geometry']=archtests
q['tests']['arch_orientation_coverage']={'designs':6,'frames':24,'pass':len(arches)==24 and all(set(v)==set(dirs) for v in coverage['arches'].values())}
m['version']='2.0';m['coverage']['unique_pixel_payloads']=len({a['pixel_sha256'] for a in aa});m['coverage']['arch_outer_spans_tiles']=[3,3,5,5,7,7];m['art_provenance']={'generator':'built-in imagegen','original_source_sheets':10,'exact_prompts':'source_art/generation_prompts.json','processing':'offline nearest-neighbor reduction, periodic UV textures, alpha cleanup, grid projection and elevation extrusion','orientation_coverage':'orientation_state_coverage.json'}
dump('manifest.json',m);dump('template/arch_geometry.json',rows)
q['overall_pass']=all(it['pass'] for test in q['tests'].values() for it in (test if isinstance(test,list) else [test]));dump('qa/validation.json',q)
# Replace obsolete fixed arch drafting guide with one guide per actual geometry.
old=P/'template/arch_guide.png'
if old.exists():old.unlink()
try:font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',14)
except OSError:font=ImageFont.load_default()
board=Image.new('RGB',(1500,1430),'#142024');d=ImageDraw.Draw(board)
d.text((24,18),'EXPANDED ARCH RIG / native 160 x 80 grid',font=font,fill='#dfc798')
for i,a in enumerate(rows):
    im=Image.new('RGBA',tuple(a['size_px']));g=ImageDraw.Draw(im);x,y=a['pivot_px'];span=a['outer_span_tiles'];h=a['height_px']
    ends=[(x-40*span,y-20*span),(x+40*span,y+20*span)]
    g.line((*ends[0],*ends[1]),fill='#e6bd75',width=1)
    g.line((ends[0][0],ends[0][1]-h,ends[0][0],ends[0][1],ends[1][0],ends[1][1],ends[1][0],ends[1][1]-h),fill='#597982')
    for xx,yy in ends:g.ellipse((xx-3,yy-3,xx+3,yy+3),fill='#e6bd75')
    g.line((x-6,y,x+6,y),fill='#42eadb');g.line((x,y-6,x,y+6),fill='#42eadb')
    im.save(P/'template'/f'arch_{i+1:02}_guide.png')
    thumb=im.copy();thumb.thumbnail((450,580),Image.Resampling.NEAREST);bx=20+(i%3)*500;by=80+(i//3)*670;board.paste(thumb,(bx,by),thumb)
    d.text((bx,by+590),f"{i+1:02} {a['arch_design']} / {span} tiles",font=font,fill='#dfc798');d.text((bx,by+615),f"Canvas {a['size_px']}  pivot {a['pivot_px']}",font=font,fill='#abbfbd')
board.save(P/'template/Layout_Template.png')
spec=json.loads((P/'template/biome_template.json').read_text());spec['required_inventory']=m['coverage'];dump('template/biome_template.json',spec)
cfg=json.loads((P/'template/cathedral_config.json').read_text());cfg['template_version']=2;cfg['required_inventory']=m['coverage'];cfg['source_atlas_layouts']=spec['source_atlas_layouts'];dump('template/cathedral_config.json',cfg)
table='\n'.join('| '+ ' | '.join(map(str,[i+1,a['arch_design'],a['outer_span_tiles'],a['clear_opening_base_tiles'],a['clear_opening_center_height_px'],a['height_px'],' x '.join(map(str,a['size_px'])),', '.join(map(str,a['pivot_px']))]))+' |' for i,a in enumerate(rows))
readme='''# Cathedral and Graveyard biome pack

Extract the ZIP and open **START_HERE.html** for the offline searchable browser. **Overview.png**, **Cathedral_Assembly.png**, and **Graveyard_Assembly.png** use the delivered sprites. The overview reduces thumbnails; the separate assembly images and reference sheets use native pixels.

## Inventory

| Category | Designs and coverage | Frames |
|---|---|---:|
| Floors | 60 distinct designs, including 10 self-repeat materials | 60 |
| Walls | 5 families, all 16 neighbor masks plus 4 directed panels each | 100 |
| Arches | 6 unique designs, two each at outer spans 3, 5 and 7 tiles; 4 views each | 24 |
| Doors | 3 designs, 4 views, open and closed states | 24 |
| Scatter | 40 unique props, one authored view each | 40 |
| Total | Static artwork; only doors have alternate states | 248 |

There are 243 distinct pixel payloads. Five directed wall panels deliberately share pixels with equivalent topology pieces; `pixel_identical_to` marks these placement aliases. All 60 floors and 40 props have unique pixel payloads. `orientation_state_coverage.json` enumerates every view/state/mask explicitly.

Floors 01–05 and 11–30 are cathedral interiors (25 designs). Floors 06–10 and 31–60 cover graveyard soil, paths, paving and burial details (35 designs). Props 01–20 and 36–40 focus on the graveyard; 21–35 provide cathedral furnishings, buttress fragments and sculpture.

## Import and placement

Import PNG RGBA with nearest/point filtering, integer positioning, no lossy compression, and no smoothing. Disable mipmaps for fixed-resolution pixel art. Use a common integer scale for the whole pack. Keep transparent canvas padding; if an engine trims a sprite, subtract the trim offset from its pivot.

Tile size is **160 x 80**. Basis vectors are `u=(80,40)` and `v=(-80,40)`. All pivots use pixel-edge coordinates:

```
ground_x = origin_x + 80 * (u - v)
ground_y = origin_y + 40 * (u + v)
image_top_left = ground - pivot_px
```

Height subtracts from screen y. Draw floors first. Depth `u+v` is a starting sort key for props. Tall combined arches require engine occlusion masks or sprite splitting for characters that must walk both in front and behind them. Collision is not generated: use the opening profiles and estimated prop footprints as starting data.

| Category | Canvas | Pivot |
|---|---|---|
| Floors | 160 x 80 | 80, 40 |
| Walls | 256 x 256 | 128, 192 |
| Doors, both states | 320 x 288 | 160, 208 |
| Scatter | 192 x 192 | Per sprite in manifest |
| Arches | Per design below | Per design below |

SE means +u; SW +v; NW -u; NE -v. These names describe the direction **along** the architecture, not the outward camera-facing normal. The four views are 0, 90, 180, 270 degree geometry reprojections. Front and reverse art are separate generated surfaces fitted to the shared front silhouette; no horizontal-flip substitute is used.

Wall masks use `NE=1, SE=2, SW=4, NW=8`. Add bits for connected neighbors. Node sockets lie half a tile from the node center; adjacent wall nodes are one tile apart. Walls are 128 pixels high and 0.2 tile thick. Families are nave ashlar, stained-glass chapel, buttressed masonry, cemetery limestone, and cemetery iron. Buttress relief on the modular wall is surface art; a freestanding dimensional buttress prop is also included. The iron family has real geometric openings above its low stone plinth.

Doors occupy one wall tile with a 0.8-tile leaf, 112 pixels high. The open leaf rotates 90 degrees around the same hinge used by the closed leaf. Never move the sprite when switching state. Leave an adjacent tile clear for the swing. The cemetery gate is a one-tile pedestrian gate, independent of the larger monumental arch openings. No intermediate animation frames are supplied.

## Expanded arches

Outer span includes both piers. Clear opening is measured from the normalized source alpha at the narrowest row within the bottom 16 pixels. Center opening height is the highest center-connected interior transparent row. Decorative tracery can make the opening narrower above the base; consult `opening_profile` in the manifest for each elevation row. These are visual geometry measurements, not a navigation certification.

| # | Design | Outer tiles | Clear base tiles | Center clearance px | Height px | Canvas px | Pivot px |
|---|---|---:|---:|---:|---:|---|---|
'''+table+'''

For span S, the endpoints in SE are `(-S/2,0)` and `(S/2,0)`; rotate these for the other views. Neighbor wall centers lie at `-(S+1)/2` and `+(S+1)/2` along the same axis. Thus 3-, 5-, and 7-tile arches join walls centered at ±2, ±3, and ±4 tiles respectively. Sockets are logical centerline locations at the outer structural extent. Sculpted piers taper above the plinth; the compatible socket height does not promise rectangular alpha occupancy. All endpoints, canvas sizes, pivots, socket thicknesses and measured spans are explicit in `manifest.json` and `template/arch_geometry.json`.

Every size has independent original artwork and native geometry. Larger sprites were not made by stretching a finished small arch. Each source elevation is normalized to 80 pixels per tile along its axis, extruded 0.2 tile, and reprojected on the same base grid. All four directions of all six designs have separate wall-join QA boards.

## Floors and seamless scope

Floors 01–10 are certified for repeating each material with itself. Their opposite UV edges match exactly; native 4x4 layouts have zero uncovered pixels and zero pixels outside the expected footprint. Repeated motifs remain visible, especially the checker and grass. This is not a claim that different materials blend seamlessly or that feature tiles 11–60 repeat without visible motifs.

The reference diamond has 6,400 opaque pixels and row widths `4,8,...,160,...,4,0`: 79 occupied rows plus one transparent row. All 60 masks match exactly. Keep the full 160x80 slot and do not infer spacing from the alpha bounds.

## Validation and provenance

Ten original source sheets were generated with the **built-in imagegen tool**. Exact prompts and untouched generated sheets are retained in `source_art`. The original game reference informed style and the measured grid; its artwork is not redistributed. Catacombs source art was not reused or recolored. Only its portable builder and placement conventions were adapted.

Processing uses connected-component extraction, nearest-neighbor sampling, binary alpha, transparent-RGB cleanup, texture quantization, periodic UV edges, and deterministic 2.5D projection. Automated results are in `qa/validation.json`: inventory, uniqueness, every floor mask, UV edges, repeat coverage, atlas round trips, unclipped canvases, door pivots/hinges, wall mask/view coverage, continuous wall silhouette joins, arch span measurements and socket coordinates. `qa/visual_review.md` records the visual review scope and limitations.

The grid and architecture transformations are analytically verified. Scatter perspective and anchors are visually matched/estimated from generated art, not recovered 3D geometry. Architectural relief and rear textures are artistic approximations on extruded elevation silhouettes. This is an **engine-neutral PNG pack**, not native DT1/DCC data or a tested engine project.

## Files

- `sprites/`: 248 clean transparent individual PNGs.
- `sheets/`: 11 transparent atlases; exact rectangles in the manifest.
- `reference_sheets/`: all 11 matching labeled inventories.
- `manifest.json`, `manifest.csv`, `orientation_state_coverage.json`: import and coverage data.
- `qa/`: repeat boards, 6 arch alignment boards, wall junctions, door state joins, transparent scenes and validation evidence.
- `template/`: editable inventory/configuration, expanded arch guides, measured arch table, sample scene placements and next-biome brief.
- `source_art/`: all original generated images, normalized elevation/UV art and exact prompts.
- `tools/`: offline builder, preview builder and finalization utility; Python 3.10+, Pillow, NumPy.
- `SHA256SUMS.txt`: file integrity hashes.

## Rebuild or reuse

From the extracted folder, with Python, Pillow and NumPy available:

```
python tools/build_pack.py --source source_art --config template/cathedral_config.json --out Rebuilt_Cathedral
python tools/make_previews.py Rebuilt_Cathedral
python tools/finalize_pack.py Rebuilt_Cathedral
```

For another biome, copy `template/biome_template.json` to a new config, replace the biome/design names and generate ten replacement source sheets in the specified layouts. Keep six arch specs (two per span), provide separate front/reverse artwork, and adjust each height and prop width as needed. Set `wall_family` to the zero-based family used in its QA connections. The iron geometry currently belongs to wall family 5; adjust the builder if a new biome changes that construction. Adapt the cathedral/graveyard-specific scene placements and presentation copy for a new theme. Run all validation and review every sheet and scene again.

Created October 12, 2026. The source Catacombs pack and separate character/monster workspaces were not modified.
'''
(P/'README.md').write_text(readme,encoding='utf-8')
(P/'template/NEXT_BIOME_BRIEF.md').write_text('''# Expanded reusable biome brief

Use this portable pack as the mechanical template for [BIOME]. Create original artwork in [THEME], preserving the exact 160x80 diamond raster, 2:1 basis, native pixel scale, pivots, wall masks and hinged door states. Read README.md, biome_template.json, arch_geometry.json, manifest.json and source_art/generation_prompts.json first.

Deliver 60 floors including 10 tested self-repeat materials; five wall families with all 16 masks and four directed panels; six arches with four directed views each, two at three-tile outer span, two at five and two at seven; three doors in four views with open/closed states; and 40 distinct one-view props. No other animation. Generate independent source art for each arch size; never stretch a finished smaller sprite. Configure each arch height, span, source sheet/column and wall family in arch_specs. Preserve front/reverse artwork and exact prompts.

Use the offline builder for mechanical projection, alpha cleanup, atlases and metadata. Validate all floor masks, periodic edges and repeats, inventory and unique designs, canvas bounds, atlas round trips, stable door hinges/pivots, all wall masks/views, and measured arch openings/spans/sockets. Visually inspect every sheet, all arch directions and representative assembled scenes. Distinguish analytical checks from visually matched scatter perspective and estimated anchors.

Deliver transparent PNGs and atlases, labeled sheets, offline searchable browser, manifests, scene previews, QA evidence, retained original generated art/prompts, updated reusable configuration/guides/tools, import instructions and one ZIP. Use a separate workspace and never modify the source pack. This remains engine-neutral PNG data, not native DT1/DCC.
''',encoding='utf-8')
print(json.dumps({'qa_pass':q['overall_pass'],'frames':len(aa),'arch_measurements':rows}))
