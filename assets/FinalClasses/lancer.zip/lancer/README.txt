Lancer — armor and helm library

80 armor sprites and 80 separate helm sprites. No animation frames.
Frame size: 128 x 192 pixels, transparent RGBA PNG.
Atlases: 10 columns x 8 rows; 1280 x 1536 pixels. Row-major order.
Draw the armor first, then the helm at the same top-left origin.
Nominal head anchor: (64, 40). Use nearest-neighbor sampling.

Rarity labels, applied independently to armor and helms:
001-020 Common (20)
021-036 Uncommon (16)
037-052 Rare (16)
053-064 Epic (12)
065-074 Legendary (10)
075-080 Mythic (6)

Open Preview.html locally to mix any of the 80 armor and 80 helm options,
adjust helm fit, and save a transparent combined PNG. No internet needed.
The two labeled PNG sheets and CSV catalogs identify every included sprite.
The clean atlases and individual sprites contain no label text.

Quality status: generated equipment artwork, mechanically sliced and aligned.
The neutral three-quarter pose is consistent in intent but not pixel-identical.
Small differences in anatomy, head angle, scale, hair and edge pixels remain.
Helms share a nominal anchor; every one of the 6,400 pairings has NOT been
individually checked. Some combinations require manual pixel cleanup and fit
adjustment before final game integration. The viewer exposes fit controls.

Artwork created using the built-in image generation tool from the supplied
roster reference. Source generation sheets and prompts are included to support
further refinement. Sprite slicing, labeling and packaging were mechanical.