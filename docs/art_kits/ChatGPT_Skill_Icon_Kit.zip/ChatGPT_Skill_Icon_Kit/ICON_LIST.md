# VELSCOUR skill icons: which have art, which need it

Every skill, talent and class ultimate in the game. **HAS ART** = painted art the game shows today. **NEEDS ART** = drawn in code (an element gradient and a simple shape). `batch` / `cell` = where it is painted in this kit.

| | Has art | Needs art |
|---|---|---|
| Skills | 236 | 448 |
| Talents | 120 | 336 |
| Ultimates | 0 | 19 |

## Paladin

Holy warrior in blessed golden-white plate with a hammer and a cross-marked shield. Gold and white light.

### Skill tree 1: Holy Wrath

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Holy Bolt | holy | HAS ART | - |
| 2 | Blessed Hammer | holy | HAS ART | - |
| 3 | Consecration | holy | HAS ART | - |
| 4 | Fist of the Heavens | holy | HAS ART | - |
| 5 | Judgment Beam | holy | HAS ART | - |
| 6 | Sanctuary | holy | HAS ART | - |
| 7 | Purifying Nova | holy | HAS ART | - |
| 8 | Heaven's Fury | holy | HAS ART | - |
| 9 | Apocalypse of Light | holy | HAS ART | - |

### Skill tree 2: Bulwark

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Smite | holy | HAS ART | - |
| 2 | Holy Shield | holy | HAS ART | - |
| 3 | Crusader's Charge | holy | HAS ART | - |
| 4 | Blessed Shield | holy | HAS ART | - |
| 5 | Fanaticism | holy | HAS ART | - |
| 6 | Conviction | holy | HAS ART | - |
| 7 | Holy Freeze Aura | cold | HAS ART | - |
| 8 | Guardian Angel | holy | HAS ART | - |
| 9 | Bastion of Faith | holy | HAS ART | - |

### Skill tree 3: Crusade

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Zeal | phys | HAS ART | - |
| 2 | Vengeance | light | HAS ART | - |
| 3 | Condemn | holy | HAS ART | - |
| 4 | Holy Fire Blade | fire | HAS ART | - |
| 5 | Sweep | phys | HAS ART | - |
| 6 | Inquisition | fire | HAS ART | - |
| 7 | Blade Barrage | holy | HAS ART | - |
| 8 | Final Judgment | holy | HAS ART | - |
| 9 | Crusade | holy | HAS ART | - |

### Skill tree 4: Radiant Ascension

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Dawnblade | holy | HAS ART | - |
| 2 | Lightwell | holy | HAS ART | - |
| 3 | Seraph Wings | holy | HAS ART | - |
| 4 | Radiant Cascade | holy | HAS ART | - |
| 5 | Solar Hammer | holy | HAS ART | - |
| 6 | Beacon of Valor | holy | HAS ART | - |
| 7 | Falling Sword | holy | HAS ART | - |
| 8 | Wings of Judgment | holy | HAS ART | - |
| 9 | Avatar of Dawn | holy | HAS ART | - |

### Talent branch 1: Holy Wrath

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Radiant Fervor | holy | HAS ART | - |
| 2 | Limitless Hammerstorm | holy | HAS ART | - |
| 3 | Thunderstruck Tether | light | HAS ART | - |
| 4 | Vigor & Blessed Aim | holy | HAS ART | - |
| 5 | Holy Bolt Fissure | holy | HAS ART | - |
| 6 | Divine Wellstorm | light | HAS ART | - |
| 7 | Aegis of Valor | holy | HAS ART | - |
| 8 | Archon of Light | holy | HAS ART | - |

### Talent branch 2: Bulwark

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Defiance & Faith | phys | HAS ART | - |
| 2 | War Steed Trample | holy | HAS ART | - |
| 3 | Shield Ram Impact | phys | HAS ART | - |
| 4 | Iron Maiden Thorns | phys | HAS ART | - |
| 5 | Combusting Aegis | fire | HAS ART | - |
| 6 | Shattering Shards | holy | HAS ART | - |
| 7 | Smiter's Crushing Blow | phys | HAS ART | - |
| 8 | Invoker's Retribution | light | HAS ART | - |

### Talent branch 3: Crusade

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Righteous Zeal | phys | HAS ART | - |
| 2 | Fanatic Flurry | holy | HAS ART | - |
| 3 | Cleaving Wrath | blood | HAS ART | - |
| 4 | Elemental Avenger | fire | HAS ART | - |
| 5 | Instant Vacuum Detonation | holy | HAS ART | - |
| 6 | Reciprocating Retaliation | fire | HAS ART | - |
| 7 | Avenging Executioner | holy | HAS ART | - |
| 8 | Crusader King's Fervor | holy | HAS ART | - |

**Ultimate:** Divine Smite (holy): NEEDS ART, ultimates_1 / cell 1

## Ranger

Wildwood archer with a longbow, hawks and wolves, cunning traps; starlit arrows in the Starshot tree.

### Skill tree 1: Marksmanship

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Quick Shot | phys | HAS ART | - |
| 2 | Multishot | phys | HAS ART | - |
| 3 | Piercing Arrow | phys | HAS ART | - |
| 4 | Guided Arrow | phys | HAS ART | - |
| 5 | Strafe | phys | HAS ART | - |
| 6 | Rain of Arrows | phys | HAS ART | - |
| 7 | Sniper Shot | phys | HAS ART | - |
| 8 | Windrunner | phys | HAS ART | - |
| 9 | Arrow Storm | phys | HAS ART | - |

### Skill tree 2: The Wilds

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Wolf Companion | phys | HAS ART | - |
| 2 | Entangling Roots | poison | HAS ART | - |
| 3 | Poison Ivy Shot | poison | HAS ART | - |
| 4 | Hawk Companion | light | HAS ART | - |
| 5 | Great Bear | phys | HAS ART | - |
| 6 | Hunter's Call | phys | HAS ART | - |
| 7 | Heart of the Oak | poison | HAS ART | - |
| 8 | Ghost Stampede | phys | HAS ART | - |
| 9 | Avatar of the Wild | poison | HAS ART | - |

### Skill tree 3: Traps & Tricks

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Spike Trap | phys | HAS ART | - |
| 2 | Caltrops | phys | HAS ART | - |
| 3 | Smoke Screen | shadow | HAS ART | - |
| 4 | Explosive Trap | fire | HAS ART | - |
| 5 | Decoy | phys | HAS ART | - |
| 6 | Lightning Pylon | light | HAS ART | - |
| 7 | Shadow Step | shadow | HAS ART | - |
| 8 | Cluster Minefield | fire | HAS ART | - |
| 9 | Death Machine | fire | HAS ART | - |

### Skill tree 4: Starshot

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Starlight Arrow | light | HAS ART | - |
| 2 | Lunar Flare | arcane | HAS ART | - |
| 3 | Constellation Shot | light | HAS ART | - |
| 4 | Nova Arrow | light | HAS ART | - |
| 5 | Solar Flare | fire | HAS ART | - |
| 6 | Black Hole Arrow | arcane | HAS ART | - |
| 7 | Falling Stars | light | HAS ART | - |
| 8 | Orion's Bow | light | HAS ART | - |
| 9 | Supernova Barrage | fire | HAS ART | - |

### Talent branch 1: Deadeye Marksman

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Eagle Eye | phys | HAS ART | - |
| 2 | Glacial Quiver | cold | HAS ART | - |
| 3 | Broadhead Volley | phys | HAS ART | - |
| 4 | Lethal Draw | phys | HAS ART | - |
| 5 | Astral Ricochet | arcane | HAS ART | - |
| 6 | Explosive Caliber | fire | HAS ART | - |
| 7 | Windforce Sovereign | phys | HAS ART | - |
| 8 | Voidstar Horizon | arcane | HAS ART | - |

### Talent branch 2: Primal Packleader

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Kinship of the Wild | poison | HAS ART | - |
| 2 | Alpha Direwolves | blood | HAS ART | - |
| 3 | Tempest Pack | light | HAS ART | - |
| 4 | Venomous Thorns | poison | HAS ART | - |
| 5 | Virulent Briars | poison | HAS ART | - |
| 6 | Celestial Guardian | holy | HAS ART | - |
| 7 | Lord of the Stampede | phys | HAS ART | - |
| 8 | Blightbloom Avatar | poison | HAS ART | - |

### Talent branch 3: Saboteur & Gadgeteer

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Cunning Sabotage | fire | HAS ART | - |
| 2 | Cluster Munitions | fire | HAS ART | - |
| 3 | Arc Sentry Network | light | HAS ART | - |
| 4 | Shadow Footwork | phys | HAS ART | - |
| 5 | Phantom Ambush | shadow | HAS ART | - |
| 6 | Pyroclast Turrets | fire | HAS ART | - |
| 7 | Grand Machinist | light | HAS ART | - |
| 8 | Nightstalker's Veil | shadow | HAS ART | - |

**Ultimate:** Storm of Shafts (phys): NEEDS ART, ultimates_1 / cell 2

## Wizard

Robed elemental mage: meteors, blizzards, chain lightning; one element per tree.

### Skill tree 1: Fire

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Fireball | fire | HAS ART | - |
| 2 | Combustion | fire | HAS ART | - |
| 3 | Fire Wall | fire | HAS ART | - |
| 4 | Flame Wave | fire | HAS ART | - |
| 5 | Summon Hydra | fire | HAS ART | - |
| 6 | Meteor | fire | HAS ART | - |
| 7 | Inferno Beam | fire | HAS ART | - |
| 8 | Volcano | fire | HAS ART | - |
| 9 | Armageddon | fire | HAS ART | - |

### Skill tree 2: Frost

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Frost Bolt | cold | HAS ART | - |
| 2 | Frost Nova | cold | HAS ART | - |
| 3 | Ice Armor | cold | HAS ART | - |
| 4 | Glacial Spike | cold | HAS ART | - |
| 5 | Frozen Orb | cold | HAS ART | - |
| 6 | Blizzard | cold | HAS ART | - |
| 7 | Ice Wall | cold | HAS ART | - |
| 8 | Deep Freeze | cold | HAS ART | - |
| 9 | Absolute Zero | cold | HAS ART | - |

### Skill tree 3: Storm

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Charged Bolt | light | HAS ART | - |
| 2 | Lightning Bolt | light | HAS ART | - |
| 3 | Teleport | light | HAS ART | - |
| 4 | Chain Lightning | light | HAS ART | - |
| 5 | Ball Lightning | light | HAS ART | - |
| 6 | Static Field | light | HAS ART | - |
| 7 | Thunderstorm | light | HAS ART | - |
| 8 | Tempest Cyclone | light | HAS ART | - |
| 9 | Wrath of the Sky | light | HAS ART | - |

### Skill tree 4: Prismatic

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Prism Bolt | arcane | HAS ART | - |
| 2 | Chromatic Orb | arcane | HAS ART | - |
| 3 | Spectral Blades | arcane | HAS ART | - |
| 4 | Prismatic Ward | arcane | HAS ART | - |
| 5 | Disintegrate Beam | arcane | HAS ART | - |
| 6 | Singularity Lens | arcane | HAS ART | - |
| 7 | Chromatic Wave | arcane | HAS ART | - |
| 8 | Prismatic Cataclysm | arcane | HAS ART | - |
| 9 | Archon Form | arcane | HAS ART | - |

### Talent branch 1: Conflagration

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Kindled Soul | fire | HAS ART | - |
| 2 | Scorched Earth | fire | HAS ART | - |
| 3 | Phoenix Familiar | fire | HAS ART | - |
| 4 | Searing Intensity | fire | HAS ART | - |
| 5 | Astral Starfall | arcane | HAS ART | - |
| 6 | Flashpoint Wave | fire | HAS ART | - |
| 7 | Heart of the Sun | fire | HAS ART | - |
| 8 | Ashen Rebirth | fire | HAS ART | - |

### Talent branch 2: Absolute Cryomancy

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Rimeheart | cold | HAS ART | - |
| 2 | Shatter Lance | cold | HAS ART | - |
| 3 | Glacial Aegis | cold | HAS ART | - |
| 4 | Winter's Precision | cold | HAS ART | - |
| 5 | Polar Vortex | cold | HAS ART | - |
| 6 | Frostfire Singularity | fire | HAS ART | - |
| 7 | Lord of Eternal Winter | cold | HAS ART | - |
| 8 | Sovereign Archon | arcane | HAS ART | - |

### Talent branch 3: Tempest & Prism

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | High Voltage | light | HAS ART | - |
| 2 | Superconductor | light | HAS ART | - |
| 3 | Aether Slipstream | arcane | HAS ART | - |
| 4 | Leyline Surge | arcane | HAS ART | - |
| 5 | Focused Spectrum | arcane | HAS ART | - |
| 6 | Tempest Overcharge | light | HAS ART | - |
| 7 | Avatar of Thunder | light | HAS ART | - |
| 8 | Grand Prism | arcane | HAS ART | - |

**Ultimate:** Supernova (fire): NEEDS ART, ultimates_1 / cell 3

## Necromancer

Commander of the dead: skeletons, bone spears, blood magic, curses, plague.

### Skill tree 1: Bone & Blood

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Bone Spear | phys | HAS ART | - |
| 2 | Bone Armor | phys | HAS ART | - |
| 3 | Blood Drain | blood | HAS ART | - |
| 4 | Corpse Explosion | fire | HAS ART | - |
| 5 | Blood Nova | blood | HAS ART | - |
| 6 | Bone Prison | phys | HAS ART | - |
| 7 | Bone Spirit | shadow | HAS ART | - |
| 8 | Bone Storm | phys | HAS ART | - |
| 9 | Exsanguinate | blood | HAS ART | - |

### Skill tree 2: Summoning

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Raise Skeleton | phys | HAS ART | - |
| 2 | Skeletal Mage | cold | HAS ART | - |
| 3 | Summon Golem | phys | HAS ART | - |
| 4 | Dark Pact | shadow | HAS ART | - |
| 5 | Revive | shadow | HAS ART | - |
| 6 | Unholy Command | shadow | HAS ART | - |
| 7 | Ghoul Horde | poison | HAS ART | - |
| 8 | Army of the Dead | shadow | HAS ART | - |
| 9 | Lich Form | cold | HAS ART | - |

### Skill tree 3: Curses & Plague

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Amplify Damage | shadow | HAS ART | - |
| 2 | Decrepify | shadow | HAS ART | - |
| 3 | Poison Nova | poison | HAS ART | - |
| 4 | Life Tap | blood | HAS ART | - |
| 5 | Plague Cloud | poison | HAS ART | - |
| 6 | Terror | shadow | HAS ART | - |
| 7 | Plague Spear | poison | HAS ART | - |
| 8 | Pestilence Aura | poison | HAS ART | - |
| 9 | Doom | shadow | HAS ART | - |

### Skill tree 4: Skeletal Legion

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Skeletal Reaver | phys | HAS ART | - |
| 2 | Coffin Guard | phys | HAS ART | - |
| 3 | Mend Bones | shadow | HAS ART | - |
| 4 | Bone Standard-Bearer | phys | HAS ART | - |
| 5 | Skeletal Stormcaller | light | HAS ART | - |
| 6 | Chained Jailer | phys | HAS ART | - |
| 7 | Pyre Inquisitor | fire | HAS ART | - |
| 8 | Grave Warband | phys | HAS ART | - |
| 9 | Reaper King | shadow | HAS ART | - |

### Talent branch 1: Ossuary & Blood

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Serrated Marrow | phys | HAS ART | - |
| 2 | Teeth & Splinters | phys | HAS ART | - |
| 3 | Sanguine Lance | blood | HAS ART | - |
| 4 | Crimson Reservoir | blood | HAS ART | - |
| 5 | Miasmic Detonation | poison | HAS ART | - |
| 6 | Reaper Vortex | shadow | HAS ART | - |
| 7 | Sanguine Sovereign | blood | HAS ART | - |
| 8 | Lich Phylactery | shadow | HAS ART | - |

### Talent branch 2: Undying Legion

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Skeleton Mastery | shadow | HAS ART | - |
| 2 | Skeletal Marksmen | phys | HAS ART | - |
| 3 | Ironbone Phalanx | phys | HAS ART | - |
| 4 | Danse Macabre | shadow | HAS ART | - |
| 5 | Hellfire Golem & Pyromancers | fire | HAS ART | - |
| 6 | Bone Colossus | blood | HAS ART | - |
| 7 | Supreme Overlord | shadow | HAS ART | - |
| 8 | Conclave of Archliches | arcane | HAS ART | - |

### Talent branch 3: Blight & Malediction

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Venomous Malediction | poison | HAS ART | - |
| 2 | Soul Rupture | shadow | HAS ART | - |
| 3 | Pandemic Volley | poison | HAS ART | - |
| 4 | Creeping Entropy | poison | HAS ART | - |
| 5 | Sanctified Reliquary | holy | HAS ART | - |
| 6 | Harbinger of Doom | shadow | HAS ART | - |
| 7 | Avatar of Pestilence | poison | HAS ART | - |
| 8 | Toll of the Dead | shadow | HAS ART | - |

**Ultimate:** Grave Eruption (shadow): NEEDS ART, ultimates_1 / cell 4

## Barbarian

Savage northern berserker: bare arms, furs and iron, two-handed axes and greatswords, war paint, roaring warcries, earth-splitting slams. Steel, leather brown, blood red, ember orange.

### Skill tree 1: Rage

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Bash | phys | NEEDS ART | barbarian__skills_t0 / 1 |
| 2 | Frenzy | phys | NEEDS ART | barbarian__skills_t0 / 2 |
| 3 | Furious Charge | phys | NEEDS ART | barbarian__skills_t0 / 3 |
| 4 | Whirlwind | phys | NEEDS ART | barbarian__skills_t0 / 4 |
| 5 | Cleave | phys | NEEDS ART | barbarian__skills_t0 / 5 |
| 6 | Double Throw | phys | NEEDS ART | barbarian__skills_t0 / 6 |
| 7 | Executioner | blood | NEEDS ART | barbarian__skills_t0 / 7 |
| 8 | Bloodlust | blood | NEEDS ART | barbarian__skills_t0 / 8 |
| 9 | Wrath of the Berserker | blood | NEEDS ART | barbarian__skills_t0 / 9 |

### Skill tree 2: Warcries

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Battle Orders | phys | NEEDS ART | barbarian__skills_t1 / 1 |
| 2 | Howl | phys | NEEDS ART | barbarian__skills_t1 / 2 |
| 3 | Taunt | phys | NEEDS ART | barbarian__skills_t1 / 3 |
| 4 | War Cry | phys | NEEDS ART | barbarian__skills_t1 / 4 |
| 5 | Battle Command | phys | NEEDS ART | barbarian__skills_t1 / 5 |
| 6 | Grim Ward | phys | HAS ART (creature portrait) | barbarian__skills_t1 / 6 |
| 7 | Rallying Cry | phys | NEEDS ART | barbarian__skills_t1 / 7 |
| 8 | Call of the Ancients | phys | HAS ART (creature portrait) | barbarian__skills_t1 / 8 |
| 9 | Undying Rage | blood | NEEDS ART | barbarian__skills_t1 / 9 |

### Skill tree 3: Earthshaker

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Ground Stomp | phys | NEEDS ART | barbarian__skills_t2 / 1 |
| 2 | Leap Attack | phys | NEEDS ART | barbarian__skills_t2 / 2 |
| 3 | Boulder Toss | phys | NEEDS ART | barbarian__skills_t2 / 3 |
| 4 | Fissure | phys | NEEDS ART | barbarian__skills_t2 / 4 |
| 5 | Seismic Step | phys | NEEDS ART | barbarian__skills_t2 / 5 |
| 6 | Earthquake | phys | NEEDS ART | barbarian__skills_t2 / 6 |
| 7 | Avalanche | phys | NEEDS ART | barbarian__skills_t2 / 7 |
| 8 | Stone Skin | phys | NEEDS ART | barbarian__skills_t2 / 8 |
| 9 | Worldsplitter | phys | NEEDS ART | barbarian__skills_t2 / 9 |

### Skill tree 4: Bloodrage

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Rending Chop | blood | NEEDS ART | barbarian__skills_t3 / 1 |
| 2 | Bloodletting Nova | blood | NEEDS ART | barbarian__skills_t3 / 2 |
| 3 | Crimson Cleave | blood | NEEDS ART | barbarian__skills_t3 / 3 |
| 4 | Blood Howl | blood | NEEDS ART | barbarian__skills_t3 / 4 |
| 5 | Blood Totem | blood | HAS ART (creature portrait) | barbarian__skills_t3 / 5 |
| 6 | Massacre | blood | NEEDS ART | barbarian__skills_t3 / 6 |
| 7 | Axe Rain | phys | NEEDS ART | barbarian__skills_t3 / 7 |
| 8 | Bloodbath | blood | NEEDS ART | barbarian__skills_t3 / 8 |
| 9 | Avatar of Carnage | blood | NEEDS ART | barbarian__skills_t3 / 9 |

### Talent branch 1: Berserker Fury

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Relentless Savagery | phys | NEEDS ART | barbarian__talents_b0 / 1 |
| 2 | Eye of the Bloodstorm | phys | NEEDS ART | barbarian__talents_b0 / 2 |
| 3 | Cinder Cyclone | fire | NEEDS ART | barbarian__talents_b0 / 3 |
| 4 | Thirst for Carnage | blood | NEEDS ART | barbarian__talents_b0 / 4 |
| 5 | Merciless Execution | blood | NEEDS ART | barbarian__talents_b0 / 5 |
| 6 | Crimson Rupture | blood | NEEDS ART | barbarian__talents_b0 / 6 |
| 7 | God of Slaughter | blood | NEEDS ART | barbarian__talents_b0 / 7 |
| 8 | Too Angry to Die | phys | NEEDS ART | barbarian__talents_b0 / 8 |

### Talent branch 2: Warchief & Ancients

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Booming Voice | phys | NEEDS ART | barbarian__talents_b1 / 1 |
| 2 | Thunderous Roar | light | NEEDS ART | barbarian__talents_b1 / 2 |
| 3 | Chieftain Medicine | holy | NEEDS ART | barbarian__talents_b1 / 3 |
| 4 | Iron Skin & Courage | phys | NEEDS ART | barbarian__talents_b1 / 4 |
| 5 | Ancients of the Peak | light | NEEDS ART | barbarian__talents_b1 / 5 |
| 6 | War Standards | fire | NEEDS ART | barbarian__talents_b1 / 6 |
| 7 | Voice of Mount Arreat | light | NEEDS ART | barbarian__talents_b1 / 7 |
| 8 | Bastion of Iron | phys | NEEDS ART | barbarian__talents_b1 / 8 |

### Talent branch 3: Tectonic Titan

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Crushing Weight | phys | NEEDS ART | barbarian__talents_b2 / 1 |
| 2 | Crater Impact | fire | NEEDS ART | barbarian__talents_b2 / 2 |
| 3 | Avalanche Hurl | cold | NEEDS ART | barbarian__talents_b2 / 3 |
| 4 | Tectonic Force | fire | NEEDS ART | barbarian__talents_b2 / 4 |
| 5 | Volcanic Faults | fire | NEEDS ART | barbarian__talents_b2 / 5 |
| 6 | Subduction Pull | phys | NEEDS ART | barbarian__talents_b2 / 6 |
| 7 | Cataclysmic Titan | fire | NEEDS ART | barbarian__talents_b2 / 7 |
| 8 | Skybreaker Colossus | phys | NEEDS ART | barbarian__talents_b2 / 8 |

**Ultimate:** Cataclysm (phys): NEEDS ART, ultimates_1 / cell 5

## Dragoon

Armored dragon-lancer in a winged helm with a long lance, diving from the sky; dragon blood and wyrm breath. Deep steel blue, silver and dragon-fire orange.

### Skill tree 1: Lancework

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Lance Jab | phys | NEEDS ART | dragoon__skills_t0 / 1 |
| 2 | Twin Thrust | phys | NEEDS ART | dragoon__skills_t0 / 2 |
| 3 | Sweeping Lance | phys | NEEDS ART | dragoon__skills_t0 / 3 |
| 4 | Spiral Lance | phys | NEEDS ART | dragoon__skills_t0 / 4 |
| 5 | Spearstep | phys | NEEDS ART | dragoon__skills_t0 / 5 |
| 6 | Lance Flurry | phys | NEEDS ART | dragoon__skills_t0 / 6 |
| 7 | Lance Barrier | phys | NEEDS ART | dragoon__skills_t0 / 7 |
| 8 | Spear Rain | phys | NEEDS ART | dragoon__skills_t0 / 8 |
| 9 | Gungnir | light | NEEDS ART | dragoon__skills_t0 / 9 |

### Skill tree 2: Sky Dive

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Jump | phys | NEEDS ART | dragoon__skills_t1 / 1 |
| 2 | Wind Step | phys | NEEDS ART | dragoon__skills_t1 / 2 |
| 3 | Dragon Dive | fire | NEEDS ART | dragoon__skills_t1 / 3 |
| 4 | Feather Fall | phys | NEEDS ART | dragoon__skills_t1 / 4 |
| 5 | Comet Dive | fire | NEEDS ART | dragoon__skills_t1 / 5 |
| 6 | Updraft Cyclone | phys | NEEDS ART | dragoon__skills_t1 / 6 |
| 7 | Storm Dive | light | NEEDS ART | dragoon__skills_t1 / 7 |
| 8 | Skyward Sweep | phys | NEEDS ART | dragoon__skills_t1 / 8 |
| 9 | Dragonfall | fire | NEEDS ART | dragoon__skills_t1 / 9 |

### Skill tree 3: Wyrmblood

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Dragon Breath | fire | NEEDS ART | dragoon__skills_t2 / 1 |
| 2 | Wyrm Scale | fire | NEEDS ART | dragoon__skills_t2 / 2 |
| 3 | Blood Pact | blood | NEEDS ART | dragoon__skills_t2 / 3 |
| 4 | Wyvern Familiar | fire | HAS ART (creature portrait) | dragoon__skills_t2 / 4 |
| 5 | Draconic Roar | fire | NEEDS ART | dragoon__skills_t2 / 5 |
| 6 | Flame Lash | fire | NEEDS ART | dragoon__skills_t2 / 6 |
| 7 | Wyrm Coil | fire | NEEDS ART | dragoon__skills_t2 / 7 |
| 8 | Bloodfire Nova | blood | NEEDS ART | dragoon__skills_t2 / 8 |
| 9 | Dragonsoul | fire | NEEDS ART | dragoon__skills_t2 / 9 |

### Skill tree 4: Spearstorm

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Thousandfold Impalement | phys | NEEDS ART | dragoon__skills_t3 / 1 |
| 2 | Triune Spearfall | phys | NEEDS ART | dragoon__skills_t3 / 2 |
| 3 | Rallying Standard | phys | NEEDS ART | dragoon__skills_t3 / 3 |
| 4 | Phalanx Breaker | phys | NEEDS ART | dragoon__skills_t3 / 4 |
| 5 | Storm of Barbs | light | NEEDS ART | dragoon__skills_t3 / 5 |
| 6 | Spear Vortex | phys | NEEDS ART | dragoon__skills_t3 / 6 |
| 7 | Sunfall Lance | fire | NEEDS ART | dragoon__skills_t3 / 7 |
| 8 | Aegis of the Wyrm | fire | NEEDS ART | dragoon__skills_t3 / 8 |
| 9 | Sovereign Spearstorm | phys | NEEDS ART | dragoon__skills_t3 / 9 |

### Talent branch 1: Spear Sovereign

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Valkyrie Reach | phys | NEEDS ART | dragoon__talents_b0 / 1 |
| 2 | Heartseeker Thrusts | phys | NEEDS ART | dragoon__talents_b0 / 2 |
| 3 | Thunder Glaive | light | NEEDS ART | dragoon__talents_b0 / 3 |
| 4 | Relentless Cadence | phys | NEEDS ART | dragoon__talents_b0 / 4 |
| 5 | Heavensfall Javelins | holy | NEEDS ART | dragoon__talents_b0 / 5 |
| 6 | Whirling Guard | phys | NEEDS ART | dragoon__talents_b0 / 6 |
| 7 | Grandmaster of the Spear | phys | NEEDS ART | dragoon__talents_b0 / 7 |
| 8 | Odinic Bolt | light | NEEDS ART | dragoon__talents_b0 / 8 |

### Talent branch 2: Skyborne Diver

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Gale Stride | light | NEEDS ART | dragoon__talents_b1 / 1 |
| 2 | Thunderbolt Dive | light | NEEDS ART | dragoon__talents_b1 / 2 |
| 3 | Starfall Crater | fire | NEEDS ART | dragoon__talents_b1 / 3 |
| 4 | Aerial Supremacy | light | NEEDS ART | dragoon__talents_b1 / 4 |
| 5 | Relentless Vault | phys | NEEDS ART | dragoon__talents_b1 / 5 |
| 6 | Jetstream Vortex | cold | NEEDS ART | dragoon__talents_b1 / 6 |
| 7 | Lord of the High Heavens | light | NEEDS ART | dragoon__talents_b1 / 7 |
| 8 | Wings of the Immortal | holy | NEEDS ART | dragoon__talents_b1 / 8 |

### Talent branch 3: Wyrmblood Covenant

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Draconic Vitality | fire | NEEDS ART | dragoon__talents_b2 / 1 |
| 2 | Rimefang Lineage | cold | NEEDS ART | dragoon__talents_b2 / 2 |
| 3 | Searing Dragonfire | fire | NEEDS ART | dragoon__talents_b2 / 3 |
| 4 | Ancient Scales | fire | NEEDS ART | dragoon__talents_b2 / 4 |
| 5 | Elder Wyrm Familiar | fire | NEEDS ART | dragoon__talents_b2 / 5 |
| 6 | Awakened Bloodline | blood | NEEDS ART | dragoon__talents_b2 / 6 |
| 7 | Avatar of the First Wyrm | fire | NEEDS ART | dragoon__talents_b2 / 7 |
| 8 | Covenant of Scales | phys | NEEDS ART | dragoon__talents_b2 / 8 |

**Ultimate:** Skyfall Dive (light): NEEDS ART, ultimates_1 / cell 6

## Totem Master

Tribal shaman who plants carved spirit totems (bear, wolf, eagle and serpent faces) that burn, shock and heal; ghostly ancestors fight beside him. Carved wood, bone, feathers, turquoise spirit glow, storm and lava.

### Skill tree 1: Totems

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Elemental Totem | fire | HAS ART (creature portrait) | totem_master__skills_t0 / 1 |
| 2 | Healing Stream Totem | holy | HAS ART (creature portrait) | totem_master__skills_t0 / 2 |
| 3 | Stoneclaw Totem | phys | HAS ART (creature portrait) | totem_master__skills_t0 / 3 |
| 4 | Windfury Totem | phys | HAS ART (creature portrait) | totem_master__skills_t0 / 4 |
| 5 | Earthbind Totem | phys | HAS ART (creature portrait) | totem_master__skills_t0 / 5 |
| 6 | Totemic Recall | arcane | NEEDS ART | totem_master__skills_t0 / 6 |
| 7 | Magma Totem | fire | HAS ART (creature portrait) | totem_master__skills_t0 / 7 |
| 8 | Spirit Link Totem | holy | HAS ART (creature portrait) | totem_master__skills_t0 / 8 |
| 9 | Grand Pantheon Totem | arcane | HAS ART (creature portrait) | totem_master__skills_t0 / 9 |

### Skill tree 2: Ancestors

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Spirit Wolf | cold | HAS ART (creature portrait) | totem_master__skills_t1 / 1 |
| 2 | Ancestral Bolt | holy | NEEDS ART | totem_master__skills_t1 / 2 |
| 3 | Spirit Shield | holy | NEEDS ART | totem_master__skills_t1 / 3 |
| 4 | Hex | shadow | NEEDS ART | totem_master__skills_t1 / 4 |
| 5 | Ancestral Guardian | holy | HAS ART (creature portrait) | totem_master__skills_t1 / 5 |
| 6 | Spirit Walk | holy | NEEDS ART | totem_master__skills_t1 / 6 |
| 7 | Rebirth | holy | NEEDS ART | totem_master__skills_t1 / 7 |
| 8 | Spirit Bear | holy | HAS ART (creature portrait) | totem_master__skills_t1 / 8 |
| 9 | Council of Elders | holy | HAS ART (creature portrait) | totem_master__skills_t1 / 9 |

### Skill tree 3: Earth & Storm

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Elemental Shock | light | NEEDS ART | totem_master__skills_t2 / 1 |
| 2 | Lightning Bolt | light | NEEDS ART | totem_master__skills_t2 / 2 |
| 3 | Chain Lightning | light | NEEDS ART | totem_master__skills_t2 / 3 |
| 4 | Primal Stomp | phys | NEEDS ART | totem_master__skills_t2 / 4 |
| 5 | Lava Burst | fire | NEEDS ART | totem_master__skills_t2 / 5 |
| 6 | Thunderstorm | light | HAS ART (creature portrait) | totem_master__skills_t2 / 6 |
| 7 | Earthquake | phys | NEEDS ART | totem_master__skills_t2 / 7 |
| 8 | Earthen Wall | phys | NEEDS ART | totem_master__skills_t2 / 8 |
| 9 | Avatar of Storms | light | NEEDS ART | totem_master__skills_t2 / 9 |

### Skill tree 4: Spirit Walk

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Ghostpalm Strike | arcane | NEEDS ART | totem_master__skills_t3 / 1 |
| 2 | Wisp Bolt | arcane | NEEDS ART | totem_master__skills_t3 / 2 |
| 3 | Ancestral Step | arcane | NEEDS ART | totem_master__skills_t3 / 3 |
| 4 | Soul Drum | arcane | NEEDS ART | totem_master__skills_t3 / 4 |
| 5 | Spirit Chain | arcane | NEEDS ART | totem_master__skills_t3 / 5 |
| 6 | Ghostly Gale | arcane | NEEDS ART | totem_master__skills_t3 / 6 |
| 7 | Totem Transmute | arcane | NEEDS ART | totem_master__skills_t3 / 7 |
| 8 | Ancestral Wrath | holy | NEEDS ART | totem_master__skills_t3 / 8 |
| 9 | Astral Ascendance | arcane | NEEDS ART | totem_master__skills_t3 / 9 |

### Talent branch 1: Totemic Architect

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Runed Heartwood | fire | NEEDS ART | totem_master__talents_b0 / 1 |
| 2 | Volcanic Spire | fire | NEEDS ART | totem_master__talents_b0 / 2 |
| 3 | Thunderhead Totems | light | NEEDS ART | totem_master__talents_b0 / 3 |
| 4 | Sacred Grove | holy | NEEDS ART | totem_master__talents_b0 / 4 |
| 5 | Overloaded Recall | arcane | NEEDS ART | totem_master__talents_b0 / 5 |
| 6 | Tidecaller Spires | holy | NEEDS ART | totem_master__talents_b0 / 6 |
| 7 | Forest of Pillars | arcane | NEEDS ART | totem_master__talents_b0 / 7 |
| 8 | Reincarnation | holy | NEEDS ART | totem_master__talents_b0 / 8 |

### Talent branch 2: Spiritwalker

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Ancestral Wisdom | holy | NEEDS ART | totem_master__talents_b1 / 1 |
| 2 | Alpha Spirit Pack | cold | NEEDS ART | totem_master__talents_b1 / 2 |
| 3 | Tethered Souls | holy | NEEDS ART | totem_master__talents_b1 / 3 |
| 4 | Rhythm of the Ancients | holy | NEEDS ART | totem_master__talents_b1 / 4 |
| 5 | Crippling Jinx | shadow | NEEDS ART | totem_master__talents_b1 / 5 |
| 6 | Astral Projection | arcane | NEEDS ART | totem_master__talents_b1 / 6 |
| 7 | Chieftain of the Spirit Realm | holy | NEEDS ART | totem_master__talents_b1 / 7 |
| 8 | Astral Walker | arcane | NEEDS ART | totem_master__talents_b1 / 8 |

### Talent branch 3: Primal Fury

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Fury of Sky & Earth | light | NEEDS ART | totem_master__talents_b2 / 1 |
| 2 | Lightning Overload | light | NEEDS ART | totem_master__talents_b2 / 2 |
| 3 | Permafrost Surge | cold | NEEDS ART | totem_master__talents_b2 / 3 |
| 4 | Elemental Devastation | fire | NEEDS ART | totem_master__talents_b2 / 4 |
| 5 | Magma Chamber | fire | NEEDS ART | totem_master__talents_b2 / 5 |
| 6 | Cyclonic Convergence | light | NEEDS ART | totem_master__talents_b2 / 6 |
| 7 | Voice of the Maelstrom | light | NEEDS ART | totem_master__talents_b2 / 7 |
| 8 | Worldshatter | fire | NEEDS ART | totem_master__talents_b2 / 8 |

**Ultimate:** Grand Totemic Cataclysm (light): NEEDS ART, ultimates_1 / cell 7

## Death Knight

Fallen champion in dark runed plate with a frost-glowing greatsword (his Runeblade); plague and life-stealing blood magic. Tree colours: Frost = icy blue, Unholy = sickly green, Blood = crimson, Runeblade = cold blue-white runes.

### Skill tree 1: Frost

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Frost Strike | cold | NEEDS ART | death_knight__skills_t0 / 1 |
| 2 | Howling Blast | cold | NEEDS ART | death_knight__skills_t0 / 2 |
| 3 | Chains of Ice | cold | NEEDS ART | death_knight__skills_t0 / 3 |
| 4 | Obliterate | cold | NEEDS ART | death_knight__skills_t0 / 4 |
| 5 | Icebound Fortitude | cold | NEEDS ART | death_knight__skills_t0 / 5 |
| 6 | Remorseless Winter | cold | NEEDS ART | death_knight__skills_t0 / 6 |
| 7 | Horn of Winter | cold | NEEDS ART | death_knight__skills_t0 / 7 |
| 8 | Glacial Advance | cold | NEEDS ART | death_knight__skills_t0 / 8 |
| 9 | Sindragosa's Fury | cold | NEEDS ART | death_knight__skills_t0 / 9 |

### Skill tree 2: Unholy

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Plague Strike | poison | NEEDS ART | death_knight__skills_t1 / 1 |
| 2 | Death Coil | shadow | NEEDS ART | death_knight__skills_t1 / 2 |
| 3 | Raise Ghoul | shadow | HAS ART (creature portrait) | death_knight__skills_t1 / 3 |
| 4 | Pestilence | poison | NEEDS ART | death_knight__skills_t1 / 4 |
| 5 | Anti-Magic Shell | shadow | NEEDS ART | death_knight__skills_t1 / 5 |
| 6 | Dark Transformation | poison | HAS ART (creature portrait) | death_knight__skills_t1 / 6 |
| 7 | Defile | shadow | NEEDS ART | death_knight__skills_t1 / 7 |
| 8 | Summon Gargoyle | shadow | HAS ART (creature portrait) | death_knight__skills_t1 / 8 |
| 9 | Army of the Dead | shadow | HAS ART (creature portrait) | death_knight__skills_t1 / 9 |

### Skill tree 3: Blood

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Blood Strike | blood | NEEDS ART | death_knight__skills_t2 / 1 |
| 2 | Death Strike | blood | NEEDS ART | death_knight__skills_t2 / 2 |
| 3 | Bone Shield | blood | NEEDS ART | death_knight__skills_t2 / 3 |
| 4 | Death Grip | shadow | NEEDS ART | death_knight__skills_t2 / 4 |
| 5 | Blood Boil | blood | NEEDS ART | death_knight__skills_t2 / 5 |
| 6 | Vampiric Blood | blood | NEEDS ART | death_knight__skills_t2 / 6 |
| 7 | Gorefiend's Grasp | shadow | NEEDS ART | death_knight__skills_t2 / 7 |
| 8 | Dancing Rune Weapon | blood | HAS ART (creature portrait) | death_knight__skills_t2 / 8 |
| 9 | Purgatory | blood | NEEDS ART | death_knight__skills_t2 / 9 |

### Skill tree 4: Runeblade

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Rune Strike | shadow | NEEDS ART | death_knight__skills_t3 / 1 |
| 2 | Runic Shield | shadow | NEEDS ART | death_knight__skills_t3 / 2 |
| 3 | Spectral Scythe | shadow | NEEDS ART | death_knight__skills_t3 / 3 |
| 4 | Rune Blade Throw | shadow | NEEDS ART | death_knight__skills_t3 / 4 |
| 5 | Dark Runeweapon | shadow | HAS ART (creature portrait) | death_knight__skills_t3 / 5 |
| 6 | Rune Tap | blood | NEEDS ART | death_knight__skills_t3 / 6 |
| 7 | Blades of the Fallen | shadow | NEEDS ART | death_knight__skills_t3 / 7 |
| 8 | Soul Reaper | shadow | NEEDS ART | death_knight__skills_t3 / 8 |
| 9 | Apocalyptic Runeblade | shadow | NEEDS ART | death_knight__skills_t3 / 9 |

### Talent branch 1: Frozen Throne

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Icy Talons | cold | NEEDS ART | death_knight__talents_b0 / 1 |
| 2 | Killing Machine | cold | NEEDS ART | death_knight__talents_b0 / 2 |
| 3 | Gathering Whiteout | cold | NEEDS ART | death_knight__talents_b0 / 3 |
| 4 | Runic Permafrost | cold | NEEDS ART | death_knight__talents_b0 / 4 |
| 5 | Scourge Frostwyrm | cold | NEEDS ART | death_knight__talents_b0 / 5 |
| 6 | Inexorable Grip | cold | NEEDS ART | death_knight__talents_b0 / 6 |
| 7 | Wrath of the Lich Lord | cold | NEEDS ART | death_knight__talents_b0 / 7 |
| 8 | Master of Runeblades | arcane | NEEDS ART | death_knight__talents_b0 / 8 |

### Talent branch 2: Unholy Scourge

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Ebon Plaguebringer | poison | NEEDS ART | death_knight__talents_b1 / 1 |
| 2 | Stitched Abomination | poison | NEEDS ART | death_knight__talents_b1 / 2 |
| 3 | Risen Scourge Pack | poison | NEEDS ART | death_knight__talents_b1 / 3 |
| 4 | Crypt Fever | shadow | NEEDS ART | death_knight__talents_b1 / 4 |
| 5 | Doombolt Barrage | shadow | NEEDS ART | death_knight__talents_b1 / 5 |
| 6 | Desecrated Ground | shadow | NEEDS ART | death_knight__talents_b1 / 6 |
| 7 | Fourth Horseman | shadow | NEEDS ART | death_knight__talents_b1 / 7 |
| 8 | Spellbreaker Runes | arcane | NEEDS ART | death_knight__talents_b1 / 8 |

### Talent branch 3: Sanguine Knights

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Veteran of the Third War | blood | NEEDS ART | death_knight__talents_b2 / 1 |
| 2 | Heartstrike Cleave | blood | NEEDS ART | death_knight__talents_b2 / 2 |
| 3 | Sanguine Grasp | blood | NEEDS ART | death_knight__talents_b2 / 3 |
| 4 | Ossuary Bulwark | blood | NEEDS ART | death_knight__talents_b2 / 4 |
| 5 | Crimson Blade Dance | blood | NEEDS ART | death_knight__talents_b2 / 5 |
| 6 | Blood Tap Barrier | blood | NEEDS ART | death_knight__talents_b2 / 6 |
| 7 | Shroud of Purgatory | blood | NEEDS ART | death_knight__talents_b2 / 7 |
| 8 | Sovereign of Blood | blood | NEEDS ART | death_knight__talents_b2 / 8 |

**Ultimate:** Glacial Oblivion (cold): NEEDS ART, ultimates_1 / cell 8

## Astronomer

The Astronomer: a robed stargazer who wields the heavens: star missiles, comets, falling suns, moons, black holes and constellations drawn as gold lines between stars. Starlight blue on deep night skies, with gold.

### Skill tree 1: Starfire

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Star Missiles | arcane | NEEDS ART | arcane_sorcerer__skills_t0 / 1 |
| 2 | Arcane Orb | arcane | NEEDS ART | arcane_sorcerer__skills_t0 / 2 |
| 3 | Disintegrate | arcane | NEEDS ART | arcane_sorcerer__skills_t0 / 3 |
| 4 | Celestial Mirror | arcane | NEEDS ART | arcane_sorcerer__skills_t0 / 4 |
| 5 | Supernova | arcane | NEEDS ART | arcane_sorcerer__skills_t0 / 5 |
| 6 | Arcane Torrent | arcane | NEEDS ART | arcane_sorcerer__skills_t0 / 6 |
| 7 | Pulsar | light | NEEDS ART | arcane_sorcerer__skills_t0 / 7 |
| 8 | Cosmic Ascension | arcane | NEEDS ART | arcane_sorcerer__skills_t0 / 8 |
| 9 | Big Bang | arcane | NEEDS ART | arcane_sorcerer__skills_t0 / 9 |

### Skill tree 2: Celestial Bodies

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Falling Star | arcane | NEEDS ART | arcane_sorcerer__skills_t1 / 1 |
| 2 | Comet | cold | NEEDS ART | arcane_sorcerer__skills_t1 / 2 |
| 3 | Solar Wind | fire | NEEDS ART | arcane_sorcerer__skills_t1 / 3 |
| 4 | Meteor Shower | fire | NEEDS ART | arcane_sorcerer__skills_t1 / 4 |
| 5 | Corona | fire | NEEDS ART | arcane_sorcerer__skills_t1 / 5 |
| 6 | Lunar Tide | arcane | NEEDS ART | arcane_sorcerer__skills_t1 / 6 |
| 7 | Eclipse | shadow | NEEDS ART | arcane_sorcerer__skills_t1 / 7 |
| 8 | Sun Slam | fire | NEEDS ART | arcane_sorcerer__skills_t1 / 8 |
| 9 | Moonfall | cold | NEEDS ART | arcane_sorcerer__skills_t1 / 9 |

### Skill tree 3: Gravity

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Gravity Bolt | shadow | NEEDS ART | arcane_sorcerer__skills_t2 / 1 |
| 2 | Repulse | shadow | NEEDS ART | arcane_sorcerer__skills_t2 / 2 |
| 3 | Gravity Well | shadow | NEEDS ART | arcane_sorcerer__skills_t2 / 3 |
| 4 | Wormhole | shadow | NEEDS ART | arcane_sorcerer__skills_t2 / 4 |
| 5 | Graviton Lance | shadow | NEEDS ART | arcane_sorcerer__skills_t2 / 5 |
| 6 | Accretion Disk | arcane | NEEDS ART | arcane_sorcerer__skills_t2 / 6 |
| 7 | Black Hole | shadow | NEEDS ART | arcane_sorcerer__skills_t2 / 7 |
| 8 | Neutron Star | light | NEEDS ART | arcane_sorcerer__skills_t2 / 8 |
| 9 | Singularity | shadow | NEEDS ART | arcane_sorcerer__skills_t2 / 9 |

### Skill tree 4: Constellations

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Twinkle | arcane | NEEDS ART | arcane_sorcerer__skills_t3 / 1 |
| 2 | Star Chart | arcane | NEEDS ART | arcane_sorcerer__skills_t3 / 2 |
| 3 | Shooting Star | arcane | NEEDS ART | arcane_sorcerer__skills_t3 / 3 |
| 4 | Starlines | arcane | NEEDS ART | arcane_sorcerer__skills_t3 / 4 |
| 5 | Ursa Major | arcane | HAS ART (creature portrait) | arcane_sorcerer__skills_t3 / 5 |
| 6 | Zodiac Wheel | arcane | NEEDS ART | arcane_sorcerer__skills_t3 / 6 |
| 7 | Constellation | arcane | NEEDS ART | arcane_sorcerer__skills_t3 / 7 |
| 8 | Heaven's Map | arcane | NEEDS ART | arcane_sorcerer__skills_t3 / 8 |
| 9 | Grand Conjunction | arcane | NEEDS ART | arcane_sorcerer__skills_t3 / 9 |

### Talent branch 1: Astral Conduit

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Astral Resonance | arcane | NEEDS ART | arcane_sorcerer__talents_b0 / 1 |
| 2 | Starlight Volley | arcane | NEEDS ART | arcane_sorcerer__talents_b0 / 2 |
| 3 | Quasar Ray | fire | NEEDS ART | arcane_sorcerer__talents_b0 / 3 |
| 4 | Harmonic Alignment | arcane | NEEDS ART | arcane_sorcerer__talents_b0 / 4 |
| 5 | Prism of Mirrors | arcane | NEEDS ART | arcane_sorcerer__talents_b0 / 5 |
| 6 | Magnetar Pulse | arcane | NEEDS ART | arcane_sorcerer__talents_b0 / 6 |
| 7 | Architect of the Cosmos | arcane | NEEDS ART | arcane_sorcerer__talents_b0 / 7 |
| 8 | Celestial Menagerie | arcane | NEEDS ART | arcane_sorcerer__talents_b0 / 8 |

### Talent branch 2: Solar & Lunar Cycles

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Equinox Balance | fire | NEEDS ART | arcane_sorcerer__talents_b1 / 1 |
| 2 | Halley Frostfall | cold | NEEDS ART | arcane_sorcerer__talents_b1 / 2 |
| 3 | Coronal Mass Ejection | fire | NEEDS ART | arcane_sorcerer__talents_b1 / 3 |
| 4 | Celestial Syzygy | arcane | NEEDS ART | arcane_sorcerer__talents_b1 / 4 |
| 5 | Total Umbra | shadow | NEEDS ART | arcane_sorcerer__talents_b1 / 5 |
| 6 | Perseid Shower | fire | NEEDS ART | arcane_sorcerer__talents_b1 / 6 |
| 7 | Binary Sun | fire | NEEDS ART | arcane_sorcerer__talents_b1 / 7 |
| 8 | Starlight Reborn | arcane | NEEDS ART | arcane_sorcerer__talents_b1 / 8 |

### Talent branch 3: Singularity & Void

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Event Horizon | arcane | NEEDS ART | arcane_sorcerer__talents_b2 / 1 |
| 2 | Tidal Shear | arcane | NEEDS ART | arcane_sorcerer__talents_b2 / 2 |
| 3 | Relativistic Lance | arcane | NEEDS ART | arcane_sorcerer__talents_b2 / 3 |
| 4 | Dark Matter Density | shadow | NEEDS ART | arcane_sorcerer__talents_b2 / 4 |
| 5 | Folded Space | arcane | NEEDS ART | arcane_sorcerer__talents_b2 / 5 |
| 6 | Debris Ring | arcane | NEEDS ART | arcane_sorcerer__talents_b2 / 6 |
| 7 | Supermassive Collapse | shadow | NEEDS ART | arcane_sorcerer__talents_b2 / 7 |
| 8 | Relativistic Time Dilation | arcane | NEEDS ART | arcane_sorcerer__talents_b2 / 8 |

**Ultimate:** Astral Collapse (arcane): NEEDS ART, ultimates_1 / cell 9

## Carrion Witch

Swamp hag who commands crows and locusts, brews plague and hexes foes into rotting puppets under a grave moon. Rot green, bruise purple, bone, black feathers.

### Skill tree 1: Plague

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Rot Bolt | poison | NEEDS ART | carrion_witch__skills_t0 / 1 |
| 2 | Plague Cloud | poison | NEEDS ART | carrion_witch__skills_t0 / 2 |
| 3 | Corpse Burst | poison | NEEDS ART | carrion_witch__skills_t0 / 3 |
| 4 | Locust Swarm | poison | NEEDS ART | carrion_witch__skills_t0 / 4 |
| 5 | Pestilent Spray | poison | NEEDS ART | carrion_witch__skills_t0 / 5 |
| 6 | Infest | poison | NEEDS ART | carrion_witch__skills_t0 / 6 |
| 7 | Rain of Rot | poison | NEEDS ART | carrion_witch__skills_t0 / 7 |
| 8 | Pandemic | poison | NEEDS ART | carrion_witch__skills_t0 / 8 |
| 9 | Hive Mother | poison | HAS ART (creature portrait) | carrion_witch__skills_t0 / 9 |

### Skill tree 2: Murder of Crows

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Crow Swarm | shadow | NEEDS ART | carrion_witch__skills_t1 / 1 |
| 2 | Raven Familiar | shadow | HAS ART (creature portrait) | carrion_witch__skills_t1 / 2 |
| 3 | Feathered Cloak | shadow | NEEDS ART | carrion_witch__skills_t1 / 3 |
| 4 | Murder of Crows | shadow | NEEDS ART | carrion_witch__skills_t1 / 4 |
| 5 | Eye Gouge | blood | NEEDS ART | carrion_witch__skills_t1 / 5 |
| 6 | Night Wings | shadow | NEEDS ART | carrion_witch__skills_t1 / 6 |
| 7 | Feather Blades | phys | NEEDS ART | carrion_witch__skills_t1 / 7 |
| 8 | Unkindness | shadow | HAS ART (creature portrait) | carrion_witch__skills_t1 / 8 |
| 9 | Nevermore | shadow | NEEDS ART | carrion_witch__skills_t1 / 9 |

### Skill tree 3: Hexes

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Hex Bolt | shadow | NEEDS ART | carrion_witch__skills_t2 / 1 |
| 2 | Voodoo Doll | blood | NEEDS ART | carrion_witch__skills_t2 / 2 |
| 3 | Withering Hex | shadow | NEEDS ART | carrion_witch__skills_t2 / 3 |
| 4 | Witch's Cauldron | poison | HAS ART (creature portrait) | carrion_witch__skills_t2 / 4 |
| 5 | Blood Hex | blood | NEEDS ART | carrion_witch__skills_t2 / 5 |
| 6 | Effigy Totem | blood | HAS ART (creature portrait) | carrion_witch__skills_t2 / 6 |
| 7 | Mass Hysteria | shadow | NEEDS ART | carrion_witch__skills_t2 / 7 |
| 8 | Puppeteer | shadow | NEEDS ART | carrion_witch__skills_t2 / 8 |
| 9 | Witching Hour | shadow | NEEDS ART | carrion_witch__skills_t2 / 9 |

### Skill tree 4: Grave Moon

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Moonlit Hex | shadow | NEEDS ART | carrion_witch__skills_t3 / 1 |
| 2 | Moon Moths | poison | NEEDS ART | carrion_witch__skills_t3 / 2 |
| 3 | Witchlight Zone | poison | NEEDS ART | carrion_witch__skills_t3 / 3 |
| 4 | Blood Moon Hex | blood | NEEDS ART | carrion_witch__skills_t3 / 4 |
| 5 | Gravecall | shadow | HAS ART (creature portrait) | carrion_witch__skills_t3 / 5 |
| 6 | Lantern Procession | fire | HAS ART (creature portrait) | carrion_witch__skills_t3 / 6 |
| 7 | Grave Moon Rising | shadow | NEEDS ART | carrion_witch__skills_t3 / 7 |
| 8 | Eclipse of Wings | shadow | NEEDS ART | carrion_witch__skills_t3 / 8 |
| 9 | Moonfall Cataclysm | shadow | NEEDS ART | carrion_witch__skills_t3 / 9 |

### Talent branch 1: Pestilence Hive

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Putrid Brew | poison | NEEDS ART | carrion_witch__talents_b0 / 1 |
| 2 | Ravenous Swarm | poison | NEEDS ART | carrion_witch__talents_b0 / 2 |
| 3 | Caustic Bile | acid | NEEDS ART | carrion_witch__talents_b0 / 3 |
| 4 | Spore Shroud | poison | NEEDS ART | carrion_witch__talents_b0 / 4 |
| 5 | Brood Colonies | poison | NEEDS ART | carrion_witch__talents_b0 / 5 |
| 6 | Choking Contagion | poison | NEEDS ART | carrion_witch__talents_b0 / 6 |
| 7 | Queen of the Swarm | poison | NEEDS ART | carrion_witch__talents_b0 / 7 |
| 8 | Hag of the Black Bog | poison | NEEDS ART | carrion_witch__talents_b0 / 8 |

### Talent branch 2: Murder of Crows

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Razor Plumes | shadow | NEEDS ART | carrion_witch__talents_b1 / 1 |
| 2 | Bloodbeak Flock | blood | NEEDS ART | carrion_witch__talents_b1 / 2 |
| 3 | Coven Familiars | shadow | NEEDS ART | carrion_witch__talents_b1 / 3 |
| 4 | Carrion Feast | shadow | NEEDS ART | carrion_witch__talents_b1 / 4 |
| 5 | Blackout Tornado | shadow | NEEDS ART | carrion_witch__talents_b1 / 5 |
| 6 | Corvid Step | shadow | NEEDS ART | carrion_witch__talents_b1 / 6 |
| 7 | Morrigan Sovereign | shadow | NEEDS ART | carrion_witch__talents_b1 / 7 |
| 8 | High Priestess of the Moon | arcane | NEEDS ART | carrion_witch__talents_b1 / 8 |

### Talent branch 3: Hexcraft & Moon

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Wicked Eye | shadow | NEEDS ART | carrion_witch__talents_b2 / 1 |
| 2 | Piercing Needles | shadow | NEEDS ART | carrion_witch__talents_b2 / 2 |
| 3 | Haunted Effigies | shadow | NEEDS ART | carrion_witch__talents_b2 / 3 |
| 4 | Midnight Chant | arcane | NEEDS ART | carrion_witch__talents_b2 / 4 |
| 5 | Crimson Sabbath | blood | NEEDS ART | carrion_witch__talents_b2 / 5 |
| 6 | Crushing Moonfall | arcane | NEEDS ART | carrion_witch__talents_b2 / 6 |
| 7 | Mother of Hexes | shadow | NEEDS ART | carrion_witch__talents_b2 / 7 |
| 8 | Threads of Fate | arcane | NEEDS ART | carrion_witch__talents_b2 / 8 |

**Ultimate:** Feast of Crows (poison): NEEDS ART, ultimates_2 / cell 1

## Bard

Roguish minstrel with a lute and throwing knives; songs that heal and empower, chords that shatter bone. Every Bard skill plays a musical note: show that note glyph (given per skill) as a glowing gold music symbol inside the scene.

### Skill tree 1: Songs

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Plucked Note | arcane | NEEDS ART | bard__skills_t0 / 1 |
| 2 | Hymn of Mending | holy | NEEDS ART | bard__skills_t0 / 2 |
| 3 | Ballad of Valor | holy | NEEDS ART | bard__skills_t0 / 3 |
| 4 | Song of Swiftness | phys | NEEDS ART | bard__skills_t0 / 4 |
| 5 | Dirge of Sorrow | shadow | NEEDS ART | bard__skills_t0 / 5 |
| 6 | Chorus of Spirits | holy | HAS ART (creature portrait) | bard__skills_t0 / 6 |
| 7 | Rhapsody Nova | holy | NEEDS ART | bard__skills_t0 / 7 |
| 8 | Symphony of Storms | light | NEEDS ART | bard__skills_t0 / 8 |
| 9 | Magnum Opus | holy | NEEDS ART | bard__skills_t0 / 9 |

### Skill tree 2: Sonic Arts

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Power Chord | phys | NEEDS ART | bard__skills_t1 / 1 |
| 2 | Echo | phys | NEEDS ART | bard__skills_t1 / 2 |
| 3 | Shockwave Riff | phys | NEEDS ART | bard__skills_t1 / 3 |
| 4 | Resonance Beam | arcane | NEEDS ART | bard__skills_t1 / 4 |
| 5 | Feedback Loop | phys | NEEDS ART | bard__skills_t1 / 5 |
| 6 | Bass Drop | phys | NEEDS ART | bard__skills_t1 / 6 |
| 7 | Wall of Sound | phys | NEEDS ART | bard__skills_t1 / 7 |
| 8 | Amplifier Pylon | arcane | HAS ART (creature portrait) | bard__skills_t1 / 8 |
| 9 | Sonic Boom | phys | NEEDS ART | bard__skills_t1 / 9 |

### Skill tree 3: Trickery

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Fan of Notes | phys | NEEDS ART | bard__skills_t2 / 1 |
| 2 | Smoke Screen | shadow | NEEDS ART | bard__skills_t2 / 2 |
| 3 | Pyrotechnics | fire | NEEDS ART | bard__skills_t2 / 3 |
| 4 | Dancing Notes | phys | NEEDS ART | bard__skills_t2 / 4 |
| 5 | Mirror Images | arcane | NEEDS ART | bard__skills_t2 / 5 |
| 6 | Flashbang | holy | NEEDS ART | bard__skills_t2 / 6 |
| 7 | Swashbuckle | phys | NEEDS ART | bard__skills_t2 / 7 |
| 8 | Firework Finale | fire | NEEDS ART | bard__skills_t2 / 8 |
| 9 | Bladestorm Waltz | phys | NEEDS ART | bard__skills_t2 / 9 |

### Skill tree 4: Grand Finale

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Bright Note | light | NEEDS ART | bard__skills_t3 / 1 |
| 2 | Spotlight | light | NEEDS ART | bard__skills_t3 / 2 |
| 3 | Stage Dive | phys | NEEDS ART | bard__skills_t3 / 3 |
| 4 | Drum Roll | phys | NEEDS ART | bard__skills_t3 / 4 |
| 5 | Crescendo Wave | light | NEEDS ART | bard__skills_t3 / 5 |
| 6 | Backup Singers | light | HAS ART (creature portrait) | bard__skills_t3 / 6 |
| 7 | Mic Drop | light | NEEDS ART | bard__skills_t3 / 7 |
| 8 | Rock Legend | light | NEEDS ART | bard__skills_t3 / 8 |
| 9 | The Grand Finale | fire | NEEDS ART | bard__skills_t3 / 9 |

### Talent branch 1: Virtuoso Choir

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Golden Resonance | holy | NEEDS ART | bard__talents_b0 / 1 |
| 2 | Polyphonic Arpeggio | holy | NEEDS ART | bard__talents_b0 / 2 |
| 3 | Restorative Anthem | holy | NEEDS ART | bard__talents_b0 / 3 |
| 4 | Standing Ovation | holy | NEEDS ART | bard__talents_b0 / 4 |
| 5 | Grand Ensemble | holy | NEEDS ART | bard__talents_b0 / 5 |
| 6 | Requiem of Sorrow | shadow | NEEDS ART | bard__talents_b0 / 6 |
| 7 | Celestial Maestro | holy | NEEDS ART | bard__talents_b0 / 7 |
| 8 | Final Encore | holy | NEEDS ART | bard__talents_b0 / 8 |

### Talent branch 2: Thunderous Riff

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Overdrive Amp | light | NEEDS ART | bard__talents_b1 / 1 |
| 2 | Reverb & Distortion | light | NEEDS ART | bard__talents_b1 / 2 |
| 3 | Stadium Stack | light | NEEDS ART | bard__talents_b1 / 3 |
| 4 | Wall of Decibels | arcane | NEEDS ART | bard__talents_b1 / 4 |
| 5 | Sub-Bass Implosion | arcane | NEEDS ART | bard__talents_b1 / 5 |
| 6 | Laser Lightshow | light | NEEDS ART | bard__talents_b1 / 6 |
| 7 | Thunderstruck Legend | light | NEEDS ART | bard__talents_b1 / 7 |
| 8 | Infinite Feedback | arcane | NEEDS ART | bard__talents_b1 / 8 |

### Talent branch 3: Dashing Showman

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Stage Presence | phys | NEEDS ART | bard__talents_b2 / 1 |
| 2 | Razor Fan | arcane | NEEDS ART | bard__talents_b2 / 2 |
| 3 | Pyrotechnic Rig | fire | NEEDS ART | bard__talents_b2 / 3 |
| 4 | Acrobatic Panache | phys | NEEDS ART | bard__talents_b2 / 4 |
| 5 | Illusionist Troupe | arcane | NEEDS ART | bard__talents_b2 / 5 |
| 6 | Daredevil Flourish | phys | NEEDS ART | bard__talents_b2 / 6 |
| 7 | Showstopper Finale | fire | NEEDS ART | bard__talents_b2 / 7 |
| 8 | Phantom Duelist | phys | NEEDS ART | bard__talents_b2 / 8 |

**Ultimate:** Grand Crescendo (arcane): NEEDS ART, ultimates_2 / cell 2

## Slime Lord

Crowned king of living ooze: acid floods, slimeling broods, grotesque mutations. In this game ACID IS BLUE: glossy translucent blue ooze (rainbow slimes in Primordial).

### Skill tree 1: Ooze

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Slime Ball | acid | NEEDS ART | slime_lord__skills_t0 / 1 |
| 2 | Slime Pool | acid | NEEDS ART | slime_lord__skills_t0 / 2 |
| 3 | Ooze Wave | acid | NEEDS ART | slime_lord__skills_t0 / 3 |
| 4 | Acid Rain | acid | NEEDS ART | slime_lord__skills_t0 / 4 |
| 5 | Gelatinous Wall | acid | NEEDS ART | slime_lord__skills_t0 / 5 |
| 6 | Sludge Beam | acid | NEEDS ART | slime_lord__skills_t0 / 6 |
| 7 | Viscous Orbs | acid | NEEDS ART | slime_lord__skills_t0 / 7 |
| 8 | Acid Geyser | acid | NEEDS ART | slime_lord__skills_t0 / 8 |
| 9 | Primordial Flood | acid | NEEDS ART | slime_lord__skills_t0 / 9 |

### Skill tree 2: Spawn

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Spawn Slimeling | acid | HAS ART (creature portrait) | slime_lord__skills_t1 / 1 |
| 2 | Mitosis | acid | HAS ART (creature portrait) | slime_lord__skills_t1 / 2 |
| 3 | Sap Mender | poison | HAS ART (creature portrait) | slime_lord__skills_t1 / 3 |
| 4 | Volatile Brood | acid | HAS ART (creature portrait) | slime_lord__skills_t1 / 4 |
| 5 | Frost Sage | cold | HAS ART (creature portrait) | slime_lord__skills_t1 / 5 |
| 6 | Cannibalize | acid | NEEDS ART | slime_lord__skills_t1 / 6 |
| 7 | Ooze Titan | acid | HAS ART (creature portrait) | slime_lord__skills_t1 / 7 |
| 8 | Slime Hivemind | acid | NEEDS ART | slime_lord__skills_t1 / 8 |
| 9 | Mother Ooze | acid | HAS ART (creature portrait) | slime_lord__skills_t1 / 9 |

### Skill tree 3: Mutation

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Body Slam | acid | NEEDS ART | slime_lord__skills_t2 / 1 |
| 2 | Bounce | acid | NEEDS ART | slime_lord__skills_t2 / 2 |
| 3 | Tendril Lash | acid | NEEDS ART | slime_lord__skills_t2 / 3 |
| 4 | Slime Armor | acid | NEEDS ART | slime_lord__skills_t2 / 4 |
| 5 | Engulf | acid | NEEDS ART | slime_lord__skills_t2 / 5 |
| 6 | Rolling Blob | acid | NEEDS ART | slime_lord__skills_t2 / 6 |
| 7 | Spike Mutation | acid | NEEDS ART | slime_lord__skills_t2 / 7 |
| 8 | Colossal Form | acid | NEEDS ART | slime_lord__skills_t2 / 8 |
| 9 | Slime God | acid | NEEDS ART | slime_lord__skills_t2 / 9 |

### Skill tree 4: Primordial

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Primal Glob | acid | NEEDS ART | slime_lord__skills_t3 / 1 |
| 2 | Cell Split | acid | HAS ART (creature portrait) | slime_lord__skills_t3 / 2 |
| 3 | Primordial Soup | acid | NEEDS ART | slime_lord__skills_t3 / 3 |
| 4 | Prismatic Jelly | light | HAS ART (creature portrait) | slime_lord__skills_t3 / 4 |
| 5 | Gloop Cannon | acid | NEEDS ART | slime_lord__skills_t3 / 5 |
| 6 | Jelly Rampart | acid | NEEDS ART | slime_lord__skills_t3 / 6 |
| 7 | Primeval Downpour | acid | NEEDS ART | slime_lord__skills_t3 / 7 |
| 8 | Devour Whole | acid | NEEDS ART | slime_lord__skills_t3 / 8 |
| 9 | Primordial Singularity | acid | NEEDS ART | slime_lord__skills_t3 / 9 |

### Talent branch 1: Caustic Tide

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Corrosive Enzymes | acid | NEEDS ART | slime_lord__talents_b0 / 1 |
| 2 | Mitotic Globs | acid | NEEDS ART | slime_lord__talents_b0 / 2 |
| 3 | Thermite Sludge | fire | NEEDS ART | slime_lord__talents_b0 / 3 |
| 4 | Melting Point | acid | NEEDS ART | slime_lord__talents_b0 / 4 |
| 5 | Quicksand Mire | acid | NEEDS ART | slime_lord__talents_b0 / 5 |
| 6 | Subzero Gel | cold | NEEDS ART | slime_lord__talents_b0 / 6 |
| 7 | Universal Solvent | acid | NEEDS ART | slime_lord__talents_b0 / 7 |
| 8 | Chromatic Ooze | arcane | NEEDS ART | slime_lord__talents_b0 / 8 |

### Talent branch 2: Royal Slime Court

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Royal Jelly | acid | NEEDS ART | slime_lord__talents_b1 / 1 |
| 2 | Crimson Berserker Brood | fire | NEEDS ART | slime_lord__talents_b1 / 2 |
| 3 | Gilded Bulwark Court | holy | NEEDS ART | slime_lord__talents_b1 / 3 |
| 4 | Hivemind Link | poison | NEEDS ART | slime_lord__talents_b1 / 4 |
| 5 | Void Hexer Cabal | shadow | NEEDS ART | slime_lord__talents_b1 / 5 |
| 6 | Colossal Fusion | acid | NEEDS ART | slime_lord__talents_b1 / 6 |
| 7 | Legion of Gel | acid | NEEDS ART | slime_lord__talents_b1 / 7 |
| 8 | Serenade of Glymmora | holy | NEEDS ART | slime_lord__talents_b1 / 8 |

### Talent branch 3: Apex Amoeba

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Elastic Mass | phys | NEEDS ART | slime_lord__talents_b2 / 1 |
| 2 | Meteor Bounce | acid | NEEDS ART | slime_lord__talents_b2 / 2 |
| 3 | Vampiric Pseudopods | blood | NEEDS ART | slime_lord__talents_b2 / 3 |
| 4 | Shock-Absorbing Gel | phys | NEEDS ART | slime_lord__talents_b2 / 4 |
| 5 | Toxic Spines | poison | NEEDS ART | slime_lord__talents_b2 / 5 |
| 6 | Kaiju Overgrowth | acid | NEEDS ART | slime_lord__talents_b2 / 6 |
| 7 | Split & Reform | acid | NEEDS ART | slime_lord__talents_b2 / 7 |
| 8 | Unstoppable Mass | phys | NEEDS ART | slime_lord__talents_b2 / 8 |

**Ultimate:** Royal Deluge (poison): NEEDS ART, ultimates_2 / cell 3

## Boomerang Knight

Dashing knight whose curved blade-boomerangs always come back to his hand: ricochets, swirling sword storms, gale cyclones. Steel, teal wind, gold trim, motion arcs.

### Skill tree 1: Throwing

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Curved Boomerang | phys | NEEDS ART | boomerang_knight__skills_t0 / 1 |
| 2 | Twin Boomerangs | phys | NEEDS ART | boomerang_knight__skills_t0 / 2 |
| 3 | Chakram | phys | NEEDS ART | boomerang_knight__skills_t0 / 3 |
| 4 | Heavy Rang | phys | NEEDS ART | boomerang_knight__skills_t0 / 4 |
| 5 | Seeking Rang | phys | NEEDS ART | boomerang_knight__skills_t0 / 5 |
| 6 | Ricochet Rang | phys | NEEDS ART | boomerang_knight__skills_t0 / 6 |
| 7 | Buzzsaw | phys | NEEDS ART | boomerang_knight__skills_t0 / 7 |
| 8 | Catch & Release | phys | NEEDS ART | boomerang_knight__skills_t0 / 8 |
| 9 | Horizon Rang | arcane | NEEDS ART | boomerang_knight__skills_t0 / 9 |

### Skill tree 2: Bladesmanship

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Cross Cut | phys | NEEDS ART | boomerang_knight__skills_t1 / 1 |
| 2 | Wind Slash | phys | NEEDS ART | boomerang_knight__skills_t1 / 2 |
| 3 | Gale Rush | phys | NEEDS ART | boomerang_knight__skills_t1 / 3 |
| 4 | Blade Barrier | phys | NEEDS ART | boomerang_knight__skills_t1 / 4 |
| 5 | Whirling Slash | phys | NEEDS ART | boomerang_knight__skills_t1 / 5 |
| 6 | Blade Flurry | phys | NEEDS ART | boomerang_knight__skills_t1 / 6 |
| 7 | Razor Wind Arc | phys | NEEDS ART | boomerang_knight__skills_t1 / 7 |
| 8 | Bladestorm Dance | phys | NEEDS ART | boomerang_knight__skills_t1 / 8 |
| 9 | Executioner's Guillotine | blood | NEEDS ART | boomerang_knight__skills_t1 / 9 |

### Skill tree 3: Gale Knight

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Gust | phys | NEEDS ART | boomerang_knight__skills_t2 / 1 |
| 2 | Gale Vortex | phys | NEEDS ART | boomerang_knight__skills_t2 / 2 |
| 3 | Tailwind Aura | phys | NEEDS ART | boomerang_knight__skills_t2 / 3 |
| 4 | Wind Spout | phys | NEEDS ART | boomerang_knight__skills_t2 / 4 |
| 5 | Razor Tornado | phys | NEEDS ART | boomerang_knight__skills_t2 / 5 |
| 6 | Tempest Dash | light | NEEDS ART | boomerang_knight__skills_t2 / 6 |
| 7 | Sky Cutter | phys | NEEDS ART | boomerang_knight__skills_t2 / 7 |
| 8 | Eye of the Hurricane | light | NEEDS ART | boomerang_knight__skills_t2 / 8 |
| 9 | Cataclysmic Typhoon | cold | NEEDS ART | boomerang_knight__skills_t2 / 9 |

### Skill tree 4: Tempest Orbit

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Orbiting Rang | phys | NEEDS ART | boomerang_knight__skills_t3 / 1 |
| 2 | Chakram Shield | phys | NEEDS ART | boomerang_knight__skills_t3 / 2 |
| 3 | Blade Ring Nova | phys | NEEDS ART | boomerang_knight__skills_t3 / 3 |
| 4 | Gale Barrier | light | NEEDS ART | boomerang_knight__skills_t3 / 4 |
| 5 | Tri-Chakram Orbit | light | NEEDS ART | boomerang_knight__skills_t3 / 5 |
| 6 | Slicing Maelstrom | phys | NEEDS ART | boomerang_knight__skills_t3 / 6 |
| 7 | Razor Ring Fissure | phys | NEEDS ART | boomerang_knight__skills_t3 / 7 |
| 8 | Tempest Sovereign | light | NEEDS ART | boomerang_knight__skills_t3 / 8 |
| 9 | Supernova Vortex | light | NEEDS ART | boomerang_knight__skills_t3 / 9 |

### Talent branch 1: Returning Glaives

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Aerodynamic Edge | phys | NEEDS ART | boomerang_knight__talents_b0 / 1 |
| 2 | Sunfire Chakrams | fire | NEEDS ART | boomerang_knight__talents_b0 / 2 |
| 3 | Voltaic Ricochet | light | NEEDS ART | boomerang_knight__talents_b0 / 3 |
| 4 | Momentum Catch | phys | NEEDS ART | boomerang_knight__talents_b0 / 4 |
| 5 | Sawtooth Cleaver | blood | NEEDS ART | boomerang_knight__talents_b0 / 5 |
| 6 | Phantom Return | arcane | NEEDS ART | boomerang_knight__talents_b0 / 6 |
| 7 | Master of a Thousand Glaives | phys | NEEDS ART | boomerang_knight__talents_b0 / 7 |
| 8 | Red Horizon | blood | NEEDS ART | boomerang_knight__talents_b0 / 8 |

### Talent branch 2: Bladedancer

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Whirling Footwork | phys | NEEDS ART | boomerang_knight__talents_b1 / 1 |
| 2 | Cyclone Edge | phys | NEEDS ART | boomerang_knight__talents_b1 / 2 |
| 3 | Storm Crescents | light | NEEDS ART | boomerang_knight__talents_b1 / 3 |
| 4 | Deflecting Gyre | phys | NEEDS ART | boomerang_knight__talents_b1 / 4 |
| 5 | Relentless Rush | phys | NEEDS ART | boomerang_knight__talents_b1 / 5 |
| 6 | Ring of Steel | arcane | NEEDS ART | boomerang_knight__talents_b1 / 6 |
| 7 | Eternal Dervish | phys | NEEDS ART | boomerang_knight__talents_b1 / 7 |
| 8 | Second Wind | cold | NEEDS ART | boomerang_knight__talents_b1 / 8 |

### Talent branch 3: Tempest Sovereign

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Howling Jetstream | cold | NEEDS ART | boomerang_knight__talents_b2 / 1 |
| 2 | Arctic Cyclones | cold | NEEDS ART | boomerang_knight__talents_b2 / 2 |
| 3 | Storm Eye | light | NEEDS ART | boomerang_knight__talents_b2 / 3 |
| 4 | Eye of the Gale | light | NEEDS ART | boomerang_knight__talents_b2 / 4 |
| 5 | Shredding Squall | phys | NEEDS ART | boomerang_knight__talents_b2 / 5 |
| 6 | Sanctified Tailwind | holy | NEEDS ART | boomerang_knight__talents_b2 / 6 |
| 7 | Avatar of the Typhoon | light | NEEDS ART | boomerang_knight__talents_b2 / 7 |
| 8 | Perpetual Gyre | arcane | NEEDS ART | boomerang_knight__talents_b2 / 8 |

**Ultimate:** Cyclone Tempest (phys): NEEDS ART, ultimates_2 / cell 4

## Lancer

Unbreakable knight-captain with a huge elemental energy lance, tower shields circling him (up to ten), a war banner and an order of knights at his back. Lightning white-blue, gold and steel.

### Skill tree 1: Energy Lance

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Lance Thrust | light | NEEDS ART | lancer__skills_t0 / 1 |
| 2 | Lance Charge | light | NEEDS ART | lancer__skills_t0 / 2 |
| 3 | Lance Barrage | arcane | NEEDS ART | lancer__skills_t0 / 3 |
| 4 | Lance of Light | holy | NEEDS ART | lancer__skills_t0 / 4 |
| 5 | Sweeping Cleave | phys | NEEDS ART | lancer__skills_t0 / 5 |
| 6 | Sunspear | holy | NEEDS ART | lancer__skills_t0 / 6 |
| 7 | Storm Lance | light | NEEDS ART | lancer__skills_t0 / 7 |
| 8 | Lance of Ruin | shadow | NEEDS ART | lancer__skills_t0 / 8 |
| 9 | Prismatic Lance | arcane | NEEDS ART | lancer__skills_t0 / 9 |

### Skill tree 2: Bulwark

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Tower Shield | phys | NEEDS ART | lancer__skills_t1 / 1 |
| 2 | Shield Slam | phys | NEEDS ART | lancer__skills_t1 / 2 |
| 3 | Shield Wall | phys | NEEDS ART | lancer__skills_t1 / 3 |
| 4 | Shield Throw | phys | NEEDS ART | lancer__skills_t1 / 4 |
| 5 | Bulwark Nova | phys | NEEDS ART | lancer__skills_t1 / 5 |
| 6 | Spear Wall | phys | NEEDS ART | lancer__skills_t1 / 6 |
| 7 | Ironclad Juggernaut | phys | NEEDS ART | lancer__skills_t1 / 7 |
| 8 | Bastion of Ten | light | NEEDS ART | lancer__skills_t1 / 8 |
| 9 | Living Fortress | holy | NEEDS ART | lancer__skills_t1 / 9 |

### Skill tree 3: Knight Order

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Squire Knight | phys | HAS ART (creature portrait) | lancer__skills_t2 / 1 |
| 2 | Rallying Cry | holy | NEEDS ART | lancer__skills_t2 / 2 |
| 3 | War Banner | holy | HAS ART (creature portrait) | lancer__skills_t2 / 3 |
| 4 | Knight Captain | holy | HAS ART (creature portrait) | lancer__skills_t2 / 4 |
| 5 | Hold the Line | phys | NEEDS ART | lancer__skills_t2 / 5 |
| 6 | Shout of Valor | holy | NEEDS ART | lancer__skills_t2 / 6 |
| 7 | Valiant Leap | holy | NEEDS ART | lancer__skills_t2 / 7 |
| 8 | Knights of the Round | holy | HAS ART (creature portrait) | lancer__skills_t2 / 8 |
| 9 | Hero's Ascension | holy | NEEDS ART | lancer__skills_t2 / 9 |

### Skill tree 4: Radiant Lance

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Radiant Thrust | holy | NEEDS ART | lancer__skills_t3 / 1 |
| 2 | Shield Disc | holy | NEEDS ART | lancer__skills_t3 / 2 |
| 3 | Sunlance Volley | holy | NEEDS ART | lancer__skills_t3 / 3 |
| 4 | Holy Bastion | holy | NEEDS ART | lancer__skills_t3 / 4 |
| 5 | Phalanx Leap | holy | NEEDS ART | lancer__skills_t3 / 5 |
| 6 | Spear Rain | holy | NEEDS ART | lancer__skills_t3 / 6 |
| 7 | Solar Lancestorm | holy | NEEDS ART | lancer__skills_t3 / 7 |
| 8 | Paragon Form | holy | NEEDS ART | lancer__skills_t3 / 8 |
| 9 | Final Lance | holy | NEEDS ART | lancer__skills_t3 / 9 |

### Talent branch 1: Vanguard Joust

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Couched Momentum | phys | NEEDS ART | lancer__talents_b0 / 1 |
| 2 | Breakthrough Charge | phys | NEEDS ART | lancer__talents_b0 / 2 |
| 3 | Solar Joust | fire | NEEDS ART | lancer__talents_b0 / 3 |
| 4 | Heartpiercer | light | NEEDS ART | lancer__talents_b0 / 4 |
| 5 | Thunderlance Conduit | light | NEEDS ART | lancer__talents_b0 / 5 |
| 6 | Longinus Ray | holy | NEEDS ART | lancer__talents_b0 / 6 |
| 7 | Paragon of the Sunlance | holy | NEEDS ART | lancer__talents_b0 / 7 |
| 8 | Thunderous Cavalry | phys | NEEDS ART | lancer__talents_b0 / 8 |

### Talent branch 2: Phalanx Bulwark

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Tower Pavise | phys | NEEDS ART | lancer__talents_b1 / 1 |
| 2 | Whirling Pavise | phys | NEEDS ART | lancer__talents_b1 / 2 |
| 3 | Sun-Disc Ricochet | holy | NEEDS ART | lancer__talents_b1 / 3 |
| 4 | Iron Resolve | phys | NEEDS ART | lancer__talents_b1 / 4 |
| 5 | Furnace Bastion | fire | NEEDS ART | lancer__talents_b1 / 5 |
| 6 | Cathedral Wall | holy | NEEDS ART | lancer__talents_b1 / 6 |
| 7 | Last Stand of the Ten | phys | NEEDS ART | lancer__talents_b1 / 7 |
| 8 | Walking Citadel | phys | NEEDS ART | lancer__talents_b1 / 8 |

### Talent branch 3: Grand Knight Order

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Oath of Chivalry | holy | NEEDS ART | lancer__talents_b2 / 1 |
| 2 | Order of the Flame | fire | NEEDS ART | lancer__talents_b2 / 2 |
| 3 | Order of the Rime Pavise | cold | NEEDS ART | lancer__talents_b2 / 3 |
| 4 | Marshal Command | holy | NEEDS ART | lancer__talents_b2 / 4 |
| 5 | Banner of Kings | holy | NEEDS ART | lancer__talents_b2 / 5 |
| 6 | Stormblade Captains | light | NEEDS ART | lancer__talents_b2 / 6 |
| 7 | High King of the Round | holy | NEEDS ART | lancer__talents_b2 / 7 |
| 8 | Champion of the Realm | arcane | NEEDS ART | lancer__talents_b2 / 8 |

**Ultimate:** Gungnir's Fall (light): NEEDS ART, ultimates_2 / cell 5

## Dragon Knight

Knight with the blood of the wyrm: fire breath, red dragon-scale armor, draconic wings, finally becoming a dragon. Crimson, ember orange, gold.

### Skill tree 1: Flame

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Dragon Fang Strike | fire | NEEDS ART | dragon_knight__skills_t0 / 1 |
| 2 | Fire Breath | fire | NEEDS ART | dragon_knight__skills_t0 / 2 |
| 3 | Fireball Spit | fire | NEEDS ART | dragon_knight__skills_t0 / 3 |
| 4 | Flame Nova | fire | NEEDS ART | dragon_knight__skills_t0 / 4 |
| 5 | Molten Fissure | fire | NEEDS ART | dragon_knight__skills_t0 / 5 |
| 6 | Fire Aura | fire | NEEDS ART | dragon_knight__skills_t0 / 6 |
| 7 | Magma Geyser | fire | NEEDS ART | dragon_knight__skills_t0 / 7 |
| 8 | Inferno Breath | fire | NEEDS ART | dragon_knight__skills_t0 / 8 |
| 9 | Cataclysm of Flame | fire | NEEDS ART | dragon_knight__skills_t0 / 9 |

### Skill tree 2: Scale

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Dragon Claw | phys | NEEDS ART | dragon_knight__skills_t1 / 1 |
| 2 | Dragon Scales | fire | NEEDS ART | dragon_knight__skills_t1 / 2 |
| 3 | Tail Swipe | phys | NEEDS ART | dragon_knight__skills_t1 / 3 |
| 4 | Dragon Charge | phys | NEEDS ART | dragon_knight__skills_t1 / 4 |
| 5 | Spiked Carapace | fire | NEEDS ART | dragon_knight__skills_t1 / 5 |
| 6 | Draconic Roar | fire | NEEDS ART | dragon_knight__skills_t1 / 6 |
| 7 | Dragon Leap | fire | NEEDS ART | dragon_knight__skills_t1 / 7 |
| 8 | Dragon Heart | fire | NEEDS ART | dragon_knight__skills_t1 / 8 |
| 9 | Ironclad Wyrmform | phys | NEEDS ART | dragon_knight__skills_t1 / 9 |

### Skill tree 3: Draconic

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Drake Whelp | fire | HAS ART (creature portrait) | dragon_knight__skills_t2 / 1 |
| 2 | Dragon Wings | fire | NEEDS ART | dragon_knight__skills_t2 / 2 |
| 3 | Blood Frenzy | blood | NEEDS ART | dragon_knight__skills_t2 / 3 |
| 4 | Wyvern Spirit | fire | HAS ART (creature portrait) | dragon_knight__skills_t2 / 4 |
| 5 | Dragon Fear | fire | NEEDS ART | dragon_knight__skills_t2 / 5 |
| 6 | Wyrm Coil | fire | NEEDS ART | dragon_knight__skills_t2 / 6 |
| 7 | Elder Red Drake | fire | HAS ART (creature portrait) | dragon_knight__skills_t2 / 7 |
| 8 | Dragonflight Swarm | fire | HAS ART (creature portrait) | dragon_knight__skills_t2 / 8 |
| 9 | True Dragon Form | fire | NEEDS ART | dragon_knight__skills_t2 / 9 |

### Skill tree 4: Wyrmfire Ascendant

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Wyrmfire Thrust | arcane | NEEDS ART | dragon_knight__skills_t3 / 1 |
| 2 | Prism Breath | arcane | NEEDS ART | dragon_knight__skills_t3 / 2 |
| 3 | Meteor Impact | fire | NEEDS ART | dragon_knight__skills_t3 / 3 |
| 4 | Wyrmfire Barrier | arcane | NEEDS ART | dragon_knight__skills_t3 / 4 |
| 5 | Dragon Tempest | fire | NEEDS ART | dragon_knight__skills_t3 / 5 |
| 6 | Sovereign Roar | fire | NEEDS ART | dragon_knight__skills_t3 / 6 |
| 7 | Sunfall Dragon Dive | fire | NEEDS ART | dragon_knight__skills_t3 / 7 |
| 8 | Avatar of the Wyrm | arcane | NEEDS ART | dragon_knight__skills_t3 / 8 |
| 9 | Judgment of the Dragon King | fire | NEEDS ART | dragon_knight__skills_t3 / 9 |

### Talent branch 1: Inferno Maw

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Furnace Heart | fire | NEEDS ART | dragon_knight__talents_b0 / 1 |
| 2 | Glacial Wyrmfire | cold | NEEDS ART | dragon_knight__talents_b0 / 2 |
| 3 | Hellfire Bombard | fire | NEEDS ART | dragon_knight__talents_b0 / 3 |
| 4 | Searing Maw | fire | NEEDS ART | dragon_knight__talents_b0 / 4 |
| 5 | Chromatic Breath | arcane | NEEDS ART | dragon_knight__talents_b0 / 5 |
| 6 | Living Cinder | fire | NEEDS ART | dragon_knight__talents_b0 / 6 |
| 7 | Calamity Wyrm | fire | NEEDS ART | dragon_knight__talents_b0 / 7 |
| 8 | Sovereign Wyrmking | holy | NEEDS ART | dragon_knight__talents_b0 / 8 |

### Talent branch 2: Obsidian Scales

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Obsidian Hide | phys | NEEDS ART | dragon_knight__talents_b1 / 1 |
| 2 | Thunderous Claws | light | NEEDS ART | dragon_knight__talents_b1 / 2 |
| 3 | Comet Rush | fire | NEEDS ART | dragon_knight__talents_b1 / 3 |
| 4 | Adamantine Ridge | phys | NEEDS ART | dragon_knight__talents_b1 / 4 |
| 5 | Magma Carapace | fire | NEEDS ART | dragon_knight__talents_b1 / 5 |
| 6 | Immortal Dragonheart | holy | NEEDS ART | dragon_knight__talents_b1 / 6 |
| 7 | Heart of the Immortal Wyrm | fire | NEEDS ART | dragon_knight__talents_b1 / 7 |
| 8 | Dreadnought Wyrm | phys | NEEDS ART | dragon_knight__talents_b1 / 8 |

### Talent branch 3: Elder Dragonflight

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Broodlord Kinship | fire | NEEDS ART | dragon_knight__talents_b2 / 1 |
| 2 | Twin Wyverns | fire | NEEDS ART | dragon_knight__talents_b2 / 2 |
| 3 | Frostwyrm Brood | cold | NEEDS ART | dragon_knight__talents_b2 / 3 |
| 4 | Wings of Dominion | fire | NEEDS ART | dragon_knight__talents_b2 / 4 |
| 5 | Cloud of Wings | fire | NEEDS ART | dragon_knight__talents_b2 / 5 |
| 6 | Awakened Aspect | fire | NEEDS ART | dragon_knight__talents_b2 / 6 |
| 7 | Progenitor of Dragons | fire | NEEDS ART | dragon_knight__talents_b2 / 7 |
| 8 | True Aspect | arcane | NEEDS ART | dragon_knight__talents_b2 / 8 |

**Ultimate:** Dragon's Inferno (fire): NEEDS ART, ultimates_2 / cell 6

## Gunner

Powder-stained engineer: pistols and rifles (bullet hell), rockets and grenades, turrets, drones, a biplane bombing run and a death laser. Brass, gunmetal, smoke, muzzle-flash orange.

### Skill tree 1: Firearms

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Burst Fire | phys | NEEDS ART | gunner__skills_t0 / 1 |
| 2 | Shotgun Blast | phys | NEEDS ART | gunner__skills_t0 / 2 |
| 3 | Piercing Shot | phys | NEEDS ART | gunner__skills_t0 / 3 |
| 4 | Snipe | phys | NEEDS ART | gunner__skills_t0 / 4 |
| 5 | Full Auto | phys | NEEDS ART | gunner__skills_t0 / 5 |
| 6 | Magnum Execution | phys | NEEDS ART | gunner__skills_t0 / 6 |
| 7 | Gunslinger Stance | phys | NEEDS ART | gunner__skills_t0 / 7 |
| 8 | Minigun Fury | phys | NEEDS ART | gunner__skills_t0 / 8 |
| 9 | Orbital Death Laser | fire | NEEDS ART | gunner__skills_t0 / 9 |

### Skill tree 2: Explosives

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Frag Grenade | fire | NEEDS ART | gunner__skills_t1 / 1 |
| 2 | Landmine | fire | NEEDS ART | gunner__skills_t1 / 2 |
| 3 | Smoke Grenade | shadow | NEEDS ART | gunner__skills_t1 / 3 |
| 4 | Rocket Launcher | fire | NEEDS ART | gunner__skills_t1 / 4 |
| 5 | Napalm Zone | fire | NEEDS ART | gunner__skills_t1 / 5 |
| 6 | Sticky Bomb | fire | NEEDS ART | gunner__skills_t1 / 6 |
| 7 | Carpet Bomb | fire | NEEDS ART | gunner__skills_t1 / 7 |
| 8 | Rocket Barrage | fire | NEEDS ART | gunner__skills_t1 / 8 |
| 9 | Tactical Nuke | fire | NEEDS ART | gunner__skills_t1 / 9 |

### Skill tree 3: Engineering

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Gun Turret | phys | HAS ART (creature portrait) | gunner__skills_t2 / 1 |
| 2 | Support Drone | light | HAS ART (creature portrait) | gunner__skills_t2 / 2 |
| 3 | Repair Kit | phys | NEEDS ART | gunner__skills_t2 / 3 |
| 4 | Tesla Coil | light | HAS ART (creature portrait) | gunner__skills_t2 / 4 |
| 5 | Shield Generator | arcane | NEEDS ART | gunner__skills_t2 / 5 |
| 6 | Overclock | light | NEEDS ART | gunner__skills_t2 / 6 |
| 7 | Laser Fence | light | NEEDS ART | gunner__skills_t2 / 7 |
| 8 | Mech Suit | phys | NEEDS ART | gunner__skills_t2 / 8 |
| 9 | War Machine | fire | HAS ART (creature portrait) | gunner__skills_t2 / 9 |

### Skill tree 4: Heavy Ordnance

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Heavy Shell | phys | NEEDS ART | gunner__skills_t3 / 1 |
| 2 | Incendiary Shell | fire | NEEDS ART | gunner__skills_t3 / 2 |
| 3 | Flak Vest | phys | NEEDS ART | gunner__skills_t3 / 3 |
| 4 | Concussion Grenade | phys | NEEDS ART | gunner__skills_t3 / 4 |
| 5 | Cryo Shell | cold | NEEDS ART | gunner__skills_t3 / 5 |
| 6 | Rail Shot | light | NEEDS ART | gunner__skills_t3 / 6 |
| 7 | Drone Swarm Pod | fire | HAS ART (creature portrait) | gunner__skills_t3 / 7 |
| 8 | Saturation Bombing | fire | NEEDS ART | gunner__skills_t3 / 8 |
| 9 | Annihilator Beam | light | NEEDS ART | gunner__skills_t3 / 9 |

### Talent branch 1: Deadshot Arsenal

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Rifled Barrels | phys | NEEDS ART | gunner__talents_b0 / 1 |
| 2 | Full-Metal Salvo | phys | NEEDS ART | gunner__talents_b0 / 2 |
| 3 | Subzero Rounds | cold | NEEDS ART | gunner__talents_b0 / 3 |
| 4 | Hair Trigger | phys | NEEDS ART | gunner__talents_b0 / 4 |
| 5 | Gauss Accelerator | light | NEEDS ART | gunner__talents_b0 / 5 |
| 6 | Dragonbreath Belt | fire | NEEDS ART | gunner__talents_b0 / 6 |
| 7 | High Noon Desperado | phys | NEEDS ART | gunner__talents_b0 / 7 |
| 8 | Experimental Plasma Core | light | NEEDS ART | gunner__talents_b0 / 8 |

### Talent branch 2: Demolitions

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | High-Yield Payload | fire | NEEDS ART | gunner__talents_b1 / 1 |
| 2 | MIRV Cluster Shells | fire | NEEDS ART | gunner__talents_b1 / 2 |
| 3 | White Phosphorus | fire | NEEDS ART | gunner__talents_b1 / 3 |
| 4 | Flak Plating | phys | NEEDS ART | gunner__talents_b1 / 4 |
| 5 | Implosion Charges | arcane | NEEDS ART | gunner__talents_b1 / 5 |
| 6 | Perimeter Defense | fire | NEEDS ART | gunner__talents_b1 / 6 |
| 7 | Carpet Bombardier | fire | NEEDS ART | gunner__talents_b1 / 7 |
| 8 | Emergency Protocol | fire | NEEDS ART | gunner__talents_b1 / 8 |

### Talent branch 3: Mechanist Corps

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Precision Servos | light | NEEDS ART | gunner__talents_b2 / 1 |
| 2 | Heavy Rocket Sentries | fire | NEEDS ART | gunner__talents_b2 / 2 |
| 3 | Cryo-Beam Sentries | cold | NEEDS ART | gunner__talents_b2 / 3 |
| 4 | High-Capacity Grid | light | NEEDS ART | gunner__talents_b2 / 4 |
| 5 | Kamikaze Drone Bay | fire | NEEDS ART | gunner__talents_b2 / 5 |
| 6 | Overclocked Generators | light | NEEDS ART | gunner__talents_b2 / 6 |
| 7 | Supreme Engineer | light | NEEDS ART | gunner__talents_b2 / 7 |
| 8 | Goliath Protocol | fire | NEEDS ART | gunner__talents_b2 / 8 |

**Ultimate:** Siege Artillery (fire): NEEDS ART, ultimates_2 / cell 7

## Monk

Bald martial artist in saffron robes: palm strikes, flying kicks, temple bells, chi light.

### Skill tree 1: Martial Arts

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Fist of Fury | phys | HAS ART | - |
| 2 | Flying Kick | phys | HAS ART | - |
| 3 | Sweeping Crescent | phys | HAS ART | - |
| 4 | Hundred Fists | phys | HAS ART | - |
| 5 | Iron Palm | phys | HAS ART | - |
| 6 | Spinning Crane Kick | phys | HAS ART | - |
| 7 | Quivering Palm | phys | HAS ART | - |
| 8 | Asura Stance | phys | HAS ART | - |
| 9 | Grandmaster Flurry | phys | HAS ART | - |

### Skill tree 2: Spirit & Mantras

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Chi Bolt | holy | HAS ART | - |
| 2 | Mantra of Healing | holy | HAS ART | - |
| 3 | Radiant Bell | holy | HAS ART | - |
| 4 | Inner Peace | holy | HAS ART | - |
| 5 | Mantra of Retribution | holy | HAS ART | - |
| 6 | Spirit Chains | holy | HAS ART | - |
| 7 | Purifying Wave | holy | HAS ART | - |
| 8 | Pillar of Nirvana | holy | HAS ART | - |
| 9 | Avatar of Enlightenment | holy | HAS ART | - |

### Skill tree 3: Dragon & Tiger

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Dragon Strike | fire | HAS ART | - |
| 2 | Tiger Pounce | fire | HAS ART | - |
| 3 | Flaming Lotus | fire | HAS ART | - |
| 4 | Breath of the Wyrm | fire | HAS ART | - |
| 5 | Tiger Roar | phys | HAS ART | - |
| 6 | Fiery Ascent | fire | HAS ART | - |
| 7 | Inferno Palm | fire | HAS ART | - |
| 8 | Dragon Tempest | fire | HAS ART | - |
| 9 | Cataclysmic Dragon Slam | fire | HAS ART | - |

### Skill tree 4: Transcendence

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Palm of the Dawn | holy | HAS ART | - |
| 2 | Resonating Bellstrike | holy | HAS ART | - |
| 3 | Zen Dash | holy | HAS ART | - |
| 4 | Orbiting Prayer Beads | holy | HAS ART | - |
| 5 | Sweeping Gale | phys | HAS ART | - |
| 6 | Wave of Light | holy | HAS ART | - |
| 7 | Chakras Open | holy | HAS ART | - |
| 8 | Heavenly Palm | holy | HAS ART | - |
| 9 | Nirvana Flash | holy | HAS ART | - |

### Talent branch 1: Way of the Hundred Fists

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Flowing Tempo | phys | HAS ART | - |
| 2 | Fists of Thunder | light | HAS ART | - |
| 3 | Cyclone Strike | phys | HAS ART | - |
| 4 | Sixth Sense | phys | HAS ART | - |
| 5 | Sundering Palm | blood | HAS ART | - |
| 6 | Dashing Strike | light | HAS ART | - |
| 7 | Six-Armed Asura | phys | HAS ART | - |
| 8 | Touch of Death | blood | HAS ART | - |

### Talent branch 2: Enlightened Spirit

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Harmony | holy | HAS ART | - |
| 2 | Golden Temple Bell | holy | HAS ART | - |
| 3 | Sacred Rosary | holy | HAS ART | - |
| 4 | Diamond Mind | holy | HAS ART | - |
| 5 | Resounding Mantras | holy | HAS ART | - |
| 6 | Sanctuary of Nirvana | holy | HAS ART | - |
| 7 | Near Death Experience | holy | HAS ART | - |
| 8 | Enlightened Avatar | holy | HAS ART | - |

### Talent branch 3: Dragon & White Tiger

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Blazing Meridians | fire | HAS ART | - |
| 2 | Vermilion Bird Talons | fire | HAS ART | - |
| 3 | White Tiger Frostfang | cold | HAS ART | - |
| 4 | Four Beasts Stance | fire | HAS ART | - |
| 5 | Coiling Firestorm | fire | HAS ART | - |
| 6 | King of Beasts | phys | HAS ART | - |
| 7 | Avatar of the Crimson Dragon | fire | HAS ART | - |
| 8 | Wrath of the White Tiger | cold | HAS ART | - |

**Ultimate:** Seven-Sided Strike (holy): NEEDS ART, ultimates_2 / cell 8

## Rogue

Black-leather assassin from the shuttered guilds with twin reverse-grip daggers; she lurks in shadow, builds combo points and spends them on bloody finishers. Crimson, black, steel.

### Skill tree 1: Assassination

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Sinister Strike | phys | NEEDS ART | rogue__skills_t0 / 1 |
| 2 | Eviscerate | blood | NEEDS ART | rogue__skills_t0 / 2 |
| 3 | Backstab | shadow | NEEDS ART | rogue__skills_t0 / 3 |
| 4 | Rupture | blood | NEEDS ART | rogue__skills_t0 / 4 |
| 5 | Mutilate | poison | NEEDS ART | rogue__skills_t0 / 5 |
| 6 | Kidney Shot | phys | NEEDS ART | rogue__skills_t0 / 6 |
| 7 | Envenom | poison | NEEDS ART | rogue__skills_t0 / 7 |
| 8 | Vendetta | blood | NEEDS ART | rogue__skills_t0 / 8 |
| 9 | Death from Above | blood | NEEDS ART | rogue__skills_t0 / 9 |

### Skill tree 2: Subtlety

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Shadowstrike | shadow | NEEDS ART | rogue__skills_t1 / 1 |
| 2 | Stealth | shadow | NEEDS ART | rogue__skills_t1 / 2 |
| 3 | Smoke Bomb | shadow | NEEDS ART | rogue__skills_t1 / 3 |
| 4 | Cheap Shot | phys | NEEDS ART | rogue__skills_t1 / 4 |
| 5 | Shadowstep | shadow | NEEDS ART | rogue__skills_t1 / 5 |
| 6 | Shadow Dance | shadow | NEEDS ART | rogue__skills_t1 / 6 |
| 7 | Marked for Death | blood | NEEDS ART | rogue__skills_t1 / 7 |
| 8 | Cloak of Shadows | shadow | NEEDS ART | rogue__skills_t1 / 8 |
| 9 | Secret Technique | shadow | NEEDS ART | rogue__skills_t1 / 9 |

### Skill tree 3: Knives

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Throwing Knife | phys | NEEDS ART | rogue__skills_t2 / 1 |
| 2 | Fan of Knives | phys | NEEDS ART | rogue__skills_t2 / 2 |
| 3 | Ricochet Blade | phys | NEEDS ART | rogue__skills_t2 / 3 |
| 4 | Rain of Daggers | blood | NEEDS ART | rogue__skills_t2 / 4 |
| 5 | Poisoned Volley | poison | NEEDS ART | rogue__skills_t2 / 5 |
| 6 | Fangs of the Earth | blood | NEEDS ART | rogue__skills_t2 / 6 |
| 7 | Between the Eyes | phys | NEEDS ART | rogue__skills_t2 / 7 |
| 8 | Blade Flurry | phys | NEEDS ART | rogue__skills_t2 / 8 |
| 9 | Executioner's Blade | blood | NEEDS ART | rogue__skills_t2 / 9 |

### Skill tree 4: Crimson Tempest

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Hemorrhage | blood | NEEDS ART | rogue__skills_t3 / 1 |
| 2 | Crimson Tempest | blood | NEEDS ART | rogue__skills_t3 / 2 |
| 3 | Blood Dance | blood | NEEDS ART | rogue__skills_t3 / 3 |
| 4 | Exsanguinate | blood | NEEDS ART | rogue__skills_t3 / 4 |
| 5 | Blade Vortex | phys | NEEDS ART | rogue__skills_t3 / 5 |
| 6 | Crimson Vial | blood | NEEDS ART | rogue__skills_t3 / 6 |
| 7 | Thousand Cuts | blood | NEEDS ART | rogue__skills_t3 / 7 |
| 8 | Adrenaline Rush | blood | NEEDS ART | rogue__skills_t3 / 8 |
| 9 | Night of Knives | blood | NEEDS ART | rogue__skills_t3 / 9 |

### Talent branch 1: Assassin's Mark

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Honed Edges | blood | NEEDS ART | rogue__talents_b0 / 1 |
| 2 | Serrated Blades | blood | NEEDS ART | rogue__talents_b0 / 2 |
| 3 | Venomous Wounds | poison | NEEDS ART | rogue__talents_b0 / 3 |
| 4 | Relentless Strikes | phys | NEEDS ART | rogue__talents_b0 / 4 |
| 5 | Cut to the Chase | blood | NEEDS ART | rogue__talents_b0 / 5 |
| 6 | Find Weakness | shadow | NEEDS ART | rogue__talents_b0 / 6 |
| 7 | Deeper Stratagem | blood | NEEDS ART | rogue__talents_b0 / 7 |
| 8 | Crimson Harvest | blood | NEEDS ART | rogue__talents_b0 / 8 |

### Talent branch 2: Shadowcraft

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Night Stalker | shadow | NEEDS ART | rogue__talents_b1 / 1 |
| 2 | Shadow Blades | shadow | NEEDS ART | rogue__talents_b1 / 2 |
| 3 | Smoke and Mirrors | shadow | NEEDS ART | rogue__talents_b1 / 3 |
| 4 | Master of Shadows | shadow | NEEDS ART | rogue__talents_b1 / 4 |
| 5 | Premeditation | phys | NEEDS ART | rogue__talents_b1 / 5 |
| 6 | Dark Shadow | shadow | NEEDS ART | rogue__talents_b1 / 6 |
| 7 | Cheat Death | shadow | NEEDS ART | rogue__talents_b1 / 7 |
| 8 | Shadow Dancer | shadow | NEEDS ART | rogue__talents_b1 / 8 |

### Talent branch 3: Knifework

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Razor Wind | phys | NEEDS ART | rogue__talents_b2 / 1 |
| 2 | A Knife for Everyone | phys | NEEDS ART | rogue__talents_b2 / 2 |
| 3 | Trick Shots | phys | NEEDS ART | rogue__talents_b2 / 3 |
| 4 | Steel Tempest | phys | NEEDS ART | rogue__talents_b2 / 4 |
| 5 | Iron Rain | blood | NEEDS ART | rogue__talents_b2 / 5 |
| 6 | Buried Blades | blood | NEEDS ART | rogue__talents_b2 / 6 |
| 7 | Kingsbane | phys | NEEDS ART | rogue__talents_b2 / 7 |
| 8 | Red Wheel | blood | NEEDS ART | rogue__talents_b2 / 8 |

**Ultimate:** Night's Verdict (blood): NEEDS ART, ultimates_2 / cell 9

## Ninja

Silent agent of the ruined moon temple: katana, a chain hook, shuriken, caltrops, shadow clones that repeat his cuts, dragon ninpo. Midnight blue, silver moonlight, shadow purple, dragon fire.

### Skill tree 1: Way of the Blade

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Crescent Cut | phys | NEEDS ART | ninja__skills_t0 / 1 |
| 2 | Swallow's Flight | phys | NEEDS ART | ninja__skills_t0 / 2 |
| 3 | Rising Moon | phys | NEEDS ART | ninja__skills_t0 / 3 |
| 4 | Iaido | phys | NEEDS ART | ninja__skills_t0 / 4 |
| 5 | Crossing Blades | phys | NEEDS ART | ninja__skills_t0 / 5 |
| 6 | Heaven's Drop | phys | NEEDS ART | ninja__skills_t0 / 6 |
| 7 | Flowing Water | phys | NEEDS ART | ninja__skills_t0 / 7 |
| 8 | Falling Petals | phys | NEEDS ART | ninja__skills_t0 / 8 |
| 9 | Hundred-Cut Reckoning | phys | NEEDS ART | ninja__skills_t0 / 9 |

### Skill tree 2: Shadow Arts

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Shadow Step | shadow | NEEDS ART | ninja__skills_t1 / 1 |
| 2 | Mirror Shadows | shadow | NEEDS ART | ninja__skills_t1 / 2 |
| 3 | Grappling Hook | phys | NEEDS ART | ninja__skills_t1 / 3 |
| 4 | Smoke Bomb | shadow | NEEDS ART | ninja__skills_t1 / 4 |
| 5 | Shadow Bind | shadow | NEEDS ART | ninja__skills_t1 / 5 |
| 6 | Hook Swing | phys | NEEDS ART | ninja__skills_t1 / 6 |
| 7 | Umbral Legion | shadow | NEEDS ART | ninja__skills_t1 / 7 |
| 8 | Eclipse Veil | shadow | NEEDS ART | ninja__skills_t1 / 8 |
| 9 | Thousand Shadows | shadow | NEEDS ART | ninja__skills_t1 / 9 |

### Skill tree 3: Tools of War

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Shuriken | phys | NEEDS ART | ninja__skills_t2 / 1 |
| 2 | Caltrops | phys | NEEDS ART | ninja__skills_t2 / 2 |
| 3 | Kunai Burst | fire | NEEDS ART | ninja__skills_t2 / 3 |
| 4 | Windmill Shuriken | phys | NEEDS ART | ninja__skills_t2 / 4 |
| 5 | Backflip Scatter | phys | NEEDS ART | ninja__skills_t2 / 5 |
| 6 | Blast Tags | fire | NEEDS ART | ninja__skills_t2 / 6 |
| 7 | Storm of Steel | phys | NEEDS ART | ninja__skills_t2 / 7 |
| 8 | Poison Darts | poison | NEEDS ART | ninja__skills_t2 / 8 |
| 9 | Demon Wind Shuriken | shadow | NEEDS ART | ninja__skills_t2 / 9 |

### Skill tree 4: Dragon Ninpo

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Nunchaku Flurry | phys | NEEDS ART | ninja__skills_t3 / 1 |
| 2 | Art of the Fire Wheels | fire | NEEDS ART | ninja__skills_t3 / 2 |
| 3 | Thunder Step | light | NEEDS ART | ninja__skills_t3 / 3 |
| 4 | Dragon Flail | phys | NEEDS ART | ninja__skills_t3 / 4 |
| 5 | Art of the Inferno | fire | NEEDS ART | ninja__skills_t3 / 5 |
| 6 | Art of the Piercing Void | shadow | NEEDS ART | ninja__skills_t3 / 6 |
| 7 | Lightning Kick | light | NEEDS ART | ninja__skills_t3 / 7 |
| 8 | Ninpo Trance | shadow | NEEDS ART | ninja__skills_t3 / 8 |
| 9 | True Dragon Technique | fire | NEEDS ART | ninja__skills_t3 / 9 |

### Talent branch 1: Kenjutsu

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Keen Edge | phys | NEEDS ART | ninja__talents_b0 / 1 |
| 2 | Moon Cutter | phys | NEEDS ART | ninja__talents_b0 / 2 |
| 3 | Flash Step | light | NEEDS ART | ninja__talents_b0 / 3 |
| 4 | Bladesong | phys | NEEDS ART | ninja__talents_b0 / 4 |
| 5 | Severing Draw | blood | NEEDS ART | ninja__talents_b0 / 5 |
| 6 | Storm of Petals | phys | NEEDS ART | ninja__talents_b0 / 6 |
| 7 | Thousand-Fold Blade | phys | NEEDS ART | ninja__talents_b0 / 7 |
| 8 | Certain Death | blood | NEEDS ART | ninja__talents_b0 / 8 |

### Talent branch 2: Shadow Arts

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Shadow Walker | shadow | NEEDS ART | ninja__talents_b1 / 1 |
| 2 | Living Shadows | shadow | NEEDS ART | ninja__talents_b1 / 2 |
| 3 | Iron Hook | phys | NEEDS ART | ninja__talents_b1 / 3 |
| 4 | Night Veil | shadow | NEEDS ART | ninja__talents_b1 / 4 |
| 5 | Umbral Host | shadow | NEEDS ART | ninja__talents_b1 / 5 |
| 6 | Smoke and Knives | shadow | NEEDS ART | ninja__talents_b1 / 6 |
| 7 | Substitution | shadow | NEEDS ART | ninja__talents_b1 / 7 |
| 8 | Shadows of Substance | shadow | NEEDS ART | ninja__talents_b1 / 8 |

### Talent branch 3: Hidden Arsenal

| # | Name | Element | Status | Batch / cell |
|---|---|---|---|---|
| 1 | Steady Hand | phys | NEEDS ART | ninja__talents_b2 / 1 |
| 2 | Storm of Stars | phys | NEEDS ART | ninja__talents_b2 / 2 |
| 3 | Barbed Caltrops | poison | NEEDS ART | ninja__talents_b2 / 3 |
| 4 | Ninpo Mastery | fire | NEEDS ART | ninja__talents_b2 / 4 |
| 5 | Inferno Scroll | fire | NEEDS ART | ninja__talents_b2 / 5 |
| 6 | Demon Wind | shadow | NEEDS ART | ninja__talents_b2 / 6 |
| 7 | Master of Arms | phys | NEEDS ART | ninja__talents_b2 / 7 |
| 8 | Dragon Heart | fire | NEEDS ART | ninja__talents_b2 / 8 |

**Ultimate:** Moonless Night (shadow): NEEDS ART, ultimates_3 / cell 1
