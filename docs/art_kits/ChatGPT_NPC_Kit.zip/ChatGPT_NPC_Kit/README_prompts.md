# VELSCOUR ChatGPT NPC (townsfolk) kit

A sheet of **4 animated townsfolk** for Herrington Hollow and the overworld roads. Same frames as the town's existing 25 identities (each frame 128 x 192 in game):

- **Townsfolk**: 11 frames: IDLE 1-3, WALK 1-2, DYING, DEAD (lying on the ground), SCREAM (scared), POINT (scared, pointing), HAPPY, CHEER (celebrating, arms up).
- **Knights / guards**: the same 11 plus ATTACK 1-2 (sword wind-up, strike): use the knights template.

| File | Size | What |
|---|---|---|
| `templates/npcs_template.png` | 1536 x 1024 | 4 rows x 11 frames |
| `templates/knights_template.png` | 1536 x 1024 | 4 rows x 13 frames |
| `examples/npcs_example.png` | 1536 x 1024 | Baker, Healer, Boy, King |
| `examples/knights_example.png` | 1536 x 1024 | the town's four knights |
| `npcs_names_template.json` | | names, roles, child or adult |

## Step 0: paste this first (style bible)

Open a new chat, attach nothing, paste:

```text
We are making art for VELSCOUR, a retro isometric pixel-art action RPG in the style of Diablo II
(dark fantasy, grimdark, gothic). Everything is seen from the game's 3/4 isometric camera, slightly from above.

Rules for every image I ask for:
- Crisp, detailed pixel-art sprites with hard edges, a dark muted palette, light from the upper left.
  Match the attached EXAMPLE's rendering style, level of detail and size in the frame exactly.
- Follow the attached TEMPLATE exactly: same 1536x1024 canvas, same grid, same cell order. The cyan dashed
  boxes are bounding outlines: fit the art inside them. Feet stand on the yellow ground line.
- Characters face RIGHT (three-quarter view towards screen right).
- Background: pure flat magenta #FF00FF everywhere (or real transparency). No shadows on the ground, no floor,
  no gradients, no glow that bleeds far outside the creature. Sprites never touch each other or the cell edges.
- Remove ALL guide marks from your output: no cyan or yellow lines, no labels, no numbers, no text, no borders.
- Every cell is a different design unless I say otherwise; keep one consistent style across all sheets.
Reply "ready" and wait for the first sheet.
```

## Step 1: the sheet

```text
Sheet: 4 TOWNSFOLK. Attached: template and example. 1536x1024. Each ROW is one person, each COLUMN one frame:
idle 1, idle 2, idle 3, walk 1, walk 2, dying, dead (lying flat), scream (scared), point (scared, pointing),
happy, cheer (arms raised). People: [1 = an old fisherman, 2 = ..., 3 = ..., 4 = ...]. The SAME person in every
frame of a row: same face, hair, clothes, colours and size. Medieval dark-fantasy village folk, facing right,
feet on the yellow line, inside the cyan boxes. Leave the label column and header empty magenta.
```
Knights: use `knights_template.png` and add "...cheer, attack 1 (sword raised), attack 2 (sword swung down)".

## Step 2: the names file

```text
Fill in this JSON for the 4 people in order: "name", "role" (their job), and "child" true for children.
Set "knights" true if this is the knights sheet. Reply with the JSON only.
```

## Importing the result

Save ChatGPT's image and the filled-in names file, then from the repository root:

```bash
python tools/chatgpt_art.py npcs <image.png> <names.json> --dry   # cut only: look at tools/tests/out/chatgpt_art/preview.png
python tools/chatgpt_art.py npcs <image.png> <names.json>
```
`chatgpt_art.py` is in this zip too (it lives in `tools/`). It needs `pip install pillow numpy scipy`.

Each person becomes `assets/sprites/townsfolk/townsfolk_NNN.png` (numbered after 100) with a `manifest.json` entry. To put them in town, point townsfolk at the new numbers in `src/data/townsfolk.js` (`spriteForJob`, or a row in `knights` / `court` / `regular`).

## Check the reply before importing

- Same 3:2 canvas (1536 x 1024), same number of cells, nothing in the wrong cell.
- Background flat magenta, no floor or shadow under the art, no labels or guide lines left over.
- Nothing touching a neighbour or crossing a cell edge (the importer gives each cell the art whose centre is in it).
- If one cell is wrong, ask: "Redraw only cell N, keep everything else pixel-identical."

