# VELSCOUR ChatGPT boss kit

A sheet of **6 bosses**: guardians and raid bosses. Same idea as the enemy kit, with bigger cells (512 x 512, the size set 2's titans, colossi and hydras were drawn at) and more detail. Bosses never join packs; each depth picks its guardian from them.

| File | Size | What |
|---|---|---|
| `templates/bosses_template.png` | 1536 x 1024 | 3 x 2 cells of 512 x 512 |
| `examples/bosses_example.png` | 1536 x 1024 | six of the game's boss sprites in the same layout |
| `bosses_names_template.json` | | names, AI archetype, height and element, filled in by ChatGPT |

## Step 0: paste this first (style bible)

Open a new chat, attach nothing, paste:

```text
We are making art for VELSCOUR, a retro isometric pixel-art action RPG in the style of Diablo II
(dark fantasy, grimdark, gothic). Everything is seen from the game's 3/4 isometric camera, slightly from above.

Rules for every image I ask for:
- Crisp, detailed pixel-art sprites with hard edges, a dark muted palette, light from the upper left.
  Match the attached EXAMPLE's rendering style, level of detail and size in the frame exactly.
- Follow the attached TEMPLATE exactly: same 1536x1024 canvas, same grid, same cell order. The cyan dashed
  boxes are bounding outlines: fit the art inside them. Feet stand on the yellow ground line.
- Characters face RIGHT (three-quarter view towards screen right).
- Background: pure flat magenta #FF00FF everywhere (or real transparency). No shadows on the ground, no floor,
  no gradients, no glow that bleeds far outside the creature. Sprites never touch each other or the cell edges.
- Remove ALL guide marks from your output: no cyan or yellow lines, no labels, no numbers, no text, no borders.
- Every cell is a different design unless I say otherwise; keep one consistent style across all sheets.
Reply "ready" and wait for the first sheet.
```

## Step 1: the sheet

```text
Sheet: 6 BOSSES. Attached: template and example. Theme: [e.g. "kings of a drowned empire"].
1536x1024, 3 columns x 2 rows of 512x512 cells, one huge boss per cell in reading order, each filling its
cyan box, feet (or base) on the yellow line, facing right. Make them imposing and unmistakably bosses:
crowns, giant weapons, many limbs, glowing cores. Very different silhouettes. Same style as the example.
```

## Step 2: the names file

```text
Fill in this JSON for the 6 bosses in order. "family" is one lowercase word. Per boss: "name",
"arch" (one of the listed archetypes; golem/abomination/demon/knight suit big melee bosses, cultist/eye/wraith
casters), "h" (height in game pixels: the hero is 60, bosses 90-160), "el" (or ""), and "fly" true for
flying bosses. Keep the keys exactly; reply with the JSON only.
```

## Importing the result

Save ChatGPT's image and the filled-in names file, then from the repository root:

```bash
python tools/chatgpt_art.py bosses <image.png> <names.json> --dry   # cut only: look at tools/tests/out/chatgpt_art/preview.png
python tools/chatgpt_art.py bosses <image.png> <names.json>
```
`chatgpt_art.py` is in this zip too (it lives in `tools/`). It needs `pip install pillow numpy scipy`.

The printed `BESTIARY` rows carry `boss: true, lone: true`. To also use one as a raid boss (every 5th depth), give a `RAID_BOSSES` entry in `src/game/raid.js` its id as `art`.

## Check the reply before importing

- Same 3:2 canvas (1536 x 1024), same number of cells, nothing in the wrong cell.
- Background flat magenta, no floor or shadow under the art, no labels or guide lines left over.
- Nothing touching a neighbour or crossing a cell edge (the importer gives each cell the art whose centre is in it).
- If one cell is wrong, ask: "Redraw only cell N, keep everything else pixel-identical."

