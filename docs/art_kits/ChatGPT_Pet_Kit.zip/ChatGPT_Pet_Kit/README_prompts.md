# VELSCOUR ChatGPT pet kit

A sheet of **4 animated pets** (summons and companions). Two layouts, matching the game's pet animations:

- **Land** (walkers): 9 frames per pet: REST, SPAWN 1-3 (rising out of the ground or arriving), RUN 1-3, ATTACK 1-2.
- **Winged** (flyers): 6 frames per pet: FLAP 1-3 (hovering in place), FLY 1-3 (flying forward).

| File | Size | What |
|---|---|---|
| `templates/pets_land_template.png` | 1536 x 1024 | 4 rows x 9 frames, frame names on top |
| `templates/pets_winged_template.png` | 1536 x 1024 | 4 rows x 6 frames |
| `examples/pets_land_example.png` | 1536 x 1024 | Wolf, Bear, Skeleton Warrior, Fire Golem |
| `examples/pets_winged_example.png` | 1536 x 1024 | Storm Hawk, Raven, Phoenix, Drake Whelp |
| `pets_names_template.json` | | sheet name, land or winged, and the four pets |

## Step 0: paste this first (style bible)

Open a new chat, attach nothing, paste:

```text
We are making art for VELSCOUR, a retro isometric pixel-art action RPG in the style of Diablo II
(dark fantasy, grimdark, gothic). Everything is seen from the game's 3/4 isometric camera, slightly from above.

Rules for every image I ask for:
- Crisp, detailed pixel-art sprites with hard edges, a dark muted palette, light from the upper left.
  Match the attached EXAMPLE's rendering style, level of detail and size in the frame exactly.
- Follow the attached TEMPLATE exactly: same 1536x1024 canvas, same grid, same cell order. The cyan dashed
  boxes are bounding outlines: fit the art inside them. Feet stand on the yellow ground line.
- Characters face RIGHT (three-quarter view towards screen right).
- Background: pure flat magenta #FF00FF everywhere (or real transparency). No shadows on the ground, no floor,
  no gradients, no glow that bleeds far outside the creature. Sprites never touch each other or the cell edges.
- Remove ALL guide marks from your output: no cyan or yellow lines, no labels, no numbers, no text, no borders.
- Every cell is a different design unless I say otherwise; keep one consistent style across all sheets.
Reply "ready" and wait for the first sheet.
```

## Step 1: the sheet

Attach the land (or winged) template and its example:

```text
Sheet: 4 ANIMATED PETS, LAND. Attached: template and example. 1536x1024. Each ROW is one pet, each COLUMN one
animation frame in this order: rest, spawn 1, spawn 2, spawn 3, run 1, run 2, run 3, attack 1, attack 2.
Pets: [1 = ..., 2 = ..., 3 = ..., 4 = ...]. The SAME creature in every frame of its row (same colours,
markings, size and gear); only the pose changes. Spawn: from crouched/forming to standing. Run: a 3-frame
gallop or stride. Attack: wind-up and strike (bite, claw, slash or spell). Facing right, feet on the yellow
line, every pose inside its cyan box. Leave the left label column and the top header empty magenta.
```
Winged: "...each COLUMN one frame: flap 1, flap 2, flap 3 (wings up, level, down while hovering), fly 1, fly 2,
fly 3 (body tilted forward, flying right)."

## Step 2: the names file

```text
Fill in this JSON: "sheet" (one lowercase word naming this group), "kind" ("land" or "winged"),
and for each row "name" and "h" (height in game pixels: the hero is 60; wolves 34, bears 44, birds 26-34).
Reply with the JSON only.
```

## Importing the result

Save ChatGPT's image and the filled-in names file, then from the repository root:

```bash
python tools/chatgpt_art.py pets <image.png> <names.json> --dry   # cut only: look at tools/tests/out/chatgpt_art/preview.png
python tools/chatgpt_art.py pets <image.png> <names.json>
```
`chatgpt_art.py` is in this zip too (it lives in `tools/`). It needs `pip install pillow numpy scipy`.

The frames are cut to a clean sheet in `assets/source/pet_animations/` and packed by `tools/build_pet_animations.py`; `src/core/petart.js` animates any summon whose key matches a row. The script prints a `SUMMONS` entry per pet for `src/data/summons.js`.

## Check the reply before importing

- Same 3:2 canvas (1536 x 1024), same number of cells, nothing in the wrong cell.
- Background flat magenta, no floor or shadow under the art, no labels or guide lines left over.
- Nothing touching a neighbour or crossing a cell edge (the importer gives each cell the art whose centre is in it).
- If one cell is wrong, ask: "Redraw only cell N, keep everything else pixel-identical."

