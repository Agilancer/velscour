# VELSCOUR ChatGPT enemy kit

A sheet of **10 monsters** for one family (a themed group, like set 2's goblins or slimes). Each monster is a single still pose: the game moves, flips, flashes and sizes it (`h` in the names file), and palette-swaps it per biome. So draw every monster as large as its cyan box allows, whole body, feet on the yellow line.

| File | Size | What |
|---|---|---|
| `templates/enemies_template.png` | 1536 x 1024 | 5 x 2 cells (307 x 512), outlines and ground lines |
| `examples/enemies_example.png` | 1536 x 1024 | the same layout filled with ten of the game's monsters |
| `enemies_names_template.json` | | names, AI archetype, height and element per cell, filled in by ChatGPT |

## Step 0: paste this first (style bible)

Open a new chat, attach nothing, paste:

```text
We are making art for VELSCOUR, a retro isometric pixel-art action RPG in the style of Diablo II
(dark fantasy, grimdark, gothic). Everything is seen from the game's 3/4 isometric camera, slightly from above.

Rules for every image I ask for:
- Crisp, detailed pixel-art sprites with hard edges, a dark muted palette, light from the upper left.
  Match the attached EXAMPLE's rendering style, level of detail and size in the frame exactly.
- Follow the attached TEMPLATE exactly: same 1536x1024 canvas, same grid, same cell order. The cyan dashed
  boxes are bounding outlines: fit the art inside them. Feet stand on the yellow ground line.
- Characters face RIGHT (three-quarter view towards screen right).
- Background: pure flat magenta #FF00FF everywhere (or real transparency). No shadows on the ground, no floor,
  no gradients, no glow that bleeds far outside the creature. Sprites never touch each other or the cell edges.
- Remove ALL guide marks from your output: no cyan or yellow lines, no labels, no numbers, no text, no borders.
- Every cell is a different design unless I say otherwise; keep one consistent style across all sheets.
Reply "ready" and wait for the first sheet.
```

## Step 1: the sheet

Attach the template and the example, then paste (fill the brackets):

```text
Sheet: 10 MONSTERS. Attached: template and example. Family: [e.g. "drowned sailors: bloated, barnacled
corpses with rusted cutlasses, kelp and green-black water"]. 1536x1024, 5 columns x 2 rows of equal cells,
one monster per cell in reading order, each fitting its cyan box, feet on the yellow line, facing right.
Ten clearly different monsters of this family: mix sizes and roles (a small fast one, a ranged one, a caster,
a tank, a brute...). [Optional: list them: 1 = ..., 2 = ...]. Same style and detail as the example.
```

## Step 2: the names file

Attach `enemies_names_template.json` and paste:

```text
Fill in this JSON for the 10 monsters you drew, in the same order. "family" is one lowercase word for the
group. For each monster: "name" (2-3 words), "arch" (the AI it fights with, one of the listed archetypes),
"h" (height in game pixels: the hero is 60; imps and crawlers 30-40, men 54-58, brutes 64-80),
"el" (element it shows, or "" for none). Keep the keys exactly; reply with the JSON only.
```

## Importing the result

Save ChatGPT's image and the filled-in names file, then from the repository root:

```bash
python tools/chatgpt_art.py enemies <image.png> <names.json> --dry   # cut only: look at tools/tests/out/chatgpt_art/preview.png
python tools/chatgpt_art.py enemies <image.png> <names.json>
```
`chatgpt_art.py` is in this zip too (it lives in `tools/`). It needs `pip install pillow numpy scipy`.

The sprites go to `assets/source/enemies/set3/<family>/` (numbered after the existing ones) and the enemy importer packs them into an atlas. The script prints one `BESTIARY` row per monster to paste into `src/data/bestiary.js`; after that they spawn in levels whose biome rosters use their archetypes.

## Check the reply before importing

- Same 3:2 canvas (1536 x 1024), same number of cells, nothing in the wrong cell.
- Background flat magenta, no floor or shadow under the art, no labels or guide lines left over.
- Nothing touching a neighbour or crossing a cell edge (the importer gives each cell the art whose centre is in it).
- If one cell is wrong, ask: "Redraw only cell N, keep everything else pixel-identical."

